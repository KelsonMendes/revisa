// Fila de revisões em segundo plano: a IA começa a revisar enquanto o SOC ainda está sendo lido,
// e vai adiantando as próximas enquanto o médico confere a Fila. Puro (sem Node): usado pelo app local e pela extensão.
import { config } from './config.js';

const fila = [];
const emCurso = new Map(); // chave → promessa da revisão em andamento
let executor = null;

export const estadoFila = { pendentes: 0, feitas: 0, erros: 0 };

// rotas.js diz como revisar um item ({ data, crecid, seq, campo }).
export function definirExecutor(fn) {
  executor = fn;
  girar();
}

export const chaveRevisao = ({ data, crecid, seq, campo }) => `${data}|${crecid}|${seq}|${campo}`;

export function enfileirar(tarefa) {
  const chave = chaveRevisao(tarefa);
  if (emCurso.has(chave) || fila.some((t) => t.chave === chave)) return;
  fila.push({ ...tarefa, chave });
  estadoFila.pendentes++;
  girar();
}

// Se esta revisão já está rodando por trás, espera por ela em vez de pedir de novo.
export function esperarSeEmCurso(tarefa) {
  return emCurso.get(chaveRevisao(tarefa)) || null;
}

function girar() {
  const limite = Math.max(1, Number(config.revisoesSimultaneas) || 2);
  while (executor && emCurso.size < limite && fila.length) {
    const t = fila.shift();
    const p = Promise.resolve()
      .then(() => executor(t))
      .then(() => { estadoFila.feitas++; }, (e) => { estadoFila.erros++; console.warn('[revisa.] revisão por trás:', e?.message || e); })
      .finally(() => { emCurso.delete(t.chave); estadoFila.pendentes--; girar(); });
    emCurso.set(t.chave, p);
  }
}
