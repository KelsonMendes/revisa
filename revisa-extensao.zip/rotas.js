// Ações do painel (o que antes ficava no servidor). Usado pelo app local (server.js) e pela extensão do Edge:
// cada um entrega a sua versão de db.js, cdp.js, ia.js, config.js e checklist.js.
import { config, salvarAjustes } from './config.js';
import { edgeAberto, conectar } from './cdp.js';
import { estadoSoc, agendaAtual, colar, abrirFicha, listarAgendas, passoDoLote } from './soc.js';
import { veu, tirarVeu } from './veu.js';
import { varrerDia, progresso, lembrarMedico } from './varredura.js';
import { definirExecutor, estadoFila, esperarSeEmCurso } from './fila-ia.js';
import { pseudonimizar, restaurar } from './anon.js';
import { revisar, pontePresente } from './ia.js';
import { montarPedidoLote, lerRespostaLote } from './prompt.js';
import { checklist } from './checklist.js';
import {
  agora, registrar, salvarAtendimento, atendimentosDoDia, atendimentosDesde, atendimento, revisoesDoAtendimento, revisao,
  lembrarAgenda, agendasConhecidas, guardarAgendasDoSoc, apagarLidos, salvarRevisao, atualizarRevisao, todasRevisoes,
  marcarConcluido, concluidosDosDias, desfazerConcluido,
} from './db.js';
import { ESTADOS, diasDesde, chaveConcluido, fluxoCompleto } from './estado.js';

// Exame físico padrão (Kelson, 24/10/2026): entra na evolução só quando o médico confirma que fez. Editável em ⚙.
const EXAME_FISICO_PADRAO = 'Exame físico: bom estado geral, lúcido e orientado. Ausculta cardíaca: ritmo regular em dois tempos, bulhas normofonéticas, sem sopros. Ausculta pulmonar: murmúrio vesicular presente e simétrico, sem ruídos adventícios. Membros superiores: força muscular preservada contra resistência; mobilidade ativa e passiva dos ombros preservada e indolor; teste de Apley negativo; punhos com sinal de Tinel e teste de Phalen negativos; teste de Finkelstein negativo. Coluna: percussão das apófises espinhosas indolor. Membros inferiores: força muscular preservada em flexão e extensão contra resistência; mobilidade de tornozelos e pés preservada. Questionado sobre dor na coluna: nega. Sem outras alterações ao exame.';

const REVISORES = ['claude-code', 'chatgpt', 'gemini', 'claude', 'copilot', 'outra'];

const CAMPOS = {
  cad009: [
    { campo: 'anamnese', rotulo: 'Anamnese' },
    { campo: 'observacaoComplemento', rotulo: 'Observações' },
  ],
  cad016: [
    { campo: 'periciaLicenca', rotulo: 'Perícia' },
    { campo: 'restricaoRetorno', rotulo: 'Restrição de retorno' },
  ],
};

async function montarAtendimento(a, feitos = new Set()) {
  const ficha = JSON.parse(a.ficha_json || '{}');
  // "preparada" = revisada por trás, ainda não pedida pelo médico: não aparece no painel até ele clicar em Revisar.
  const revs = (await revisoesDoAtendimento(a.id)).filter((r) => r.status !== 'preparada').map((r) => ({
    ...r,
    resultado: r.resultado_json ? JSON.parse(r.resultado_json) : null,
    resultado_json: undefined,
  }));
  return {
    id: a.id,
    data: a.data,
    hora: a.hora,
    local: a.agenda_nome,
    agendaCodigo: a.agenda_codigo,
    podeAbrir: !!JSON.parse(a.linha_json || '{}').hrefFicha,
    paciente: a.paciente,
    empresa: a.empresa,
    tipo: a.tipo_texto,
    doMedico: a.do_medico,
    // A agenda daquele local não tem a coluna "Profissional da Agenda".
    semProfissional: !!JSON.parse(a.linha_json || '{}').semColunaProfissional,
    profissional: a.profissional || '',
    medico: ficha.medico || '',
    estadoPrincipal: a.estado_principal,
    estadoPrincipalTexto: ESTADOS[a.estado_principal] || a.estado_principal,
    documentoPrincipal: ficha.programa === 'cad016' ? 'Licença médica' : 'Ficha clínica',
    estadoAso: a.estado_aso,
    estadoAsoTexto: a.estado_aso ? ESTADOS[a.estado_aso] : null,
    diasDesde: diasDesde(a.data),
    // Já inspecionado: o fluxo terminou (assinado, ASO assinado). Sai da lista "A fazer".
    concluido: feitos.has(chaveConcluido(a.data, a.paciente)),
    chaveConcluido: chaveConcluido(a.data, a.paciente),
    alerta: a.estado_principal !== 'assinada' && diasDesde(a.data) >= config.diasAlertaSemAssinatura,
    erro: ficha.erro || null,
    campos: (CAMPOS[ficha.programa] || []).map((c) => ({ ...c, texto: ficha.textos?.[c.campo] || '' })),
    revisoes: revs,
  };
}

async function montarVarios(lista) {
  const feitos = new Set((await concluidosDosDias([...new Set(lista.map((a) => a.data))])).map((c) => c.chave));
  return Promise.all(lista.map((a) => montarAtendimento(a, feitos)));
}

// Prepara um campo para a IA: texto e contexto já sem nome, CPF, contatos e outros nomes.
// A consulta do SOC escreve a pressão como "120por90(HipertensãoEstágio1)": vira "120x90 (hipertensão estágio 1)".
function limparPressao(p) {
  const [, valor = p, classe = ''] = String(p).replace(/\s+/g, '').match(/^([\d.,]+(?:x|por|\/)[\d.,]+)(?:\((.*)\))?/i) || [];
  const v = valor.replace(/por|\//i, 'x');
  const c = classe.replace(/([a-zà-ú])([A-ZÀ-Ú])/g, '$1 $2').replace(/([A-Za-zÀ-ú])(\d)/g, '$1 $2').toLowerCase();
  return c ? `${v} (${c})` : v;
}

// Sinais vitais e medidas da ficha numa linha (são preenchidos fora da evolução). IMC calculado se faltar.
function resumirSinais(s) {
  if (!s) return null;
  const num = (x) => Number(String(x || '').replace(',', '.').replace(/[^\d.]/g, ''));
  let imc = s.imc;
  const peso = num(s.peso);
  let altura = num(s.altura);
  if (altura > 3) altura /= 100; // altura em cm
  if (!imc && peso && altura) imc = (peso / (altura * altura)).toFixed(1).replace('.', ',');
  const partes = [
    s.pressao && /\d/.test(s.pressao) && `PA ${limparPressao(s.pressao)} mmHg`,
    s.frequenciaPulso && `FC ${s.frequenciaPulso} bpm`,
    s.frequenciaRespiratoria && `FR ${s.frequenciaRespiratoria} irpm`,
    s.temperatura && `Temperatura ${s.temperatura} °C`,
    s.peso && `Peso ${s.peso} kg`,
    s.altura && `Altura ${s.altura} m`,
    imc && `IMC ${imc} kg/m²`,
    s.cintura && `Circunferência abdominal ${s.cintura} cm`,
    s.biotipo && !/selecione/i.test(s.biotipo) && `Biotipo ${s.biotipo}`,
  ].filter(Boolean);
  return partes.length ? partes.join('; ') : null;
}

// Questionário da ficha gravada ("Item ▷ Sim/Não"): por bloco, o que é Sim (refere), o que é Não (nega) e o resto.
function resumirQuestionarioSoc(grupos, anonimizar) {
  if (!Array.isArray(grupos) || !grupos.length) return null;
  const linhas = grupos.map((g) => {
    const sim = g.itens.filter((i) => /^sim$/i.test(i.valor)).map((i) => i.item);
    const nao = g.itens.filter((i) => /^n[ãa]o$/i.test(i.valor)).map((i) => i.item);
    const outros = g.itens.filter((i) => !/^(sim|n[ãa]o)$/i.test(i.valor) && i.valor).map((i) => `${i.item} = ${i.valor}`);
    return [`${g.titulo}:`, sim.length && `Sim → ${sim.join(', ')}`, nao.length && `Não → ${nao.join(', ')}`, outros.length && outros.join('; ')]
      .filter(Boolean).join(' ');
  });
  return anonimizar(linhas.join('\n')).slice(0, 5000);
}

// Questionário da ficha em linhas curtas para a IA. "nada marcado" = o paciente negou.
function resumirQuestionario(questionario, anonimizar) {
  if (!Array.isArray(questionario) || !questionario.length) return null;
  const linhas = questionario.map((g) => {
    if (g.opcoes.length) {
      if (g.marcadas.length) return `${g.pergunta}: marcado ${g.marcadas.join(', ')}`;
      // Lista de caixas sem nenhuma marcada = o paciente negou. Pergunta de Sim/Não sem resposta é só "sem resposta".
      return g.radio ? `${g.pergunta}: sem resposta` : `${g.pergunta}: nada marcado (o paciente negou; opções: ${g.opcoes.slice(0, 12).join(', ')})`;
    }
    return `${g.pergunta}: ${g.textos.join(' / ')}`;
  });
  return anonimizar(linhas.join('\n')).slice(0, 4000);
}

async function prepararCampo(atendimentoId, campo) {
  const a = await atendimento(atendimentoId);
  if (!a) throw new Error('Atendimento não encontrado');
  const ficha = JSON.parse(a.ficha_json || '{}');
  if (!ficha.existe) throw new Error('A ficha ainda não foi gerada no SOC; não há texto para revisar.');
  const original = ficha.textos?.[campo] ?? '';
  const outrosNomes = [a.empresa, ficha.incluidoPor, ficha.alteradoPor, ficha.medico].filter(Boolean);
  const anon = pseudonimizar(original, { paciente: a.paciente, outrosNomes });
  if (anon.sobrou.length) throw new Error('A anonimização não removeu todo o nome do paciente; revisão bloqueada por segurança.');
  const contexto = {
    tipo: ficha.tipoExame || a.tipo_texto,
    idade: ficha.idade,
    sexo: ficha.sexo,
    cargo: ficha.cargo,
    setor: ficha.setor,
    parecer: ficha.parecer || null,
    licenca: ficha.licenca || null,
    exameFisico: ficha.exameFisico ? pseudonimizar(ficha.exameFisico, { paciente: a.paciente, outrosNomes }).texto : null,
    sinaisVitais: resumirSinais(ficha.sinais),
    exameFisicoPadrao: campo === 'anamnese' ? config.exameFisicoPadrao || EXAME_FISICO_PADRAO : undefined,
    riscos: ficha.riscos ? pseudonimizar(ficha.riscos, { paciente: a.paciente, outrosNomes }).texto.slice(0, 1500) : null,
    questionario: resumirQuestionario(ficha.questionario, (t) => pseudonimizar(t, { paciente: a.paciente, outrosNomes }).texto)
      || resumirQuestionarioSoc(ficha.questionarioSoc, (t) => pseudonimizar(t, { paciente: a.paciente, outrosNomes }).texto),
  };
  return { a, campo, original, dados: { campo, tipoExame: contexto.tipo, contexto, texto: anon.texto } };
}

// O parecer do médico é Apto? Vale a última linha do texto aprovado ("Apto."/"Apta.") ou, sem ela, o parecer da ficha.
// Apto para trabalho em altura: só se o médico escreveu isso na evolução.
const aptoAltura = (texto) => /apt[oa][^.\n]{0,40}altura/i.test(String(texto || ''));

function parecerApto(texto, parecerFicha) {
  const ultima = String(texto || '').trim().split('\n').filter((l) => l.trim()).pop() || '';
  if (/^inapt[oa]/i.test(ultima.trim())) return false;
  if (/^apt[oa]\b/i.test(ultima.trim())) return true;
  return /^apto/i.test(String(parecerFicha || '').trim());
}

// Paciente com tudo feito (assinado, ASO assinado ou sem ASO) vai para "Já inspecionados".
async function concluirSeTerminou(id, como) {
  const final = await atendimento(id);
  if (!final || !fluxoCompleto(final.estado_principal, final.estado_aso)) return false;
  await marcarConcluido({ chave: chaveConcluido(final.data, final.paciente), data: final.data, hora: final.hora, paciente: final.paciente,
    empresa: final.empresa, tipo_texto: final.tipo_texto, agenda_nome: final.agenda_nome, estado_principal: final.estado_principal,
    estado_aso: final.estado_aso, concluido_em: agora(), como });
  return true;
}

// Lote (Kelson, 31/10): o médico já revisou as fichas e só quer gerar e assinar. Nada de IA, nada de texto mexido.
// Um atendimento por vez, com o mesmo véu e a mesma barra de progresso da leitura.
async function rodarLote(lista, { pdf, assinar, aso }) {
  Object.assign(progresso, { rodando: true, etapa: 'Lote: conectando ao SOC', feito: 0, total: lista.length, erro: null, aviso: null, resumo: null, terminou: null });
  const conta = { pdfs: 0, assinados: 0, asos: 0, pedidos: 0, aguardando: 0, pendentes: [], erros: [] };
  let s;
  try {
    s = await conectar();
    for (const a of lista) {
      const linha = JSON.parse(a.linha_json || '{}');
      const ficha = JSON.parse(a.ficha_json || '{}');
      const nome = String(a.paciente || '').split(' ')[0];
      progresso.etapa = `Lote: ${progresso.feito + 1} de ${lista.length} · ${a.hora} ${nome}`;
      await veu(s, { titulo: 'Gerando e assinando em lote', detalhe: `${a.hora} · ${a.tipo_texto || ''}`, feito: progresso.feito, total: lista.length });
      try {
        // ASO só com o parecer que o médico já deu na ficha: Apto. Inapto ou sem parecer fica para ele.
        const comAso = aso && ficha.programa !== 'cad016' && parecerApto(ficha.textos?.anamnese, ficha.parecer);
        const r = await passoDoLote(s, {
          linha, data: a.data, agenda: { codigo: a.agenda_codigo, nome: a.agenda_nome }, programa: ficha.programa,
          estadoPrincipal: a.estado_principal, estadoAso: a.estado_aso, pdf, assinar, aso: comAso, textoFicha: ficha.textos?.anamnese || '',
        });
        const troca = {};
        if (r.pdf?.ok) { conta.pdfs++; troca.estado_principal = r.pdf.assinado ? 'assinada' : r.pdf.pedido ? 'pdf_pedido' : 'pdf_pendente'; if (r.pdf.assinado) conta.assinados++; }
        else if (r.pdf) conta.erros.push(`${a.hora} ${nome}: PDF da ficha não saiu (${r.pdf.motivo})`);
        if (r.assinatura?.ok) { conta.assinados++; troca.estado_principal = 'assinada'; }
        else if (r.assinatura) conta.erros.push(`${a.hora} ${nome}: ${r.assinatura.motivo}`);
        if (r.pedido?.ok) { conta.pedidos++; troca.estado_principal = 'pdf_pedido'; }
        else if (r.pedido) conta.erros.push(`${a.hora} ${nome}: ${r.pedido.motivo}`);
        if (r.aguardando) conta.aguardando++;
        if (r.aso?.ok) { conta.asos++; troca.estado_aso = r.aso.assinado ? 'assinada' : r.aso.pdf ? 'pdf_pendente' : 'sem_pdf'; }
        else if (r.aso) conta.pendentes.push(`${a.hora} ${nome}: ${r.aso.motivo}`);
        if (Object.keys(troca).length) await salvarAtendimento(linhaAtendimento(await atendimento(a.id), troca));
        await concluirSeTerminou(a.id, 'lote');
        await registrar('lote', `${a.data} ${a.hora}: ${JSON.stringify({ pdf: r.pdf?.ok, ass: r.assinatura?.ok ?? r.pdf?.assinado, aso: r.aso?.ok, pedido: r.pedido?.ok })}`);
      } catch (e) {
        conta.erros.push(`${a.hora} ${nome}: ${e.message}`);
      }
      progresso.feito++;
    }
    progresso.resumo = [
      `${lista.length} no lote`,
      conta.pdfs && `${conta.pdfs} PDF(s) de ficha`,
      conta.assinados && `${conta.assinados} assinado(s)`,
      conta.asos && `${conta.asos} ASO(s)`,
      conta.pedidos && `${conta.pedidos} licença(s) pedida(s) ao SOC: rode o lote de novo daqui a uns 30 min para assinar`,
      conta.aguardando && `${conta.aguardando} licença(s) ainda sem o PDF do SOC`,
      conta.pendentes.length && `ASO pendente: ${conta.pendentes.join(' | ')}`,
      conta.erros.length && `Não deu: ${conta.erros.join(' | ')}`,
    ].filter(Boolean).join(' · ');
    progresso.etapa = 'Concluído';
  } catch (e) {
    progresso.erro = e.message;
  } finally {
    progresso.rodando = false;
    progresso.terminou = agora();
    if (s) {
      try { await tirarVeu(s, progresso.erro ? {} : { mensagem: `Lote: ${progresso.resumo}` }); } catch { /* */ }
      s.close();
    }
  }
}

// Linha do atendimento no formato que salvarAtendimento espera (com campos trocados).
function linhaAtendimento(a, troca = {}) {
  const chaves = ['data', 'hora', 'agenda_codigo', 'agenda_nome', 'profissional', 'paciente', 'empresa', 'tipo', 'tipo_texto', 'crecid',
    'cod_funcionario', 'seq_compromisso', 'linha_json', 'ficha_json', 'do_medico', 'estado_principal', 'estado_aso', 'ged_json', 'lido_em'];
  return Object.fromEntries(chaves.map((k) => [k, k in troca ? troca[k] : a[k] ?? null]));
}

async function guardarRevisao(p, resultado, extra = {}) {
  await salvarRevisao({
    atendimento_id: p.a.id,
    campo: p.campo,
    texto_original: p.original,
    resultado_json: JSON.stringify(resultado),
    texto_sugerido: restaurar(resultado.texto_sugerido, { paciente: p.a.paciente }),
    status: extra.status || 'sugerida',
    modelo: extra.modelo || null,
    tokens_entrada: extra.tokensEntrada ?? null,
    tokens_saida: extra.tokensSaida ?? null,
    criada_em: agora(),
  });
  await registrar('revisao', `atendimento ${p.a.id} campo ${p.campo}`);
}

// Campos ainda sem revisão (e com texto) dos meus atendimentos de um dia.
async function camposParaRevisar(data) {
  const saida = [];
  for (const a of await atendimentosDoDia(data)) {
    if (!a.do_medico) continue;
    const m = await montarAtendimento(a);
    for (const c of m.campos) {
      if (c.texto && !m.revisoes.some((r) => r.campo === c.campo && r.status !== 'descartada')) saida.push({ atendimentoId: a.id, campo: c.campo });
    }
  }
  return saida;
}

export const rotas = {
  'GET /api/estado': async () => {
    const aberto = await edgeAberto();
    let soc = null;
    if (aberto) {
      try {
        const s = await conectar();
        soc = await estadoSoc(s);
        s.close();
        await lembrarMedico(soc.usuario);
        // A agenda aberta no SOC entra na lista (sem mudar a ordem) para virar a escolha padrão do painel.
        if (soc.agendaAberta?.codigo && soc.agendaAberta.nome) await guardarAgendasDoSoc([soc.agendaAberta]);
      } catch (e) {
        soc = { erro: e.message };
      }
    }
    return { edgeAberto: aberto, soc, progresso: { ...progresso, ia: { ...estadoFila } }, agendas: await agendasConhecidas(), medico: config.medico, modoIA: config.modoIA || 'auto' };
  },

  // O médico troca a agenda no SOC (seletor da própria agenda) e o app guarda o local.
  'POST /api/agenda/detectar': async () => {
    const s = await conectar();
    try {
      const a = await agendaAtual(s);
      await lembrarAgenda({ codigo: a.codigo, nome: a.nome });
      return a;
    } finally {
      s.close();
    }
  },

  // A mesma lista do botão "Trocar agenda" do SOC, guardada para o seletor do painel.
  'POST /api/agendas/buscar': async () => {
    const s = await conectar();
    try {
      const r = await listarAgendas(s);
      await guardarAgendasDoSoc(r.agendas);
      return { agendas: await agendasConhecidas(), reconheceu: r.reconheceu };
    } finally {
      s.close();
    }
  },

  // agendaCodigo: o código de uma agenda, "@minhas" (procura onde você já atendeu) ou "@todas" (procura em todas do SOC).
  'POST /api/varrer': async (corpo) => {
    const busca = { '@minhas': 'minhas', '@todas': 'todas' }[corpo.agendaCodigo] || null;
    const agenda = !busca && corpo.agendaCodigo ? (await agendasConhecidas()).find((x) => x.codigo === corpo.agendaCodigo) : null;
    varrerDia({ data: corpo.data, agenda, busca }).catch(() => {});
    return { iniciado: true };
  },

  // Lixeira: { data } apaga o dia; { tudo: true } apaga todos os dias lidos. Para ler de novo do zero.
  'POST /api/limpar': async (corpo) => {
    if (progresso.rodando) throw new Error('Espere a leitura terminar para limpar.');
    if (!corpo.tudo && !corpo.data) throw new Error('Diga qual dia limpar.');
    const n = await apagarLidos(corpo.tudo ? null : corpo.data);
    await registrar('limpar', corpo.tudo ? `tudo: ${n} atendimentos` : `${corpo.data}: ${n} atendimentos`);
    Object.assign(progresso, { erro: null, aviso: null, terminou: null, feito: 0, total: 0 });
    return { apagados: n };
  },

  'GET /api/atendimentos': async (_c, url) => montarVarios(await atendimentosDoDia(url.searchParams.get('data'))),

  // Lote: os atendimentos escolhidos no painel (os seus, ainda não concluídos). Roda por trás; o painel acompanha
  // pela mesma barra da leitura.
  'POST /api/lote': async (corpo) => {
    if (progresso.rodando) throw new Error('Espere a leitura ou o lote atual terminar.');
    const ids = (corpo.ids || []).map(Number);
    if (!ids.length) throw new Error('Nenhum atendimento no lote.');
    const lista = (await Promise.all(ids.map((id) => atendimento(id))))
      .filter((a) => a && a.do_medico && !['outro_medico', 'nao_compareceu', 'nao_gerada', 'erro'].includes(a.estado_principal))
      .sort((x, y) => String(x.hora).localeCompare(String(y.hora)));
    if (!lista.length) throw new Error('Nenhum desses atendimentos tem ficha gravada para gerar.');
    rodarLote(lista, { pdf: corpo.pdf !== false, assinar: !!corpo.assinar, aso: !!corpo.aso }).catch(() => {});
    return { iniciado: true, total: lista.length };
  },

  // "Voltar para a lista": o paciente deixa de ser "já inspecionado" e a próxima leitura abre a ficha de novo.
  'POST /api/concluido/desfazer': async (corpo) => {
    await desfazerConcluido(String(corpo.chave || ''));
    await registrar('concluido_desfeito', String(corpo.chave || '').split('|')[0]);
    return { ok: true };
  },

  'POST /api/revisar': async (corpo) => {
    if ((config.modoIA || 'auto') === 'manual') throw new Error('A revisão está no modo copiar e colar: use o botão "Revisar pelo…" da aba Dia.');
    // Já revisado por trás (ou revisando agora): usa esse resultado em vez de pedir de novo.
    const at = await atendimento(corpo.atendimentoId);
    if (at) {
      const rodando = esperarSeEmCurso({ data: at.data, crecid: at.crecid, seq: at.seq_compromisso, campo: corpo.campo });
      if (rodando) await rodando;
      const doCampo = (await revisoesDoAtendimento(at.id)).filter((r) => r.campo === corpo.campo && r.status !== 'descartada');
      // Revisada por trás: só agora, com o clique, ela aparece.
      const preparada = doCampo.find((r) => r.status === 'preparada');
      if (preparada && !corpo.deNovo) await atualizarRevisao(preparada.id, { status: 'sugerida' });
      if (doCampo.length && !corpo.deNovo) return montarAtendimento(await atendimento(corpo.atendimentoId));
    }
    const p = await prepararCampo(corpo.atendimentoId, corpo.campo);
    const r = await revisar(p.dados);
    await guardarRevisao(p, r.resultado, r);
    return montarAtendimento(await atendimento(corpo.atendimentoId));
  },

  // Modo manual: um pedido com vários campos para colar no claude.ai.
  'POST /api/manual/pedido': async (corpo) => {
    const alvos = corpo.data ? await camposParaRevisar(corpo.data) : corpo.itens || [];
    if (!alvos.length) throw new Error('Nada novo para revisar neste dia.');
    const itens = [];
    for (const [i, alvo] of alvos.entries()) {
      const p = await prepararCampo(alvo.atendimentoId, alvo.campo);
      itens.push({ id: `R${i + 1}-${alvo.atendimentoId}-${alvo.campo}`, ...p.dados });
    }
    return { texto: montarPedidoLote(checklist, itens), quantidade: itens.length };
  },

  'POST /api/manual/resposta': async (corpo) => {
    const lista = lerRespostaLote(corpo.texto);
    let feitas = 0;
    const ignoradas = [];
    for (const r of lista) {
      const m = r.id.match(/^R\d+-(\d+)-(\w+)$/);
      if (!m) { ignoradas.push(r.id || '(sem id)'); continue; }
      const { id: _id, ...resultado } = r;
      const p = await prepararCampo(Number(m[1]), m[2]);
      await guardarRevisao(p, resultado, { modelo: 'claude.ai (manual)' });
      feitas++;
    }
    if (!feitas) throw new Error('A resposta não trouxe nenhum registro reconhecível. Copie a resposta inteira do Claude.');
    return { feitas, ignoradas };
  },

  'POST /api/aprovar': async (corpo) => {
    const r = await revisao(corpo.revisaoId);
    if (!r) throw new Error('Revisão não encontrada');
    if (/\[COMPLETAR/i.test(corpo.texto)) throw new Error('Ainda há marcadores [COMPLETAR: ...] no texto. Preencha antes de aprovar.');
    if (/\[CONFERIR CONDUTA/i.test(corpo.texto)) throw new Error('Ainda há [CONFERIR CONDUTA: ...] no texto. Decida a conduta antes de aprovar.');
    const ajustes = Array.isArray(corpo.ajustes) ? corpo.ajustes.slice(0, 40) : [];
    await atualizarRevisao(r.id, { texto_aprovado: corpo.texto, status: 'aprovada', aprovada_em: agora(), ajustes_json: JSON.stringify(ajustes) });
    await registrar('aprovacao', `revisao ${r.id}`);
    return montarAtendimento(await atendimento(r.atendimento_id));
  },

  'POST /api/descartar': async (corpo) => {
    const r = await revisao(corpo.revisaoId);
    await atualizarRevisao(r.id, { status: 'descartada' });
    return montarAtendimento(await atendimento(r.atendimento_id));
  },

  // Números da Visão geral: tudo vem dos dados locais, sem tocar no SOC.
  'GET /api/painel': async () => {
    const hoje = new Date();
    const br = (d) => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    const meus = (await atendimentosDesde(60)).filter((a) => a.do_medico);
    const grupo = (a) => (a.estado_principal === 'assinada' ? 'assinada' : a.estado_principal === 'nao_gerada' ? 'nao_gerada' : 'pendente');

    const dias = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - i);
      const doDia = meus.filter((a) => a.data === br(d));
      dias.push({
        data: br(d),
        semana: d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''),
        lido: doDia.length > 0,
        assinada: doDia.filter((a) => grupo(a) === 'assinada').length,
        pendente: doDia.filter((a) => grupo(a) === 'pendente').length,
        nao_gerada: doDia.filter((a) => grupo(a) === 'nao_gerada').length,
      });
    }

    const abertos = meus.filter((a) => !['assinada', 'outro_medico', 'nao_compareceu'].includes(a.estado_principal));
    const faixa = (min, max) => abertos.filter((a) => { const d = diasDesde(a.data); return d >= min && d <= max; }).length;
    const atraso = { recentes: faixa(0, 6), semana: faixa(7, 14), antigas: faixa(15, 9999) };

    const revs = (await todasRevisoes()).filter((r) => r.status !== 'preparada');
    const limite30 = Date.now() - 30 * 86400000;
    const recentes = revs.filter((r) => Date.parse(r.criada_em) >= limite30 && r.resultado_json);
    const notas = recentes.map((r) => JSON.parse(r.resultado_json).nota_completude).filter((n) => typeof n === 'number');
    const contagem = new Map();
    for (const r of recentes) {
      for (const ach of JSON.parse(r.resultado_json).achados || []) {
        const chave = String(ach.item || '').split(/[:—-]/)[0].trim() || 'Outros';
        const c = contagem.get(chave) || { item: chave, total: 0, altas: 0 };
        c.total++;
        if (ach.gravidade === 'alta') c.altas++;
        contagem.set(chave, c);
      }
    }
    const ultima = [...meus].sort((x, y) => String(y.lido_em).localeCompare(String(x.lido_em)))[0];

    return {
      hoje: br(hoje),
      medico: config.medico,
      dias,
      atraso,
      totalAbertos: abertos.length,
      fila: { aguardando: revs.filter((r) => r.status === 'sugerida').length, aprovadas: revs.filter((r) => r.status === 'aprovada').length,
        coladas30: recentes.filter((r) => r.status === 'colada').length },
      qualidade: { revisoes: recentes.length, notaMedia: notas.length ? notas.reduce((x, y) => x + y, 0) / notas.length : null,
        distribuicao: [0, 1, 2, 3, 4].map((i) => notas.filter((n) => Math.min(4, Math.floor(n / 2)) === i).length),
        achados: [...contagem.values()].sort((x, y) => y.total - x.total).slice(0, 5) },
      ultimaLeitura: ultima ? { data: ultima.data, local: ultima.agenda_nome, quando: ultima.lido_em } : null,
    };
  },

  // Pendências dos meus atendimentos nos últimos N dias já lidos: o que não está assinado.
  'GET /api/pendencias': async (_c, url) => {
    const dias = Number(url.searchParams.get('dias') || 30);
    const todos = await atendimentosDesde(dias);
    const lista = (await montarVarios(todos.filter((a) => a.do_medico)))
      .filter((a) => !a.concluido && (!['assinada', 'outro_medico', 'nao_compareceu'].includes(a.estadoPrincipal) || (a.estadoAso && a.estadoAso !== 'assinada')))
      .sort((x, y) => y.diasDesde - x.diasDesde || x.hora.localeCompare(y.hora));
    return { lista, diasLidos: new Set(todos.map((a) => a.data)).size, dias };
  },

  // Só abre a ficha no Edge para o médico agir (gerar, imprimir PDF, assinar). Nada é alterado.
  'POST /api/abrir': async (corpo) => {
    if (progresso.rodando) throw new Error('Espere a leitura terminar.');
    const a = await atendimento(corpo.atendimentoId);
    if (!a) throw new Error('Atendimento não encontrado');
    const s = await conectar();
    try {
      await abrirFicha(s, { linha: JSON.parse(a.linha_json), data: a.data, agenda: { codigo: a.agenda_codigo, nome: a.agenda_nome } });
      return { ok: true };
    } finally {
      s.close();
    }
  },

  'GET /api/config': async () => ({
    medico: config.medico,
    medicoDoSoc: config.medicoDoSoc || '',
    medicoManual: !!config.medicoManual,
    modeloClaudeCode: config.modeloClaudeCode || 'sonnet',
    revisoesSimultaneas: config.revisoesSimultaneas || 2,
    diasAlertaSemAssinatura: config.diasAlertaSemAssinatura,
    modoIA: config.modoIA || 'auto',
    revisor: config.revisor || '',
    tourVisto: !!config.tourVisto,
    exameFisicoPadrao: config.exameFisicoPadrao || EXAME_FISICO_PADRAO,
  }),

  // O Claude Code deste computador responde? (a extensão pergunta à ponte; o app local roda "claude --version")
  'GET /api/ia/ponte': async () => ({ ok: await pontePresente() }),

  'POST /api/config': async (corpo) => {
    const novos = {};
    // Nome em branco (ou igual ao do login) = usar o nome de quem está logado no SOC.
    if (typeof corpo.medico === 'string') {
      const nome = corpo.medico.trim();
      const doSoc = config.medicoDoSoc || '';
      if (!nome || nome === doSoc) Object.assign(novos, { medicoManual: false, medico: doSoc || config.medico });
      else if (nome.length >= 3) Object.assign(novos, { medicoManual: true, medico: nome });
    }
    if (['opus', 'sonnet'].includes(corpo.modeloClaudeCode)) novos.modeloClaudeCode = corpo.modeloClaudeCode;
    if ([1, 2, 3].includes(Number(corpo.revisoesSimultaneas))) novos.revisoesSimultaneas = Number(corpo.revisoesSimultaneas);
    if (Number(corpo.diasAlertaSemAssinatura) >= 1) novos.diasAlertaSemAssinatura = Number(corpo.diasAlertaSemAssinatura);
    if (['auto', 'manual'].includes(corpo.modoIA)) novos.modoIA = corpo.modoIA;
    // Revisor escolhido no onboarding ou nas configurações: só o Claude Code é automático; os outros são copiar e colar.
    if (REVISORES.includes(corpo.revisor)) Object.assign(novos, { revisor: corpo.revisor, modoIA: corpo.revisor === 'claude-code' ? 'auto' : 'manual' });
    if (corpo.tourVisto === true) novos.tourVisto = true;
    // Exame físico padrão do médico: em branco volta ao texto de fábrica.
    if (typeof corpo.exameFisicoPadrao === 'string') novos.exameFisicoPadrao = corpo.exameFisicoPadrao.trim().slice(0, 3000) || EXAME_FISICO_PADRAO;
    await salvarAjustes(novos);
    return rotas['GET /api/config']();
  },

  // Uma ficha por vez. O médico escolhe até onde ir: 'colar' (ele salva), 'salvar', 'pdf' (salva e gera o PDF)
  // ou 'assinar' (salva, gera o PDF e assina pela pastinha). O ASO entra junto com o PDF, se o parecer for Apto.
  'POST /api/colar': async (corpo) => {
    const acao = ['colar', 'salvar', 'pdf', 'assinar'].includes(corpo.acao) ? corpo.acao : corpo.salvar ? 'pdf' : 'colar';
    corpo.salvar = acao !== 'colar';
    const comPdf = acao === 'pdf' || acao === 'assinar';
    const r = await revisao(corpo.revisaoId);
    if (!r || r.status !== 'aprovada') throw new Error('Só dá para colar uma revisão aprovada.');
    if (progresso.rodando) throw new Error('Espere a leitura terminar antes de colar.');
    const a = await atendimento(r.atendimento_id);
    const s = await conectar();
    try {
      const res = await colar(s, {
        linha: JSON.parse(a.linha_json),
        data: a.data,
        agenda: { codigo: a.agenda_codigo, nome: a.agenda_nome },
        campo: r.campo,
        texto: r.texto_aprovado,
        esperado: r.texto_original,
        ajustes: JSON.parse(r.ajustes_json || '[]'),
        salvar: corpo.salvar,
        // PDF e assinatura: só ficha clínica.
        gerarPdf: comPdf && JSON.parse(a.ficha_json || '{}').programa !== 'cad016',
        assinar: acao === 'assinar',
        // ASO junto com o PDF: só na ficha clínica, só se o parecer do médico for Apto (última linha do texto ou parecer da ficha).
        aso: comPdf && corpo.aso !== false && JSON.parse(a.ficha_json || '{}').programa !== 'cad016' && parecerApto(r.texto_aprovado, JSON.parse(a.ficha_json || '{}').parecer),
      });
      if (!res?.ok) throw new Error(res?.motivo || 'Não consegui colar no SOC.');
      await atualizarRevisao(r.id, { status: 'colada', colada_em: agora() });
      await registrar(corpo.salvar ? 'colagem_salva' : 'colagem', `revisao ${r.id} campo ${r.campo}${res.salvo ? ` salvo=${res.salvo.ok} pdf=${res.pdf?.ok ?? '-'}` : ''}`);
      const q = res.questionario;
      const movido = res.movido ? ` Atenção: ${res.movido}.` : '';
      const extra = movido + (q ? ` ${q.feitos.length ? `Marquei no questionário: ${q.feitos.join('; ')}.` : ''}${q.faltaram.length ? ` Não achei na ficha: ${q.faltaram.join('; ')}; marque à mão.` : ''}` : '');
      if (!corpo.salvar) return { ok: true, aviso: `Texto colado no SOC.${extra} Confira a ficha e clique em Salvar você mesmo.` };
      if (!res.salvo?.ok) return { ok: false, aviso: `Texto colado,${extra} mas o SOC não gravou: ${res.salvo?.motivo}. A ficha ficou aberta para você conferir e salvar.` };
      // A ficha mudou no SOC: o estado do atendimento acompanha (sem PDF → PDF sem assinatura).
      await salvarAtendimento(linhaAtendimento(a, {
        estado_principal: res.assinatura?.ok ? 'assinada' : res.pdf?.ok ? 'pdf_pendente' : 'sem_pdf',
        ficha_json: JSON.stringify({ ...JSON.parse(a.ficha_json || '{}'), textos: { ...(JSON.parse(a.ficha_json || '{}').textos || {}), [r.campo]: r.texto_aprovado }, fichaPossuiGed: !!res.pdf?.ok }),
      }));
      const pdf = res.pdf == null ? '' : !res.pdf.ok ? ` O PDF da ficha não saiu (${res.pdf.motivo}).`
        : res.pdf.pedido ? ` PDF da ficha pedido ao SOC (pedido ${res.pdf.pedido}): ele aparece na pastinha da ficha em alguns minutos.`
          : res.pdf.aviso ? ` ${res.pdf.aviso}` : ' PDF da ficha gerado no SOCGED.';
      let aso = '';
      if (res.aso) {
        aso = res.aso.ok
          ? ` ASO gravado como Apto${res.aso.extras?.length ? ` (${res.aso.extras.join('; ')})` : ''}${res.aso.pdf ? ' e PDF do ASO gerado' : `, mas o PDF do ASO não saiu (${res.aso.motivo})`}.${res.aso.pendentes?.length ? ` Ficou para você no ASO: ${res.aso.pendentes.join(', ')}.` : ''}`
          : ` O ASO ficou pendente: ${res.aso.motivo}`;
        if (res.aso.ok) {
          const atual = await atendimento(a.id);
          await salvarAtendimento(linhaAtendimento(atual, { estado_aso: res.aso.pdf ? 'pdf_pendente' : 'sem_pdf' }));
        }
      } else if (comPdf && JSON.parse(a.ficha_json || '{}').programa !== 'cad016') {
        aso = ' O ASO não foi mexido: o parecer não é Apto (faça à mão).';
      }
      const assinatura = res.assinatura == null ? '' : res.assinatura.ok ? ' PDF da ficha assinado.' : ` A assinatura não foi concluída: ${res.assinatura.motivo}`;
      // Tudo feito (ficha assinada e ASO assinado ou sem ASO): o paciente vai para "Já inspecionados".
      const final = await atendimento(a.id);
      let encerrou = '';
      if (fluxoCompleto(final.estado_principal, final.estado_aso)) {
        await marcarConcluido({ chave: chaveConcluido(final.data, final.paciente), data: final.data, hora: final.hora, paciente: final.paciente,
          empresa: final.empresa, tipo_texto: final.tipo_texto, agenda_nome: final.agenda_nome, estado_principal: final.estado_principal,
          estado_aso: final.estado_aso, concluido_em: agora(), como: 'painel' });
        encerrou = ' Paciente concluído: foi para "Já inspecionados".';
      }
      const falta = [res.pdf?.ok && !res.assinatura?.ok ? 'o PDF da ficha' : '', res.aso?.pdf ? 'o PDF do ASO' : ''].filter(Boolean);
      const assinar = falta.length ? ` Falta assinar ${falta.join(' e ')}.` : '';
      return { ok: true, aviso: `Ficha salva no SOC.${extra}${pdf}${assinatura}${aso}${assinar}${encerrou}` };
    } finally {
      s.close();
    }
  },
};

// Despacha um pedido no formato do painel: método, caminho com ?consulta e corpo JSON.
export async function atender(metodo, endereco, corpo) {
  const url = new URL(endereco, 'http://auditor.local');
  const rota = rotas[`${metodo} ${url.pathname}`];
  if (!rota) return { status: 404, corpo: { erro: 'Rota não encontrada' } };
  try {
    return { status: 200, corpo: await rota(corpo || {}, url) };
  } catch (e) {
    return { status: 400, corpo: { erro: e.message } };
  }
}

// Revisão por trás (fila-ia.js): acha o atendimento lido e revisa o campo, se ainda não houver revisão dele.
definirExecutor(async ({ data, crecid, seq, campo }) => {
  const a = (await atendimentosDoDia(data)).find((x) => x.crecid === crecid && x.seq_compromisso === seq);
  if (!a || a.do_medico !== 1) return;
  if ((await revisoesDoAtendimento(a.id)).some((r) => r.campo === campo && r.status !== 'descartada')) return;
  const p = await prepararCampo(a.id, campo);
  const r = await revisar(p.dados);
  await guardarRevisao(p, r.resultado, { ...r, status: 'preparada' });
});
