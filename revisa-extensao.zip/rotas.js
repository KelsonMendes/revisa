// Ações do painel (o que antes ficava no servidor). Usado pelo app local (server.js) e pela extensão do Edge:
// cada um entrega a sua versão de db.js, cdp.js, ia.js, config.js e checklist.js.
import { config, salvarAjustes } from './config.js';
import { edgeAberto, conectar } from './cdp.js';
import { estadoSoc, agendaAtual, colar, abrirFicha, listarAgendas } from './soc.js';
import { varrerDia, progresso, lembrarMedico } from './varredura.js';
import { pseudonimizar, restaurar } from './anon.js';
import { revisar } from './ia.js';
import { montarPedidoLote, lerRespostaLote } from './prompt.js';
import { checklist } from './checklist.js';
import {
  agora, registrar, atendimentosDoDia, atendimentosDesde, atendimento, revisoesDoAtendimento, revisao,
  lembrarAgenda, agendasConhecidas, guardarAgendasDoSoc, apagarLidos, salvarRevisao, atualizarRevisao, todasRevisoes,
} from './db.js';
import { ESTADOS, diasDesde } from './estado.js';

const CAMPOS = {
  cad009: [
    { campo: 'anamnese', rotulo: 'Anamnese' },
    { campo: 'observacaoComplemento', rotulo: 'Observações' },
  ],
  cad016: [
    { campo: 'periciaLicenca', rotulo: 'Perícia' },
    { campo: 'restricaoRetorno', rotulo: 'Restrição de retorno' },
  ],
};

async function montarAtendimento(a) {
  const ficha = JSON.parse(a.ficha_json || '{}');
  const revs = (await revisoesDoAtendimento(a.id)).map((r) => ({
    ...r,
    resultado: r.resultado_json ? JSON.parse(r.resultado_json) : null,
    resultado_json: undefined,
  }));
  return {
    id: a.id,
    data: a.data,
    hora: a.hora,
    local: a.agenda_nome,
    agendaCodigo: a.agenda_codigo,
    podeAbrir: !!JSON.parse(a.linha_json || '{}').hrefFicha,
    paciente: a.paciente,
    empresa: a.empresa,
    tipo: a.tipo_texto,
    doMedico: a.do_medico,
    profissional: a.profissional || '',
    medico: ficha.medico || '',
    estadoPrincipal: a.estado_principal,
    estadoPrincipalTexto: ESTADOS[a.estado_principal] || a.estado_principal,
    documentoPrincipal: ficha.programa === 'cad016' ? 'Licença médica' : 'Ficha clínica',
    estadoAso: a.estado_aso,
    estadoAsoTexto: a.estado_aso ? ESTADOS[a.estado_aso] : null,
    diasDesde: diasDesde(a.data),
    alerta: a.estado_principal !== 'assinada' && diasDesde(a.data) >= config.diasAlertaSemAssinatura,
    erro: ficha.erro || null,
    campos: (CAMPOS[ficha.programa] || []).map((c) => ({ ...c, texto: ficha.textos?.[c.campo] || '' })),
    revisoes: revs,
  };
}

const montarVarios = (lista) => Promise.all(lista.map(montarAtendimento));

// Prepara um campo para a IA: texto e contexto já sem nome, CPF, contatos e outros nomes.
async function prepararCampo(atendimentoId, campo) {
  const a = await atendimento(atendimentoId);
  if (!a) throw new Error('Atendimento não encontrado');
  const ficha = JSON.parse(a.ficha_json || '{}');
  if (!ficha.existe) throw new Error('A ficha ainda não foi gerada no SOC; não há texto para revisar.');
  const original = ficha.textos?.[campo] ?? '';
  const outrosNomes = [a.empresa, ficha.incluidoPor, ficha.alteradoPor, ficha.medico].filter(Boolean);
  const anon = pseudonimizar(original, { paciente: a.paciente, outrosNomes });
  if (anon.sobrou.length) throw new Error('A anonimização não removeu todo o nome do paciente; revisão bloqueada por segurança.');
  const contexto = {
    tipo: ficha.tipoExame || a.tipo_texto,
    idade: ficha.idade,
    sexo: ficha.sexo,
    cargo: ficha.cargo,
    setor: ficha.setor,
    parecer: ficha.parecer || null,
    licenca: ficha.licenca || null,
    exameFisico: ficha.exameFisico ? pseudonimizar(ficha.exameFisico, { paciente: a.paciente, outrosNomes }).texto : null,
  };
  return { a, campo, original, dados: { campo, tipoExame: contexto.tipo, contexto, texto: anon.texto } };
}

async function guardarRevisao(p, resultado, extra = {}) {
  await salvarRevisao({
    atendimento_id: p.a.id,
    campo: p.campo,
    texto_original: p.original,
    resultado_json: JSON.stringify(resultado),
    texto_sugerido: restaurar(resultado.texto_sugerido, { paciente: p.a.paciente }),
    status: 'sugerida',
    modelo: extra.modelo || null,
    tokens_entrada: extra.tokensEntrada ?? null,
    tokens_saida: extra.tokensSaida ?? null,
    criada_em: agora(),
  });
  await registrar('revisao', `atendimento ${p.a.id} campo ${p.campo}`);
}

// Campos ainda sem revisão (e com texto) dos meus atendimentos de um dia.
async function camposParaRevisar(data) {
  const saida = [];
  for (const a of await atendimentosDoDia(data)) {
    if (!a.do_medico) continue;
    const m = await montarAtendimento(a);
    for (const c of m.campos) {
      if (c.texto && !m.revisoes.some((r) => r.campo === c.campo && r.status !== 'descartada')) saida.push({ atendimentoId: a.id, campo: c.campo });
    }
  }
  return saida;
}

export const rotas = {
  'GET /api/estado': async () => {
    const aberto = await edgeAberto();
    let soc = null;
    if (aberto) {
      try {
        const s = await conectar();
        soc = await estadoSoc(s);
        s.close();
        await lembrarMedico(soc.usuario);
      } catch (e) {
        soc = { erro: e.message };
      }
    }
    return { edgeAberto: aberto, soc, progresso, agendas: await agendasConhecidas(), medico: config.medico, modoIA: config.modoIA || 'auto' };
  },

  // O médico troca a agenda no SOC (seletor da própria agenda) e o app guarda o local.
  'POST /api/agenda/detectar': async () => {
    const s = await conectar();
    try {
      const a = await agendaAtual(s);
      await lembrarAgenda({ codigo: a.codigo, nome: a.nome });
      return a;
    } finally {
      s.close();
    }
  },

  // A mesma lista do botão "Trocar agenda" do SOC, guardada para o seletor do painel.
  'POST /api/agendas/buscar': async () => {
    const s = await conectar();
    try {
      const r = await listarAgendas(s);
      await guardarAgendasDoSoc(r.agendas);
      return { agendas: await agendasConhecidas(), reconheceu: r.reconheceu };
    } finally {
      s.close();
    }
  },

  // agendaCodigo: o código de uma agenda, "@minhas" (procura onde você já atendeu) ou "@todas" (procura em todas do SOC).
  'POST /api/varrer': async (corpo) => {
    const busca = { '@minhas': 'minhas', '@todas': 'todas' }[corpo.agendaCodigo] || null;
    const agenda = !busca && corpo.agendaCodigo ? (await agendasConhecidas()).find((x) => x.codigo === corpo.agendaCodigo) : null;
    varrerDia({ data: corpo.data, agenda, busca }).catch(() => {});
    return { iniciado: true };
  },

  // Lixeira: { data } apaga o dia; { tudo: true } apaga todos os dias lidos. Para ler de novo do zero.
  'POST /api/limpar': async (corpo) => {
    if (progresso.rodando) throw new Error('Espere a leitura terminar para limpar.');
    if (!corpo.tudo && !corpo.data) throw new Error('Diga qual dia limpar.');
    const n = await apagarLidos(corpo.tudo ? null : corpo.data);
    await registrar('limpar', corpo.tudo ? `tudo: ${n} atendimentos` : `${corpo.data}: ${n} atendimentos`);
    Object.assign(progresso, { erro: null, aviso: null, terminou: null, feito: 0, total: 0 });
    return { apagados: n };
  },

  'GET /api/atendimentos': async (_c, url) => montarVarios(await atendimentosDoDia(url.searchParams.get('data'))),

  'POST /api/revisar': async (corpo) => {
    if ((config.modoIA || 'auto') === 'manual') throw new Error('A revisão está no modo manual: use "Revisar pelo claude.ai".');
    const p = await prepararCampo(corpo.atendimentoId, corpo.campo);
    const r = await revisar(p.dados);
    await guardarRevisao(p, r.resultado, r);
    return montarAtendimento(await atendimento(corpo.atendimentoId));
  },

  // Modo manual: um pedido com vários campos para colar no claude.ai.
  'POST /api/manual/pedido': async (corpo) => {
    const alvos = corpo.data ? await camposParaRevisar(corpo.data) : corpo.itens || [];
    if (!alvos.length) throw new Error('Nada novo para revisar neste dia.');
    const itens = [];
    for (const [i, alvo] of alvos.entries()) {
      const p = await prepararCampo(alvo.atendimentoId, alvo.campo);
      itens.push({ id: `R${i + 1}-${alvo.atendimentoId}-${alvo.campo}`, ...p.dados });
    }
    return { texto: montarPedidoLote(checklist, itens), quantidade: itens.length };
  },

  'POST /api/manual/resposta': async (corpo) => {
    const lista = lerRespostaLote(corpo.texto);
    let feitas = 0;
    const ignoradas = [];
    for (const r of lista) {
      const m = r.id.match(/^R\d+-(\d+)-(\w+)$/);
      if (!m) { ignoradas.push(r.id || '(sem id)'); continue; }
      const { id: _id, ...resultado } = r;
      const p = await prepararCampo(Number(m[1]), m[2]);
      await guardarRevisao(p, resultado, { modelo: 'claude.ai (manual)' });
      feitas++;
    }
    if (!feitas) throw new Error('A resposta não trouxe nenhum registro reconhecível. Copie a resposta inteira do Claude.');
    return { feitas, ignoradas };
  },

  'POST /api/aprovar': async (corpo) => {
    const r = await revisao(corpo.revisaoId);
    if (!r) throw new Error('Revisão não encontrada');
    if (/\[COMPLETAR/i.test(corpo.texto)) throw new Error('Ainda há marcadores [COMPLETAR: ...] no texto. Preencha antes de aprovar.');
    await atualizarRevisao(r.id, { texto_aprovado: corpo.texto, status: 'aprovada', aprovada_em: agora() });
    await registrar('aprovacao', `revisao ${r.id}`);
    return montarAtendimento(await atendimento(r.atendimento_id));
  },

  'POST /api/descartar': async (corpo) => {
    const r = await revisao(corpo.revisaoId);
    await atualizarRevisao(r.id, { status: 'descartada' });
    return montarAtendimento(await atendimento(r.atendimento_id));
  },

  // Números da Visão geral: tudo vem dos dados locais, sem tocar no SOC.
  'GET /api/painel': async () => {
    const hoje = new Date();
    const br = (d) => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
    const meus = (await atendimentosDesde(60)).filter((a) => a.do_medico);
    const grupo = (a) => (a.estado_principal === 'assinada' ? 'assinada' : a.estado_principal === 'nao_gerada' ? 'nao_gerada' : 'pendente');

    const dias = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - i);
      const doDia = meus.filter((a) => a.data === br(d));
      dias.push({
        data: br(d),
        semana: d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''),
        lido: doDia.length > 0,
        assinada: doDia.filter((a) => grupo(a) === 'assinada').length,
        pendente: doDia.filter((a) => grupo(a) === 'pendente').length,
        nao_gerada: doDia.filter((a) => grupo(a) === 'nao_gerada').length,
      });
    }

    const abertos = meus.filter((a) => a.estado_principal !== 'assinada' && a.estado_principal !== 'outro_medico');
    const faixa = (min, max) => abertos.filter((a) => { const d = diasDesde(a.data); return d >= min && d <= max; }).length;
    const atraso = { recentes: faixa(0, 6), semana: faixa(7, 14), antigas: faixa(15, 9999) };

    const revs = await todasRevisoes();
    const limite30 = Date.now() - 30 * 86400000;
    const recentes = revs.filter((r) => Date.parse(r.criada_em) >= limite30 && r.resultado_json);
    const notas = recentes.map((r) => JSON.parse(r.resultado_json).nota_completude).filter((n) => typeof n === 'number');
    const contagem = new Map();
    for (const r of recentes) {
      for (const ach of JSON.parse(r.resultado_json).achados || []) {
        const chave = String(ach.item || '').split(/[:—-]/)[0].trim() || 'Outros';
        const c = contagem.get(chave) || { item: chave, total: 0, altas: 0 };
        c.total++;
        if (ach.gravidade === 'alta') c.altas++;
        contagem.set(chave, c);
      }
    }
    const ultima = [...meus].sort((x, y) => String(y.lido_em).localeCompare(String(x.lido_em)))[0];

    return {
      hoje: br(hoje),
      medico: config.medico,
      dias,
      atraso,
      totalAbertos: abertos.length,
      fila: { aguardando: revs.filter((r) => r.status === 'sugerida').length, aprovadas: revs.filter((r) => r.status === 'aprovada').length,
        coladas30: recentes.filter((r) => r.status === 'colada').length },
      qualidade: { revisoes: recentes.length, notaMedia: notas.length ? notas.reduce((x, y) => x + y, 0) / notas.length : null,
        distribuicao: [0, 1, 2, 3, 4].map((i) => notas.filter((n) => Math.min(4, Math.floor(n / 2)) === i).length),
        achados: [...contagem.values()].sort((x, y) => y.total - x.total).slice(0, 5) },
      ultimaLeitura: ultima ? { data: ultima.data, local: ultima.agenda_nome, quando: ultima.lido_em } : null,
    };
  },

  // Pendências dos meus atendimentos nos últimos N dias já lidos: o que não está assinado.
  'GET /api/pendencias': async (_c, url) => {
    const dias = Number(url.searchParams.get('dias') || 30);
    const todos = await atendimentosDesde(dias);
    const lista = (await montarVarios(todos.filter((a) => a.do_medico)))
      .filter((a) => !['assinada', 'outro_medico'].includes(a.estadoPrincipal) || (a.estadoAso && a.estadoAso !== 'assinada'))
      .sort((x, y) => y.diasDesde - x.diasDesde || x.hora.localeCompare(y.hora));
    return { lista, diasLidos: new Set(todos.map((a) => a.data)).size, dias };
  },

  // Só abre a ficha no Edge para o médico agir (gerar, imprimir PDF, assinar). Nada é alterado.
  'POST /api/abrir': async (corpo) => {
    if (progresso.rodando) throw new Error('Espere a leitura terminar.');
    const a = await atendimento(corpo.atendimentoId);
    if (!a) throw new Error('Atendimento não encontrado');
    const s = await conectar();
    try {
      await abrirFicha(s, { linha: JSON.parse(a.linha_json), data: a.data, agenda: { codigo: a.agenda_codigo, nome: a.agenda_nome } });
      return { ok: true };
    } finally {
      s.close();
    }
  },

  'GET /api/config': async () => ({
    medico: config.medico,
    medicoDoSoc: config.medicoDoSoc || '',
    medicoManual: !!config.medicoManual,
    modeloClaudeCode: config.modeloClaudeCode || 'opus',
    revisoesSimultaneas: config.revisoesSimultaneas || 2,
    diasAlertaSemAssinatura: config.diasAlertaSemAssinatura,
    modoIA: config.modoIA || 'auto',
  }),

  'POST /api/config': async (corpo) => {
    const novos = {};
    // Nome em branco (ou igual ao do login) = usar o nome de quem está logado no SOC.
    if (typeof corpo.medico === 'string') {
      const nome = corpo.medico.trim();
      const doSoc = config.medicoDoSoc || '';
      if (!nome || nome === doSoc) Object.assign(novos, { medicoManual: false, medico: doSoc || config.medico });
      else if (nome.length >= 3) Object.assign(novos, { medicoManual: true, medico: nome });
    }
    if (['opus', 'sonnet'].includes(corpo.modeloClaudeCode)) novos.modeloClaudeCode = corpo.modeloClaudeCode;
    if ([1, 2, 3].includes(Number(corpo.revisoesSimultaneas))) novos.revisoesSimultaneas = Number(corpo.revisoesSimultaneas);
    if (Number(corpo.diasAlertaSemAssinatura) >= 1) novos.diasAlertaSemAssinatura = Number(corpo.diasAlertaSemAssinatura);
    if (['auto', 'manual'].includes(corpo.modoIA)) novos.modoIA = corpo.modoIA;
    await salvarAjustes(novos);
    return rotas['GET /api/config']();
  },

  // Uma ficha por vez: abre no SOC em modo Alterar e cola. Quem salva é o médico.
  'POST /api/colar': async (corpo) => {
    const r = await revisao(corpo.revisaoId);
    if (!r || r.status !== 'aprovada') throw new Error('Só dá para colar uma revisão aprovada.');
    if (progresso.rodando) throw new Error('Espere a leitura terminar antes de colar.');
    const a = await atendimento(r.atendimento_id);
    const s = await conectar();
    try {
      const res = await colar(s, {
        linha: JSON.parse(a.linha_json),
        data: a.data,
        agenda: { codigo: a.agenda_codigo, nome: a.agenda_nome },
        campo: r.campo,
        texto: r.texto_aprovado,
        esperado: r.texto_original,
      });
      if (!res?.ok) throw new Error(res?.motivo || 'Não consegui colar no SOC.');
      await atualizarRevisao(r.id, { status: 'colada', colada_em: agora() });
      await registrar('colagem', `revisao ${r.id} campo ${r.campo}`);
      return { ok: true, aviso: 'Texto colado no SOC. Confira a ficha e clique em Salvar você mesmo.' };
    } finally {
      s.close();
    }
  },
};

// Despacha um pedido no formato do painel: método, caminho com ?consulta e corpo JSON.
export async function atender(metodo, endereco, corpo) {
  const url = new URL(endereco, 'http://auditor.local');
  const rota = rotas[`${metodo} ${url.pathname}`];
  if (!rota) return { status: 404, corpo: { erro: 'Rota não encontrada' } };
  try {
    return { status: 200, corpo: await rota(corpo || {}, url) };
  } catch (e) {
    return { status: 400, corpo: { erro: e.message } };
  }
}
