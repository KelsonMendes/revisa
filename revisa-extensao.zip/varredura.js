// Varredura de um dia: agenda(s) do dia → cada ficha → estado de ficha/licença/ASO.
// Agenda: uma escolhida, ou a busca em várias ("minhas": onde o médico já atendeu; "todas": a lista inteira do SOC),
// ficando só com as agendas que têm atendimento com o nome dele no Profissional da Agenda naquele dia.
import { conectar } from './cdp.js';
import { lerAgenda, lerFichaDaLinha, listarAssinaturas, agendasDoSoc } from './soc.js';
import { CLASSIF, documentoNoGed, estadoDocumento, estadoPrincipal, ehDoMedico, donoPelaAgenda } from './estado.js';

// do_medico: 1 = meu (Profissional da Agenda é o Kelson), 2 = não definido na agenda, 0 = outro médico.
const DONO = { meu: 1, indefinido: 2, outro: 0 };
import { salvarAtendimento, lembrarAgenda, guardarAgendasDoSoc, agendasConhecidas, registrar, agora } from './db.js';
import { config } from './config.js';
import { veu, tirarVeu } from './veu.js';

export const progresso = { rodando: false, etapa: '', feito: 0, total: 0, erro: null, aviso: null, terminou: null, agendas: [] };

function dataMenos(dataBR, dias) {
  const [d, m, a] = dataBR.split('/').map(Number);
  const x = new Date(a, m - 1, d - dias);
  return `${String(x.getDate()).padStart(2, '0')}/${String(x.getMonth() + 1).padStart(2, '0')}/${x.getFullYear()}`;
}

function dataMais(dataBR, dias) {
  return dataMenos(dataBR, -dias);
}

// Procura o dia em cada agenda da lista e devolve só as que têm atendimento do médico.
async function procurarAgendas(sessao, data, lista, fases) {
  const achadas = [];
  for (const [i, ag] of lista.entries()) {
    progresso.etapa = `Procurando seus atendimentos: agenda ${i + 1} de ${lista.length}`;
    await veu(sessao, { titulo: 'Procurando onde você atendeu', detalhe: `${ag.nome} · ${data}`, feito: i, total: lista.length, ...fases });
    try {
      const r = await lerAgenda(sessao, { data, agenda: ag });
      if (r.linhas.some((l) => donoPelaAgenda(l.profissional, config.medico) === 'meu')) achadas.push(r);
    } catch (e) {
      await registrar('erro_agenda', `${ag.nome}: ${e.message}`);
    }
  }
  return achadas;
}

export async function varrerDia({ data, agenda, busca }) {
  if (progresso.rodando) throw new Error('Já existe uma varredura em andamento.');
  Object.assign(progresso, { rodando: true, etapa: 'Conectando ao SOC', feito: 0, total: 0, erro: null, aviso: null, terminou: null, agendas: [] });
  const sessao = await conectar();
  // Fases mostradas no véu sobre o SOC.
  const etapas = ['Assinaturas', busca ? 'Procurar agendas' : 'Agenda', 'Fichas'];
  const fase = (etapa) => ({ etapas, etapa });
  try {
    progresso.etapa = 'Lendo a Assinatura Digital';
    await veu(sessao, { titulo: 'Conferindo as assinaturas', detalhe: `Assinatura Digital · a partir de ${data}`, ...fase(0) });
    const ate = dataMais(data, Math.min(config.janelaAssinaturasDias, 30));
    const de = dataMenos(data, 0);
    const ged = await listarAssinaturas(sessao, { de, ate });

    let alvos;
    if (busca) {
      // "todas": a lista atual do SOC. "minhas": onde já houve atendimento seu (se ainda não houver nenhuma, todas).
      progresso.etapa = 'Buscando a lista de agendas';
      await veu(sessao, { titulo: 'Buscando a lista de agendas', detalhe: 'A mesma do botão Trocar agenda do SOC', ...fase(1) });
      const doSoc = await agendasDoSoc(sessao);
      await guardarAgendasDoSoc(doSoc.agendas);
      const conhecidas = await agendasConhecidas();
      const minhas = conhecidas.filter((a) => a.minha);
      const lista = busca === 'minhas' && minhas.length ? minhas : conhecidas;
      alvos = await procurarAgendas(sessao, data, lista, fase(1));
      if (!alvos.length) {
        await registrar('varredura', `${data}: nenhum atendimento seu em ${lista.length} agenda(s)`);
        progresso.aviso = `Nenhum atendimento seu em ${data} nas ${lista.length} agenda(s) procuradas.`;
        return;
      }
    } else {
      progresso.etapa = 'Lendo a agenda';
      await veu(sessao, { titulo: 'Abrindo a agenda do dia', detalhe: `${agenda?.nome || 'Agenda aberta no SOC'} · ${data}`, ...fase(1) });
      alvos = [await lerAgenda(sessao, { data, agenda })];
    }
    progresso.agendas = alvos.map((a) => ({ codigo: a.agenda.codigo, nome: a.agenda.nome }));
    progresso.total = alvos.reduce((n, a) => n + a.linhas.length, 0);

    for (const { agenda: lida, linhas } of alvos) {
      await lembrarAgenda({ codigo: lida.codigo, nome: lida.nome });
      // Na busca, o SOC terminou em outra agenda: volta para esta antes de abrir as fichas dela.
      if (alvos.length > 1 || busca) await lerAgenda(sessao, { data, agenda: lida });
      for (const linha of linhas) {
        progresso.etapa = `Lendo ficha ${progresso.feito + 1} de ${progresso.total}`;
        const dono = donoPelaAgenda(linha.profissional, config.medico);
        await veu(sessao, {
          titulo: dono === 'outro' ? 'Pulando atendimento de outro médico' : 'Lendo as fichas',
          detalhe: `${linha.hora} · ${linha.tipoTexto || 'Atendimento'} · ${lida.nome}`,
          feito: progresso.feito,
          total: progresso.total,
          ...fase(2),
        });
        let ficha = null;
        let erroFicha = null;
        if (dono !== 'outro') {
          try {
            ficha = await lerFichaDaLinha(sessao, linha);
          } catch (e) {
            erroFicha = e.message;
          }
        }
        const principal = linha.tipo === '13' || linha.tipo === '21' || linha.tipo === '22' ? CLASSIF.licenca : CLASSIF.ficha;
        const gedPrincipal = documentoNoGed(ged, { paciente: linha.paciente, data, classificacao: principal });
        const gedAso = documentoNoGed(ged, { paciente: linha.paciente, data, classificacao: CLASSIF.aso });
        await salvarAtendimento({
          data,
          hora: linha.hora,
          agenda_codigo: lida.codigo,
          agenda_nome: lida.nome,
          profissional: linha.profissional || '',
          paciente: linha.paciente,
          empresa: linha.empresa,
          tipo: linha.tipo,
          tipo_texto: linha.tipoTexto,
          crecid: linha.crecid,
          cod_funcionario: linha.codFuncionario,
          seq_compromisso: linha.seqCompromisso,
          linha_json: JSON.stringify(linha),
          ficha_json: JSON.stringify(ficha ? ficha : { erro: erroFicha }),
          // Agenda sem profissional: se a ficha já existe e o médico dela é o Kelson, conta como meu.
          do_medico: dono === 'indefinido' && ficha?.existe && ehDoMedico(ficha, config.medico) ? 1 : DONO[dono],
          estado_principal: dono === 'outro' ? 'outro_medico' : erroFicha ? 'erro' : estadoPrincipal(ficha, gedPrincipal),
          estado_aso: principal === CLASSIF.ficha ? estadoDocumento(gedAso) : null,
          ged_json: JSON.stringify({ principal: gedPrincipal, aso: gedAso }),
          lido_em: agora(),
        });
        progresso.feito++;
        // Volta para a agenda do mesmo dia e local antes da próxima linha (os links da linha só funcionam lá).
        if (ficha || erroFicha) await lerAgenda(sessao, { data, agenda: lida });
      }
      await registrar('varredura', `${data} ${lida.nome}: ${linhas.length} atendimentos`);
    }
    progresso.etapa = 'Concluído';
  } catch (e) {
    progresso.erro = e.message;
    await registrar('erro_varredura', e.message);
    throw e;
  } finally {
    progresso.rodando = false;
    progresso.terminou = agora();
    await tirarVeu(sessao, progresso.erro ? {} : { mensagem: progresso.aviso || `${progresso.feito} atendimento(s) lido(s) em ${data}.` });
    sessao.close();
  }
}
