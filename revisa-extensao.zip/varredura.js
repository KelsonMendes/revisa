// Varredura de um dia: agenda(s) do dia → cada ficha → estado de ficha/licença/ASO.
// Agenda: uma escolhida, ou a busca em várias ("minhas": onde o médico já atendeu; "todas": a lista inteira do SOC),
// ficando só com as agendas que têm atendimento com o nome dele no Profissional da Agenda naquele dia.
import { conectar } from './cdp.js';
import { lerAgenda, lerFichaDaLinha, listarAssinaturas, agendasDoSoc, usuarioLogado } from './soc.js';
import { CLASSIF, documentoNoGed, estadoDocumento, estadoPrincipal, estadoAso, ehDoMedico, donoPelaAgenda } from './estado.js';

// do_medico: 1 = meu (Profissional da Agenda é o Kelson), 2 = não definido na agenda, 0 = outro médico.
const DONO = { meu: 1, indefinido: 2, outro: 0 };
import { salvarAtendimento, lembrarAgenda, guardarAgendasDoSoc, agendasConhecidas, registrar, agora } from './db.js';
import { config, salvarAjustes } from './config.js';
import { enfileirar } from './fila-ia.js';

// Campos que a IA revisa (os mesmos do painel).
const CAMPOS_IA = ['anamnese', 'observacaoComplemento', 'periciaLicenca', 'restricaoRetorno'];
import { veu, tirarVeu } from './veu.js';

export const progresso = { rodando: false, etapa: '', feito: 0, total: 0, erro: null, aviso: null, terminou: null, agendas: [] };

function dataMenos(dataBR, dias) {
  const [d, m, a] = dataBR.split('/').map(Number);
  const x = new Date(a, m - 1, d - dias);
  return `${String(x.getDate()).padStart(2, '0')}/${String(x.getMonth() + 1).padStart(2, '0')}/${x.getFullYear()}`;
}

function dataMais(dataBR, dias) {
  return dataMenos(dataBR, -dias);
}

// O médico é quem está logado no SOC: o nome vem da barra de baixo do SOC, sem ninguém digitar.
// Só quando ele escreveu outro nome nas configurações (agenda com nome diferente do login) vale o escrito.
export async function lembrarMedico(nome) {
  nome = String(nome || '').trim();
  if (!nome) return;
  const novos = {};
  if (config.medicoDoSoc !== nome) novos.medicoDoSoc = nome;
  if (!config.medicoManual && config.medico !== nome) novos.medico = nome;
  if (Object.keys(novos).length) await salvarAjustes(novos);
}

// Procura o dia em cada agenda da lista e devolve só as que têm atendimento do médico.
async function procurarAgendas(sessao, data, lista, fases) {
  const achadas = [];
  for (const [i, ag] of lista.entries()) {
    progresso.etapa = `Procurando seus atendimentos: agenda ${i + 1} de ${lista.length}`;
    await veu(sessao, { titulo: 'Procurando onde você atendeu', detalhe: `${ag.nome} · ${data}`, feito: i, total: lista.length, ...fases });
    try {
      const r = await lerAgenda(sessao, { data, agenda: ag });
      // Agenda sem a coluna "Profissional da Agenda" (local de um médico só): entra, e as fichas dizem de quem é.
      if (r.linhas.some((l) => l.semColunaProfissional || donoPelaAgenda(l.profissional, config.medico) === 'meu')) achadas.push(r);
    } catch (e) {
      await registrar('erro_agenda', `${ag.nome}: ${e.message}`);
    }
  }
  return achadas;
}

export async function varrerDia({ data, agenda, busca }) {
  if (progresso.rodando) throw new Error('Já existe uma varredura em andamento.');
  Object.assign(progresso, { rodando: true, etapa: 'Conectando ao SOC', feito: 0, total: 0, erro: null, aviso: null, resumo: null, terminou: null, agendas: [] });
  const sessao = await conectar();
  await lembrarMedico(await usuarioLogado(sessao));
  if (!config.medico) {
    progresso.rodando = false;
    sessao.close();
    throw new Error('Não consegui descobrir quem está logado no SOC. Abra a agenda no SOC e tente de novo, ou escreva seu nome nas configurações.');
  }
  // Fases mostradas no véu sobre o SOC.
  const etapas = ['Assinaturas', busca ? 'Procurar agendas' : 'Agenda', 'Fichas'];
  const fase = (etapa) => ({ etapas, etapa });
  try {
    progresso.etapa = 'Lendo a Assinatura Digital';
    await veu(sessao, { titulo: 'Conferindo as assinaturas', detalhe: `Assinatura Digital · a partir de ${data}`, ...fase(0) });
    const ate = dataMais(data, Math.min(config.janelaAssinaturasDias, 30));
    const de = dataMenos(data, 0);
    const ged = await listarAssinaturas(sessao, { de, ate });

    let alvos;
    if (busca) {
      // "todas": a lista atual do SOC. "minhas": onde já houve atendimento seu (se ainda não houver nenhuma, todas).
      progresso.etapa = 'Buscando a lista de agendas';
      await veu(sessao, { titulo: 'Buscando a lista de agendas', detalhe: 'A mesma do botão Trocar agenda do SOC', ...fase(1) });
      const doSoc = await agendasDoSoc(sessao);
      await guardarAgendasDoSoc(doSoc.agendas);
      const conhecidas = await agendasConhecidas();
      const minhas = conhecidas.filter((a) => a.minha);
      const lista = busca === 'minhas' && minhas.length ? minhas : conhecidas;
      alvos = await procurarAgendas(sessao, data, lista, fase(1));
      if (!alvos.length) {
        await registrar('varredura', `${data}: nenhum atendimento seu em ${lista.length} agenda(s)`);
        progresso.aviso = `Nenhum atendimento seu em ${data} nas ${lista.length} agenda(s) procuradas.`;
        return;
      }
    } else {
      progresso.etapa = 'Lendo a agenda';
      await veu(sessao, { titulo: 'Abrindo a agenda do dia', detalhe: `${agenda?.nome || 'Agenda aberta no SOC'} · ${data}`, ...fase(1) });
      alvos = [await lerAgenda(sessao, { data, agenda })];
    }
    progresso.agendas = alvos.map((a) => ({ codigo: a.agenda.codigo, nome: a.agenda.nome }));
    // A contagem é só das fichas que vão ser abertas (as suas e as de agenda sem profissional).
    // Atendimentos de outro médico e "Não compareceu" entram na lista sem abrir ficha e sem contar.
    const faltou = (l) => /n[ãa]o compareceu/i.test(l.atendido || '');
    const abrir = (l) => donoPelaAgenda(l.profissional, config.medico) !== 'outro' && !faltou(l);
    progresso.total = alvos.reduce((n, a) => n + a.linhas.filter(abrir).length, 0);
    const conta = { meus: 0, outros: 0, faltas: 0, semProfissional: 0 };

    for (const { agenda: lida, linhas } of alvos) {
      await lembrarAgenda({ codigo: lida.codigo, nome: lida.nome });
      // Na busca, o SOC terminou em outra agenda: volta para esta antes de abrir as fichas dela.
      if (alvos.length > 1 || busca) await lerAgenda(sessao, { data, agenda: lida });
      for (const linha of linhas) {
        const dono = donoPelaAgenda(linha.profissional, config.medico);
        const vaiAbrir = abrir(linha);
        if (vaiAbrir) {
          progresso.etapa = `Lendo a sua ficha ${progresso.feito + 1} de ${progresso.total}`;
          await veu(sessao, {
            titulo: 'Lendo as suas fichas',
            detalhe: `${linha.hora} · ${linha.tipoTexto || 'Atendimento'} · ${lida.nome}`,
            feito: progresso.feito,
            total: progresso.total,
            ...fase(2),
          });
        }
        let ficha = null;
        let erroFicha = null;
        if (vaiAbrir) {
          try {
            ficha = await lerFichaDaLinha(sessao, linha);
          } catch (e) {
            erroFicha = e.message;
          }
        }
        // Agenda sem profissional: a ficha decide (médico dela = você → meu; outro nome → outro médico; sem ficha → indefinido).
        const donoFinal = dono !== 'indefinido' || !ficha?.existe ? dono : ehDoMedico(ficha, config.medico) ? 'meu' : 'outro';
        const principal = linha.tipo === '13' || linha.tipo === '21' || linha.tipo === '22' ? CLASSIF.licenca : CLASSIF.ficha;
        const gedPrincipal = documentoNoGed(ged, { paciente: linha.paciente, data, classificacao: principal });
        const gedAso = documentoNoGed(ged, { paciente: linha.paciente, data, classificacao: CLASSIF.aso });
        await salvarAtendimento({
          data,
          hora: linha.hora,
          agenda_codigo: lida.codigo,
          agenda_nome: lida.nome,
          profissional: linha.profissional || '',
          paciente: linha.paciente,
          empresa: linha.empresa,
          tipo: linha.tipo,
          tipo_texto: linha.tipoTexto,
          crecid: linha.crecid,
          cod_funcionario: linha.codFuncionario,
          seq_compromisso: linha.seqCompromisso,
          linha_json: JSON.stringify(linha),
          ficha_json: JSON.stringify(ficha ? ficha : { erro: erroFicha }),
          // Agenda sem profissional: se a ficha já existe e o médico dela é o Kelson, conta como meu.
          do_medico: DONO[donoFinal],
          estado_principal: donoFinal === 'outro' ? 'outro_medico' : faltou(linha) ? 'nao_compareceu' : erroFicha ? 'erro' : estadoPrincipal(ficha, gedPrincipal),
          estado_aso: principal === CLASSIF.ficha && !faltou(linha)
            ? estadoAso(ficha?.documentos, gedAso)
            : null,
          ged_json: JSON.stringify({ principal: gedPrincipal, aso: gedAso }),
          lido_em: agora(),
        });
        // Revisão automática (Claude Code): a IA já começa esta ficha enquanto o app segue lendo o SOC.
        if (donoFinal === 'meu' && ficha?.existe && (config.modoIA || 'auto') !== 'manual') {
          for (const campo of CAMPOS_IA) {
            if (ficha.textos?.[campo]?.trim()) enfileirar({ data, crecid: linha.crecid, seq: linha.seqCompromisso, campo });
          }
        }
        if (vaiAbrir) progresso.feito++;
        if (donoFinal === 'outro') conta.outros++;
        else if (faltou(linha)) conta.faltas++;
        else conta.meus++;
        if (linha.semColunaProfissional && donoFinal !== 'outro') conta.semProfissional++;
        // Volta para a agenda do mesmo dia e local antes da próxima linha (os links da linha só funcionam lá).
        if (ficha || erroFicha) await lerAgenda(sessao, { data, agenda: lida });
      }
      await registrar('varredura', `${data} ${lida.nome}: ${linhas.length} atendimentos`);
    }
    // Resumo para conferir: quantos eram seus e quantos ficaram de fora.
    progresso.resumo = [
      `${conta.meus} atendimento(s) seu(s)`,
      conta.outros && `${conta.outros} de outro médico (não abertos)`,
      conta.faltas && `${conta.faltas} não compareceu`,
      conta.semProfissional && `${conta.semProfissional} em agenda sem profissional`,
    ].filter(Boolean).join(' · ');
    progresso.etapa = 'Concluído';
  } catch (e) {
    progresso.erro = e.message;
    await registrar('erro_varredura', e.message);
    throw e;
  } finally {
    progresso.rodando = false;
    progresso.terminou = agora();
    await tirarVeu(sessao, progresso.erro ? {} : { mensagem: progresso.aviso || `${data}: ${progresso.resumo || `${progresso.feito} ficha(s) lida(s)`}.` });
    sessao.close();
  }
}
