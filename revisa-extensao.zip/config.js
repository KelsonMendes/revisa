// Versão da extensão de src/config.js: padrões fixos + ajustes guardados no próprio Edge (chrome.storage.local).
export const config = {
  medico: '', // descoberto no SOC (quem está logado); ver lembrarMedico em varredura.js
  janelaAssinaturasDias: 60,
  diasAlertaSemAssinatura: 7,
  modeloClaudeCode: 'sonnet',
  revisoesSimultaneas: 2,
  modoIA: 'auto',
};

// Carrega os ajustes salvos antes de o painel usar a configuração.
export const configPronta = chrome.storage.local.get('ajustes').then(async ({ ajustes }) => {
  Object.assign(config, ajustes || {});
  // 24/10/2026: o padrão passou a ser o Sonnet (mais rápido). Uma vez só, sem desfazer uma escolha feita depois.
  if (!config.modeloPadraoSonnet) await salvarAjustes({ modeloClaudeCode: 'sonnet', modeloPadraoSonnet: true });
});

export async function salvarAjustes(novos) {
  Object.assign(config, novos);
  const { ajustes } = await chrome.storage.local.get('ajustes');
  await chrome.storage.local.set({ ajustes: { ...(ajustes || {}), ...novos } });
}
