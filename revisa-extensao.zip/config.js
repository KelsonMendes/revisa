// Versão da extensão de src/config.js: padrões fixos + ajustes guardados no próprio Edge (chrome.storage.local).
export const config = {
  medico: '', // descoberto no SOC (quem está logado); ver lembrarMedico em varredura.js
  janelaAssinaturasDias: 60,
  diasAlertaSemAssinatura: 7,
  modeloClaudeCode: 'opus',
  revisoesSimultaneas: 2,
  modoIA: 'auto',
};

// Carrega os ajustes salvos antes de o painel usar a configuração.
export const configPronta = chrome.storage.local.get('ajustes').then(({ ajustes }) => Object.assign(config, ajustes || {}));

export async function salvarAjustes(novos) {
  Object.assign(config, novos);
  const { ajustes } = await chrome.storage.local.get('ajustes');
  await chrome.storage.local.set({ ajustes: { ...(ajustes || {}), ...novos } });
}
