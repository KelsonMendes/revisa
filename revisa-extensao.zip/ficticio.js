// Dados FICTÍCIOS do revisa.: no lugar do servidor local (ou da ponte da extensão), responde com dados inventados.
// Liga na demonstração (window.__demo) ou quando o médico escolhe "ver com dados fictícios" no rodapé do painel.
// Nada aqui fala com o SOC, com a IA ou com os dados reais guardados no computador.
(() => {
  let ligado = window.__demo === true;
  try { ligado = ligado || localStorage.getItem('dadosFicticios') === '1'; } catch {}
  if (!ligado) return;
  document.documentElement.dataset.ficticio = '1';
  if (window.__demo) document.documentElement.dataset.demo = '1';
  const MEDICO = 'Kelson Mendes Correa';
  const hoje = new Date();
  const br = (d) => `${String(d.getDate()).padStart(2, '0')}/${String(d.getMonth() + 1).padStart(2, '0')}/${d.getFullYear()}`;
  const diaMenos = (n) => new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - n);
  const diasDesde = (dataBR) => { const [d, m, a] = dataBR.split('/').map(Number); return Math.floor((hoje - new Date(a, m - 1, d)) / 86400000); };
  const ESTADOS = { nao_gerada: 'Não gerada', sem_pdf: 'Gravada sem PDF', pdf_pendente: 'PDF sem assinatura', assinada: 'Assinada', nao_encontrado: 'Sem PDF encontrado', outro_medico: 'Outro médico' };

  const nomes = ['ANA PAULA FICTICIA', 'BRUNO EXEMPLO SOUZA', 'CARLA DEMONSTRACAO', 'DIEGO TESTE LIMA', 'ELISA MODELO COSTA', 'FABIO AMOSTRA ROCHA', 'GABRIELA FICTICIA ALVES',
    'HUGO EXEMPLO DIAS', 'IARA TESTE MOURA', 'JOAO DEMONSTRACAO', 'KATIA MODELO PRADO', 'LUCAS FICTICIO', 'MARINA EXEMPLO', 'NELSON AMOSTRA', 'OLGA TESTE REIS', 'PEDRO FICTICIO MELO'];
  const empresas = ['TRANSPORTES EXEMPLO LTDA', 'PREFEITURA DE EXEMPLO', 'DISTRIBUIDORA MODELO', 'CONSTRUTORA AMOSTRA'];
  const tipos = ['Periódico', 'Periódico', 'Periódico', 'Admissional', 'Retorno ao trabalho', 'Perícia'];
  const anamneses = [
    'PACIENTE NEGA QUEIXAS. SEM ALTERACOES. APTO.',
    'REFERE DOR LOMBAR HA 2 MESES. TRABALHA COMO MOTORISTA. NEGA OUTRAS QUEIXAS.',
    'ASSINTOMATICO. EXAMES SEM ALTERACOES.',
    'QUEIXA DE ZUMBIDO EVENTUAL. EXPOSTO A RUIDO NA OFICINA. AUDIOMETRIA PENDENTE.',
  ];

  let seq = 0;
  const atendimentos = [];
  const revisoes = [];
  for (let i = 13; i >= 0; i--) {
    const d = diaMenos(i);
    if ([0, 6].includes(d.getDay())) continue;
    const qtd = 5 + ((i * 7) % 6);
    for (let k = 0; k < qtd; k++) {
      const id = ++seq;
      const outro = k % 7 === 6;
      const recente = i <= 2;
      const est = outro ? 'outro_medico' : recente ? ['assinada', 'pdf_pendente', 'sem_pdf', 'nao_gerada', 'assinada'][k % 5] : (k % 5 === 1 ? 'pdf_pendente' : k % 9 === 2 ? 'sem_pdf' : 'assinada');
      const tipo = tipos[(id + k) % tipos.length];
      const pericia = tipo === 'Perícia';
      atendimentos.push({
        id, data: br(d), hora: `${String(7 + Math.floor(k / 2)).padStart(2, '0')}:${k % 2 ? '30' : '00'}`, local: i % 2 ? 'Bom Sucesso' : 'Tito Divinópolis', agendaCodigo: i % 2 ? '1001' : '1002',
        podeAbrir: true, paciente: nomes[id % nomes.length], empresa: empresas[id % empresas.length], tipo,
        doMedico: outro ? 0 : (k === 3 && recente ? 2 : 1), profissional: outro ? 'OUTRA MEDICA EXEMPLO' : (k === 3 && recente ? '' : 'KELSON MENDES CORREA'),
        medico: outro ? 'OUTRA MEDICA EXEMPLO' : 'KELSON MENDES CORREA',
        estadoPrincipal: est, estadoPrincipalTexto: ESTADOS[est], documentoPrincipal: pericia ? 'Licença médica' : 'Ficha clínica',
        estadoAso: pericia || outro ? null : (est === 'assinada' ? 'assinada' : 'nao_encontrado'), estadoAsoTexto: null,
        diasDesde: diasDesde(br(d)), alerta: false, erro: null,
        campos: est === 'nao_gerada' || outro ? [] : pericia
          ? [{ campo: 'periciaLicenca', rotulo: 'Perícia', texto: 'ATESTADO DE 15 DIAS. CID M54.5. LIBERADO.' }]
          : [{ campo: 'anamnese', rotulo: 'Anamnese', texto: anamneses[id % anamneses.length] }, { campo: 'observacaoComplemento', rotulo: 'Observações', texto: '' }],
        revisoes: [],
      });
    }
  }
  for (const a of atendimentos) {
    a.estadoAsoTexto = a.estadoAso ? ESTADOS[a.estadoAso] : null;
    a.alerta = a.estadoPrincipal !== 'assinada' && a.estadoPrincipal !== 'outro_medico' && a.diasDesde >= 7;
  }

  // Revisões prontas de exemplo, nos últimos dias.
  const RES = (texto) => {
    const curto = texto.length < 60;
    return {
      resumo: curto ? 'Anamnese muito curta: não mostra anamnese ocupacional nem sustenta o parecer.' : 'Registro razoável, mas faltam riscos da função e conduta para a queixa.',
      nota_completude: curto ? 2 : 6,
      achados: [
        { item: 'B. Riscos do PGR', gravidade: 'alta', trecho: '', sugestao: 'Citar os riscos da função e relacionar às queixas pesquisadas (NR-7 7.5.17).' },
        { item: 'B. Anamnese ocupacional', gravidade: curto ? 'alta' : 'media', trecho: texto.split('.')[0], sugestao: 'Trocar a negativa genérica por negativas dirigidas aos riscos (audição, coluna, sono).' },
        { item: 'D. Conclusão / parecer', gravidade: 'media', trecho: curto ? 'APTO' : '', sugestao: 'O parecer fica na conclusão/ASO, não na anamnese.' },
      ],
      alteracoes: curto ? [
        { de: 'PACIENTE NEGA QUEIXAS.', para: 'Trabalhador nega queixas auditivas, osteomusculares e de sono.', motivo: 'Negativa genérica não demonstra anamnese dirigida aos riscos da função (checklist B).' },
        { de: 'SEM ALTERACOES.', para: '[COMPLETAR: riscos do PGR da função]', motivo: 'Faltam os riscos do PGR/PCMSO da função (NR-7 7.5.17).' },
        { de: 'APTO.', para: '', motivo: 'O parecer não pertence à anamnese; fica na conclusão e no ASO.' },
      ] : [
        { de: '', para: 'Exposição a vibração de corpo inteiro (PGR).', motivo: 'Relacionar a queixa aos riscos da função.' },
        { de: '', para: 'Medicações: dipirona [COMPLETAR: posologia].', motivo: 'Medicação citada sem posologia.' },
        { de: '', para: 'Apto.', motivo: 'O parecer fica sempre na última linha.' },
      ],
      negativas_funcao: [
        { item: 'Crises convulsivas ou epilepsia', frase: 'crises convulsivas ou epilepsia' },
        { item: 'Desmaios ou tonturas', frase: 'desmaios ou tonturas' },
        { item: 'Remédios que dão sono', frase: 'uso de medicamentos que causem sonolência' },
        { item: 'Distúrbios do sono', frase: 'distúrbios do sono' },
      ],
      exame_fisico_alteracoes: curto ? [] : ['dor à palpação de região lombar'],
      confirmacoes: [
        { pergunta: 'Perguntou se o calendário vacinal está atualizado?', texto: 'Imunização: refere calendário vacinal atualizado.' },
        { pergunta: 'Perguntou se os exames preventivos estão em dia?', texto: 'Rastreamento: refere exames preventivos em dia.' },
      ],
      ajustes_questionario: curto ? [] : [{ grupo: 'VOCÊ TEM OU JÁ TEVE', item: 'Dor nas costas', de: 'Não', para: 'Sim', motivo: 'o texto registra lombalgia' }],
      condutas: curto ? [] : [
        { titulo: 'Lombalgia', texto: 'Oriento alongamento e pausas durante a jornada e a procurar profissional de saúde se a dor lombar persistir.', fonte: 'guia' },
        { titulo: 'Sobrepeso', texto: 'Oriento controle do peso, alimentação equilibrada e atividade física regular.', fonte: 'guia' },
      ],
    };
  };
  const SUGERIDO = (texto) => texto.length < 60
    ? 'Trabalhador nega queixas auditivas, osteomusculares e de sono. [COMPLETAR: riscos do PGR da função]'
    : `${texto} Exposição a vibração de corpo inteiro (PGR).
Medicações: dipirona [COMPLETAR: posologia].

Apto.`;

  let revSeq = 0;
  const criarRevisao = (a, campo, status = 'sugerida') => {
    const c = a.campos.find((x) => x.campo === campo);
    const r = { id: ++revSeq, atendimento_id: a.id, campo, texto_original: c.texto, resultado: RES(c.texto), texto_sugerido: SUGERIDO(c.texto),
      texto_aprovado: status === 'sugerida' ? null : SUGERIDO(c.texto).replace(/\[COMPLETAR:[^\]]*\]/g, 'Riscos: ruído e vibração.'), status, criada_em: new Date().toISOString() };
    a.revisoes.unshift(r);
    revisoes.push(r);
    return r;
  };
  atendimentos.filter((a) => a.doMedico && a.campos[0]?.texto).slice(-26).forEach((a, i) => criarRevisao(a, a.campos[0].campo, ['colada', 'colada', 'aprovada', 'colada', 'sugerida'][i % 5]));
  // Mantém os dois últimos dias sem revisão, para dar o que testar.
  for (const a of atendimentos.filter((x) => x.diasDesde <= 1)) { a.revisoes = []; }

  const agendas = [{ codigo: '1001', nome: 'Bom Sucesso', minha: true }, { codigo: '1002', nome: 'Tito Divinópolis', minha: true }];
  // O que o botão "Trocar agenda" do SOC listaria (fictício).
  const agendasDoSoc = [{ codigo: '1003', nome: 'Conceição do Pará' }, { codigo: '1004', nome: 'Dra. Exemplo · Divinópolis' }, { codigo: '1005', nome: 'Exames complementares' }];
  const config = { medico: MEDICO, medicoDoSoc: MEDICO, medicoManual: false, revisor: '', tourVisto: false,
    exameFisicoPadrao: 'Exame físico: bom estado geral, lúcido e orientado. Ausculta cardíaca: ritmo regular em dois tempos, bulhas normofonéticas, sem sopros. Ausculta pulmonar: murmúrio vesicular presente e simétrico, sem ruídos adventícios. Membros superiores: força muscular preservada contra resistência; mobilidade ativa e passiva dos ombros preservada e indolor; teste de Apley negativo; punhos com sinal de Tinel e teste de Phalen negativos; teste de Finkelstein negativo. Coluna: percussão das apófises espinhosas indolor. Membros inferiores: força muscular preservada em flexão e extensão contra resistência; mobilidade de tornozelos e pés preservada. Questionado sobre dor na coluna: nega. Sem outras alterações ao exame.', modeloClaudeCode: 'opus', revisoesSimultaneas: 2, diasAlertaSemAssinatura: 7, modoIA: 'auto' };
  const progresso = { rodando: false, etapa: '', feito: 0, total: 0, erro: null, terminou: new Date(Date.now() - 3600e3).toISOString() };
  const espera = (ms) => new Promise((r) => setTimeout(r, ms));
  const revisaoPorId = (id) => revisoes.find((r) => r.id === id);
  const atendimentoPorId = (id) => atendimentos.find((a) => a.id === id);

  const rotas = {
    'GET /api/estado': () => ({ edgeAberto: true, soc: { logado: true }, progresso, agendas, medico: config.medico }),
    'POST /api/limpar': (c) => {
      const antes = atendimentos.length;
      for (let i = atendimentos.length - 1; i >= 0; i--) if (c.tudo || atendimentos[i].data === c.data) atendimentos.splice(i, 1);
      return { apagados: antes - atendimentos.length };
    },
    'GET /api/atendimentos': (q) => atendimentos.filter((a) => a.data === q.get('data')),
    'GET /api/config': () => config,
    'POST /api/config': (c) => {
      Object.assign(config, c);
      if (c.revisor) config.modoIA = c.revisor === 'claude-code' ? 'auto' : 'manual';
      return config;
    },
    'GET /api/ia/ponte': () => ({ ok: true }),
    'POST /api/agenda/detectar': () => agendas[0],
    'POST /api/agendas/buscar': async () => {
      await espera(900);
      for (const a of agendasDoSoc) if (!agendas.some((x) => x.codigo === a.codigo)) agendas.push({ ...a, minha: false });
      return { agendas, reconheceu: true };
    },
    'GET /api/pendencias': (q) => {
      const dias = Number(q.get('dias') || 30);
      const lista = atendimentos.filter((a) => a.doMedico && a.diasDesde <= dias && (!['assinada', 'outro_medico'].includes(a.estadoPrincipal) || (a.estadoAso && a.estadoAso !== 'assinada')))
        .sort((x, y) => y.diasDesde - x.diasDesde);
      return { lista, diasLidos: new Set(atendimentos.filter((a) => a.diasDesde <= dias).map((a) => a.data)).size, dias };
    },
    'GET /api/painel': () => {
      const meus = atendimentos.filter((a) => a.doMedico);
      const grupo = (a) => (a.estadoPrincipal === 'assinada' ? 'assinada' : a.estadoPrincipal === 'nao_gerada' ? 'nao_gerada' : 'pendente');
      const dias = [];
      for (let i = 13; i >= 0; i--) {
        const d = diaMenos(i); const doDia = meus.filter((a) => a.data === br(d));
        dias.push({ data: br(d), semana: d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', ''), lido: doDia.length > 0,
          assinada: doDia.filter((a) => grupo(a) === 'assinada').length, pendente: doDia.filter((a) => grupo(a) === 'pendente').length, nao_gerada: doDia.filter((a) => grupo(a) === 'nao_gerada').length });
      }
      const abertos = meus.filter((a) => a.estadoPrincipal !== 'assinada');
      const faixa = (min, max) => abertos.filter((a) => a.diasDesde >= min && a.diasDesde <= max).length;
      const notas = revisoes.map((r) => r.resultado.nota_completude);
      const cont = new Map();
      for (const r of revisoes) for (const ach of r.resultado.achados) { const c = cont.get(ach.item) || { item: ach.item, total: 0, altas: 0 }; c.total++; if (ach.gravidade === 'alta') c.altas++; cont.set(ach.item, c); }
      return { hoje: br(hoje), medico: config.medico, dias, atraso: { recentes: faixa(0, 6), semana: faixa(7, 14), antigas: faixa(15, 9999) }, totalAbertos: abertos.length,
        fila: { aguardando: revisoes.filter((r) => r.status === 'sugerida').length, aprovadas: revisoes.filter((r) => r.status === 'aprovada').length, coladas30: revisoes.filter((r) => r.status === 'colada').length },
        qualidade: { revisoes: revisoes.length, notaMedia: notas.reduce((x, y) => x + y, 0) / Math.max(1, notas.length), distribuicao: [0, 1, 2, 3, 4].map((i) => notas.filter((n) => Math.min(4, Math.floor(n / 2)) === i).length),
          achados: [...cont.values()].sort((x, y) => y.total - x.total).slice(0, 5) },
        ultimaLeitura: { data: br(diaMenos(0)), local: 'Tito Divinópolis', quando: new Date().toISOString() } };
    },
    'POST /api/revisar': async (c) => {
      await espera(1800);
      const a = atendimentoPorId(c.atendimentoId); criarRevisao(a, c.campo); return a;
    },
    'POST /api/aprovar': (c) => {
      if (/\[COMPLETAR/i.test(c.texto)) throw new Error('Ainda há marcadores [COMPLETAR: ...] no texto. Preencha antes de aprovar.');
      const r = revisaoPorId(c.revisaoId); r.texto_aprovado = c.texto; r.status = 'aprovada'; return atendimentoPorId(r.atendimento_id);
    },
    'POST /api/descartar': (c) => { const r = revisaoPorId(c.revisaoId); r.status = 'descartada'; return atendimentoPorId(r.atendimento_id); },
    'POST /api/colar': async (c) => { await espera(1200); revisaoPorId(c.revisaoId).status = 'colada'; return { ok: true, aviso: 'Demonstração: no app de verdade, a ficha abriria no Edge em modo Alterar com o texto colado. Você confere e salva.' }; },
    'POST /api/abrir': async () => { await espera(900); return { ok: true }; },
    'POST /api/manual/pedido': (c) => {
      const alvos = atendimentos.filter((a) => a.data === c.data && a.doMedico && a.campos.some((x) => x.texto) && !a.revisoes.length);
      if (!alvos.length) throw new Error('Nada novo para revisar neste dia.');
      return { quantidade: alvos.length, texto: `Demonstração: no app de verdade, este é o pedido com ${alvos.length} registro(s) anonimizados para colar no claude.ai.` };
    },
    'POST /api/manual/resposta': () => {
      // Na demonstração qualquer texto colado vale: cria revisões de exemplo para os registros do dia aberto.
      const alvos = atendimentos.filter((a) => a.diasDesde <= 1 && a.doMedico && a.campos[0]?.texto && !a.revisoes.length);
      alvos.forEach((a) => criarRevisao(a, a.campos[0].campo));
      return { feitas: alvos.length, ignoradas: [] };
    },
    'POST /api/varrer': (c) => {
      // Simula a leitura: o dia escolhido ganha atendimentos de exemplo aos poucos.
      const ja = atendimentos.filter((a) => a.data === c.data);
      const escolhida = agendas.find((a) => a.codigo === c.agendaCodigo) || agendas[0];
      Object.assign(progresso, { rodando: true, etapa: 'Lendo a Assinatura Digital', feito: 0, total: 0, erro: null });
      (async () => {
        await espera(1200);
        const total = ja.length || 6;
        progresso.total = total;
        for (let k = 0; k < total; k++) {
          progresso.etapa = `Lendo ficha ${k + 1} de ${total}`;
          await espera(700);
          if (!ja.length) {
            const id = ++seq;
            atendimentos.push({ id, data: c.data, hora: `${String(7 + k).padStart(2, '0')}:00`, local: escolhida.nome, agendaCodigo: escolhida.codigo, podeAbrir: true, paciente: nomes[id % nomes.length], empresa: empresas[k % 4],
              tipo: 'Periódico', doMedico: 1, profissional: 'KELSON MENDES CORREA', medico: 'KELSON MENDES CORREA', estadoPrincipal: ['assinada', 'pdf_pendente', 'nao_gerada'][k % 3],
              estadoPrincipalTexto: ESTADOS[['assinada', 'pdf_pendente', 'nao_gerada'][k % 3]], documentoPrincipal: 'Ficha clínica', estadoAso: 'nao_encontrado', estadoAsoTexto: ESTADOS.nao_encontrado,
              diasDesde: diasDesde(c.data), alerta: false, erro: null, campos: k % 3 === 2 ? [] : [{ campo: 'anamnese', rotulo: 'Anamnese', texto: anamneses[k % 4] }], revisoes: [] });
          }
          progresso.feito = k + 1;
        }
        Object.assign(progresso, { rodando: false, etapa: 'Concluído', terminou: new Date().toISOString() });
      })();
      return { iniciado: true };
    },
  };

  const fetchOriginal = window.fetch.bind(window);
  window.fetch = async (url, opcoes = {}) => {
    const u = new URL(url, location.href);
    if (!u.pathname.includes('/api/')) return fetchOriginal(url, opcoes);
    const rota = rotas[`${(opcoes.method || 'GET').toUpperCase()} ${u.pathname.slice(u.pathname.indexOf('/api/'))}`];
    const json = (status, corpo) => new Response(JSON.stringify(corpo), { status, headers: { 'Content-Type': 'application/json' } });
    if (!rota) return json(404, { erro: 'Rota não existe na demonstração' });
    try {
      const corpo = opcoes.body ? JSON.parse(opcoes.body) : u.searchParams;
      return json(200, await rota(corpo));
    } catch (e) {
      return json(400, { erro: e.message });
    }
  };
  // A moldura da demonstração não mostra caixas de confirmação: lá elas valem como "sim".
  if (window.__demo) window.confirm = () => true;
})();
