// No painel da extensão, os pedidos que iriam para o servidor local (/api/...) são atendidos aqui mesmo.
import { atender } from './rotas.js';
import { configPronta } from './config.js';

const fetchOriginal = window.fetch.bind(window);
window.fetch = async (url, opcoes = {}) => {
  const u = new URL(url, location.href);
  if (!u.pathname.startsWith('/api/')) return fetchOriginal(url, opcoes);
  await configPronta;
  const r = await atender((opcoes.method || 'GET').toUpperCase(), u.pathname + u.search, opcoes.body ? JSON.parse(opcoes.body) : {});
  return new Response(JSON.stringify(r.corpo), { status: r.status, headers: { 'Content-Type': 'application/json' } });
};
