// Textos enviados à IA e leitura das respostas. Puro (sem Node): usado pelo app local e pela extensão.

export function montarSistema(checklist) {
  return `Você revisa registros de medicina do trabalho e perícia médica escritos por um médico do trabalho no sistema SOC, para protegê-lo juridicamente e melhorar a qualidade do prontuário.

Regras inegociáveis:
- Nunca invente dado clínico, sintoma, exame, resultado, sinal vital, CID ou conclusão. Se algo necessário não está no registro, escreva no texto sugerido um marcador [COMPLETAR: o que falta] para o médico preencher.
- Preserve todos os fatos do texto original. Você pode reorganizar, corrigir português, padronizar termos e explicitar negativas que já estejam implícitas no original.
- Não altere o parecer (apto/inapto) nem dias de afastamento; se achar incoerente, aponte como achado de gravidade alta.
- O paciente aparece como [PACIENTE]; mantenha esse marcador exatamente assim. Outros nomes aparecem como [NOME]/[MEDICO].
- Escreva em português do Brasil, linguagem técnica e objetiva, sem juízo de valor sobre o trabalhador.
- O texto sugerido substitui apenas o campo informado; não acrescente cabeçalho, assinatura ou data.
- O contexto pode trazer o questionário da ficha. Pergunta marcada como "nada marcado" quer dizer que o paciente negou: registre isso no texto sugerido com "nega" (ex.: "Antecedentes familiares: nega."), se o texto ainda não disser. Não tire nenhuma outra conclusão do questionário.
- O contexto pode trazer "sinaisVitais" (pressão, pulso, peso, altura, IMC…), preenchidos em campos próprios da ficha, fora deste texto. Se o texto ainda não os registra, inclua-os no texto sugerido numa linha "Sinais vitais e medidas: …", copiando os valores exatamente. Não invente nem estime valores que não vieram.
- Em "exame_fisico_alteracoes", liste as alterações de exame físico que a ficha já registra (no texto, em "exameFisico" ou no questionário), em frases curtas. Lista vazia se não houver nenhuma. Não escreva exame físico no texto sugerido por conta própria: o médico inclui o exame padrão dele quando confirmar que fez.
- Em "negativas_funcao", liste as perguntas de triagem que costumam ser feitas para o cargo e os riscos do trabalhador (ex.: motorista ou trabalho em altura: crises convulsivas, epilepsia, desmaios, tonturas, uso de remédios que dão sono, distúrbios do sono, alterações visuais) e que o texto NÃO registra. NUNCA coloque essas negativas no texto sugerido: o médico só confirma as que de fato perguntou. Em "frase", escreva só o que vem depois de "nega" (ex.: "crises convulsivas ou epilepsia"). Lista vazia se nada se aplica.
- Em "alteracoes", liste cada mudança feita: "de" e "para" devem ser cópias exatas de trechos curtos (uma frase ou menos) do texto original e do sugerido, para que o médico veja o motivo de cada uma.

Use este checklist como rubrica (aplique só os itens pertinentes ao tipo de registro):

${checklist}`;
}

export function montarPedido({ campo, tipoExame, contexto, texto }) {
  return [
    `Tipo de registro: ${tipoExame}`,
    `Campo a revisar: ${campo}`,
    `Contexto (não revisar, só para entender): ${JSON.stringify(contexto)}`,
    '',
    'Texto atual do campo:',
    '<<<',
    texto || '(vazio)',
    '>>>',
  ].join('\n');
}

const FORMATO = `{
  "id": "o mesmo id do registro",
  "resumo": "duas ou três frases sobre a qualidade do registro",
  "nota_completude": 0 a 10 (inteiro),
  "achados": [{ "item": "item do checklist", "gravidade": "alta" | "media" | "baixa", "trecho": "trecho do original ou \\"\\"", "sugestao": "..." }],
  "texto_sugerido": "texto revisado do campo, pronto para colar",
  "alteracoes": [{ "de": "trecho exato do original ou \\"\\"", "para": "trecho exato do sugerido", "motivo": "por que mudou, em uma frase" }],
  "negativas_funcao": [{ "item": "pergunta de triagem para a função", "frase": "o que vem depois de 'nega'" }],
  "exame_fisico_alteracoes": ["alteração de exame físico já registrada na ficha"]
}`;

// Modo manual (copiar e colar em qualquer IA: ChatGPT, Gemini, Claude, Copilot…): um pedido só com vários registros, para copiar e colar numa conversa.
export function montarPedidoLote(checklist, itens) {
  const blocos = itens.map((it) => [`### Registro ${it.id}`, montarPedido(it)].join('\n')).join('\n\n');
  return `${montarSistema(checklist)}

---

Revise cada registro abaixo. Responda SOMENTE com um bloco \`\`\`json contendo uma lista, um objeto por registro, neste formato:
${FORMATO}

${blocos}`;
}

const GRAVIDADES = ['alta', 'media', 'baixa'];

// Confere o formato de uma revisão vinda da IA. Devolve a revisão limpa ou lança erro dizendo o que faltou.
export function validarRevisao(r) {
  const erro = (m) => { throw new Error(`Resposta da IA fora do formato: ${m}`); };
  if (!r || typeof r !== 'object') erro('não é um objeto');
  if (typeof r.resumo !== 'string') erro('falta "resumo"');
  const nota = Number(r.nota_completude);
  if (!Number.isFinite(nota) || nota < 0 || nota > 10) erro('"nota_completude" precisa ser de 0 a 10');
  if (!Array.isArray(r.achados)) erro('falta a lista "achados"');
  if (typeof r.texto_sugerido !== 'string') erro('falta "texto_sugerido"');
  return {
    resumo: r.resumo,
    nota_completude: Math.round(nota),
    achados: r.achados.map((a) => ({
      item: String(a?.item ?? ''),
      gravidade: GRAVIDADES.includes(a?.gravidade) ? a.gravidade : 'media',
      trecho: String(a?.trecho ?? ''),
      sugestao: String(a?.sugestao ?? ''),
    })),
    texto_sugerido: r.texto_sugerido,
    alteracoes: (Array.isArray(r.alteracoes) ? r.alteracoes : []).map((a) => ({
      de: String(a?.de ?? ''), para: String(a?.para ?? ''), motivo: String(a?.motivo ?? ''),
    })),
    negativas_funcao: (Array.isArray(r.negativas_funcao) ? r.negativas_funcao : [])
      .map((n) => ({ item: String(n?.item ?? '').trim(), frase: String(n?.frase ?? '').trim().replace(/^nega\s+/i, '') }))
      .filter((n) => n.item && n.frase),
    exame_fisico_alteracoes: (Array.isArray(r.exame_fisico_alteracoes) ? r.exame_fisico_alteracoes : []).map((x) => String(x ?? '').trim()).filter(Boolean),
  };
}

// Lê a resposta colada da IA escolhida: aceita o bloco ```json, uma lista solta ou um objeto só.
export function lerRespostaLote(texto) {
  const t = String(texto || '').trim();
  const bloco = t.match(/```(?:json)?\s*([\s\S]*?)```/i);
  let bruto = bloco ? bloco[1] : t;
  if (!bloco) {
    const ini = Math.min(...['[', '{'].map((c) => bruto.indexOf(c)).filter((i) => i >= 0));
    if (Number.isFinite(ini)) bruto = bruto.slice(ini);
  }
  let dados;
  try {
    dados = JSON.parse(bruto);
  } catch {
    throw new Error('Não consegui ler a resposta. Copie a resposta inteira da IA, incluindo o bloco ```json.');
  }
  const lista = Array.isArray(dados) ? dados : [dados];
  return lista.map((r) => ({ id: String(r?.id ?? ''), ...validarRevisao(r) }));
}
