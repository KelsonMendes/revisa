// Cruza o que a ficha mostra com a lista da Assinatura Digital para dar o estado de cada documento.
// Classificações do GED (tela 797): 8 = Ficha Clínica, 15 = Licença Médica, 6 = ASO.

export const CLASSIF = { ficha: 8, licenca: 15, aso: 6 };

export const ESTADOS = {
  nao_gerada: 'Não gerada',
  sem_pdf: 'Gravada sem PDF',
  pdf_pendente: 'PDF sem assinatura',
  assinada: 'Assinada',
  nao_encontrado: 'Sem PDF encontrado',
  outro_medico: 'Outro médico',
  nao_compareceu: 'Não compareceu',
};

export function normalizar(s) {
  return String(s || '')
    .normalize('NFD').replace(/[̀-ͯ]/g, '')
    .toUpperCase().replace(/[^A-Z0-9/ ]/g, ' ').replace(/\s+/g, ' ').trim();
}

// O "Nome do SOCGED" segue o padrão NOME_dd/mm/aaaa_Termo; às vezes vem abreviado com "...".
function casa(doc, paciente, data) {
  const nome = normalizar(doc.nomeGed.split('_')[0].replace(/\.\.\.$/, ''));
  const alvo = normalizar(paciente);
  if (!nome || !alvo) return false;
  const nomeOk = alvo.startsWith(nome) || nome.startsWith(alvo);
  const dataGed = (doc.nomeGed.match(/\d{2}\/\d{2}\/\d{4}/) || [doc.dataUpload])[0];
  return nomeOk && dataGed === data;
}

export function documentoNoGed(docs, { paciente, data, classificacao }) {
  const achados = docs.filter((d) => d.classificacao === classificacao && casa(d, paciente, data));
  if (!achados.length) return null;
  return achados.find((d) => d.assinado) || achados[0];
}

export function estadoDocumento(ged) {
  if (!ged) return 'nao_encontrado';
  return ged.assinado || ged.assinaturas >= ged.assinaturasNecessarias ? 'assinada' : 'pdf_pendente';
}

// Estado do documento principal (ficha do cad009 ou licença do cad016) a partir da própria ficha + GED.
export function estadoPrincipal(ficha, ged) {
  if (!ficha || !ficha.existe) return 'nao_gerada';
  if (ged) return estadoDocumento(ged);
  return ficha.fichaPossuiGed ? 'pdf_pendente' : 'sem_pdf';
}

// Regra do Kelson: o "Profissional da Agenda" diz quem atendeu.
// Meu nome → meu; vazio → provavelmente meu (não definido); outro nome → de outro médico.
export function donoPelaAgenda(profissional, medico) {
  const p = normalizar(profissional);
  if (!p) return 'indefinido';
  const primeiroNome = normalizar(medico).split(' ')[0];
  return p.split(' ').includes(primeiroNome) ? 'meu' : 'outro';
}

export function ehDoMedico(ficha, medico) {
  if (!ficha) return false;
  const alvo = normalizar(medico);
  return [ficha.medico, ficha.incluidoPor].some((n) => normalizar(n).includes(alvo));
}

export function diasDesde(dataBR, hoje = new Date()) {
  const [d, m, a] = dataBR.split('/').map(Number);
  return Math.floor((hoje - new Date(a, m - 1, d)) / 86400000);
}
