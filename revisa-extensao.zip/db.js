// Versão da extensão de src/db.js: os mesmos dados, guardados no IndexedDB do Edge deste computador.
// Mesmos nomes de função do original (aqui todas assíncronas).

const NOME = 'auditor-soc';
let conexao = null;

function abrir() {
  if (conexao) return conexao;
  conexao = new Promise((ok, erro) => {
    const req = indexedDB.open(NOME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      const at = db.createObjectStore('atendimento', { keyPath: 'id', autoIncrement: true });
      at.createIndex('chave', 'chave', { unique: true });
      at.createIndex('data', 'data');
      const rv = db.createObjectStore('revisao', { keyPath: 'id', autoIncrement: true });
      rv.createIndex('atendimento_id', 'atendimento_id');
      db.createObjectStore('agenda_local', { keyPath: 'codigo' });
      db.createObjectStore('log', { keyPath: 'id', autoIncrement: true });
    };
    req.onsuccess = () => ok(req.result);
    req.onerror = () => erro(req.error);
  });
  return conexao;
}

const prometer = (req) => new Promise((ok, erro) => { req.onsuccess = () => ok(req.result); req.onerror = () => erro(req.error); });

async function loja(nome, modo = 'readonly') {
  return (await abrir()).transaction(nome, modo).objectStore(nome);
}

export const agora = () => new Date().toISOString();

export async function registrar(acao, detalhe = '') {
  await prometer((await loja('log', 'readwrite')).add({ quando: agora(), acao, detalhe: String(detalhe).slice(0, 500) }));
}

export async function salvarAtendimento(a) {
  const chave = `${a.data}|${a.crecid}|${a.seq_compromisso}`;
  const s = await loja('atendimento', 'readwrite');
  const existente = await prometer(s.index('chave').get(chave));
  await prometer(s.put({ ...(existente || {}), ...a, chave, ...(existente ? { id: existente.id } : {}) }));
}

// Lixeira do painel: apaga o que foi lido (atendimentos e as revisões deles) de um dia, ou de todos.
// Não mexe nos ajustes nem na lista de agendas. Devolve quantos atendimentos saíram.
export async function apagarLidos(data) {
  const banco = await abrir();
  return new Promise((ok, erro) => {
    const tx = banco.transaction(['atendimento', 'revisao'], 'readwrite');
    const at = tx.objectStore('atendimento');
    const rv = tx.objectStore('revisao');
    let n = 0;
    const req = data ? at.index('data').openCursor(IDBKeyRange.only(data)) : at.openCursor();
    req.onsuccess = () => {
      const c = req.result;
      if (!c) return;
      const id = c.value.id;
      const revs = rv.index('atendimento_id').openCursor(IDBKeyRange.only(id));
      revs.onsuccess = () => { const r = revs.result; if (r) { r.delete(); r.continue(); } };
      c.delete();
      n++;
      c.continue();
    };
    tx.oncomplete = () => ok(n);
    tx.onerror = () => erro(tx.error);
  });
}

export async function atendimentosDoDia(data) {
  const lista = await prometer((await loja('atendimento')).index('data').getAll(data));
  return lista.sort((x, y) => String(x.hora).localeCompare(String(y.hora)));
}

export async function atendimentosDesde(dias) {
  const limite = Date.now() - dias * 86400000;
  const todos = await prometer((await loja('atendimento')).getAll());
  return todos.filter((a) => {
    const [d, m, y] = a.data.split('/').map(Number);
    return new Date(y, m - 1, d).getTime() >= limite;
  });
}

export async function atendimento(id) {
  return prometer((await loja('atendimento')).get(Number(id)));
}

export async function revisoesDoAtendimento(id) {
  const lista = await prometer((await loja('revisao')).index('atendimento_id').getAll(Number(id)));
  return lista.sort((x, y) => y.id - x.id);
}

export async function revisao(id) {
  return prometer((await loja('revisao')).get(Number(id)));
}

export async function salvarRevisao(r) {
  return prometer((await loja('revisao', 'readwrite')).add({ ...r }));
}

const COLUNAS_REVISAO = ['texto_aprovado', 'status', 'aprovada_em', 'colada_em'];

export async function atualizarRevisao(id, campos) {
  const s = await loja('revisao', 'readwrite');
  const r = await prometer(s.get(Number(id)));
  if (!r) return;
  for (const k of COLUNAS_REVISAO) if (k in campos) r[k] = campos[k];
  await prometer(s.put(r));
}

export async function todasRevisoes() {
  return prometer((await loja('revisao')).getAll());
}

export async function lembrarAgenda({ codigo, nome }) {
  await prometer((await loja('agenda_local', 'readwrite')).put({ codigo, nome, usada_em: agora() }));
}

// Lista vinda do botão "Trocar agenda" do SOC: guarda as novas e atualiza nomes, sem mexer em "usada_em".
export async function guardarAgendasDoSoc(lista) {
  const s = await loja('agenda_local', 'readwrite');
  for (const a of lista) {
    const existente = await prometer(s.get(a.codigo));
    await prometer(s.put({ usada_em: null, ...(existente || {}), codigo: a.codigo, nome: a.nome }));
  }
}

// "minha": já houve atendimento do médico nessa agenda (é onde a busca "nas minhas agendas" procura).
export async function agendasConhecidas() {
  const lista = await prometer((await loja('agenda_local')).getAll());
  const minhas = new Set((await prometer((await loja('atendimento')).getAll())).filter((t) => t.do_medico === 1).map((t) => t.agenda_codigo));
  return lista.map((a) => ({ ...a, minha: minhas.has(a.codigo) }))
    .sort((x, y) => (!x.usada_em - !y.usada_em) || String(y.usada_em).localeCompare(String(x.usada_em)) || x.nome.localeCompare(y.nome));
}
