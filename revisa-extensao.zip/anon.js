// Pseudonimização antes de mandar texto para a IA. Os dados reais ficam só no banco local.
// Troca: nome do paciente (completo e cada parte), CPF, RG, telefone, e-mail, matrícula,
// nomes de empresa/unidade e de médicos citados. Idade, sexo, cargo e setor seguem (são necessários para a análise).

const escapar = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const PREPOSICOES = new Set(['DA', 'DE', 'DO', 'DAS', 'DOS', 'E']);

function partesDoNome(nome) {
  return String(nome || '')
    .split(/\s+/)
    .filter((p) => p.length >= 3 && !PREPOSICOES.has(p.toUpperCase()));
}

export function pseudonimizar(texto, { paciente = '', pseudonimo = '[PACIENTE]', outrosNomes = [] } = {}) {
  let t = String(texto || '');
  const trocas = [];
  const trocar = (re, por) => {
    t = t.replace(re, (...m) => {
      trocas.push(m[0]);
      return por.replace(/\$(\d)/g, (_, i) => (typeof m[Number(i)] === 'string' ? m[Number(i)] : ''));
    });
  };

  // Primeiro os identificadores com formato (o e-mail costuma conter o nome).
  trocar(/[\w.+-]+@[\w-]+\.[\w.]+/g, '[EMAIL]');
  trocar(/\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b/g, '[CPF]');
  trocar(/\bRG\s*[:\-]?\s*[A-Z]{0,2}[\s\-]*[\d.\-]{5,}/gi, 'RG [RG]');
  trocar(/\(?\b\d{2}\)?\s?9?\d{4}-?\d{4}\b/g, '[TELEFONE]');
  trocar(/\b(matr[íi]cula)\s*[:\-]?\s*\d+/gi, '$1 [MATRICULA]');

  if (paciente) trocar(new RegExp(escapar(paciente), 'gi'), pseudonimo);
  for (const parte of partesDoNome(paciente)) trocar(new RegExp(`\\b${escapar(parte)}\\b`, 'gi'), pseudonimo);
  for (const nome of outrosNomes.filter(Boolean)) trocar(new RegExp(escapar(nome), 'gi'), '[NOME]');

  trocar(/\b(Dra?\.?)\s+[A-ZÀ-Ú][a-zà-ú]+(\s+(d[aeo]s?\s+)?[A-ZÀ-Ú][a-zà-ú]+)*/g, '$1 [MEDICO]');
  trocar(/\b(DRA?\.?)\s+[A-ZÀ-Ú]{2,}(\s+(D[AEO]S?\s+)?[A-ZÀ-Ú]{2,})*/g, '$1 [MEDICO]'); // textos do SOC em caixa alta

  // Seguranca extra: nenhum pedaco do nome do paciente pode sobrar.
  const sobrou = partesDoNome(paciente).filter((p) => new RegExp(`\\b${escapar(p)}\\b`, 'i').test(t));
  return { texto: t, trocas: trocas.length, sobrou };
}

// Desfaz o pseudônimo no texto sugerido pela IA, para colar no SOC.
export function restaurar(texto, { paciente = '', pseudonimo = '[PACIENTE]' } = {}) {
  if (!paciente) return texto;
  const primeiro = partesDoNome(paciente)[0] || paciente;
  return String(texto || '').split(pseudonimo).join(primeiro);
}
