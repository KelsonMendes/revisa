// Versão da extensão de src/ia.js: a extensão não roda programas, então pede a revisão à "ponte",
// um pequeno programa que o arquivo "Ligar ao Claude" instala uma vez no computador (extensao/ponte).
// A ponte só roda "claude -p" com o pedido já anonimizado; montar o pedido e ler a resposta é feito aqui,
// do mesmo jeito que no modo copiar e colar.
import { config } from './config.js';
import { checklist } from './checklist.js';
import { montarPedidoLote, lerRespostaLote } from './prompt.js';

export const HOST = 'br.kelson.auditorsoc';

function enviar(mensagem) {
  return new Promise((ok, erro) => {
    chrome.runtime.sendNativeMessage(HOST, mensagem, (resposta) => {
      if (chrome.runtime.lastError) {
        // Ter o Claude Code instalado não basta: o Edge só fala com ele pela ponte, ligada uma vez por computador.
        erro(new Error('Falta ligar o revisa. ao seu Claude Code. Abra as configurações (engrenagem), clique em "Baixar Ligar ao Claude" e dê dois cliques no arquivo baixado. Enquanto isso, use o modo copiar e colar.'));
        return;
      }
      ok(resposta);
    });
  });
}

export async function pontePresente() {
  try {
    return (await enviar({ tipo: 'ping' }))?.ok === true;
  } catch {
    return false;
  }
}

export async function revisar(dados) {
  const modelo = config.modeloClaudeCode === 'sonnet' ? 'sonnet' : 'opus';
  const prompt = montarPedidoLote(checklist, [{ id: '1', ...dados }]);
  const r = await enviar({ tipo: 'claude', prompt, modelo });
  if (!r?.ok) throw new Error(r?.erro || 'A ponte com o Claude Code não respondeu.');
  let saida;
  try {
    saida = JSON.parse(r.saida);
  } catch {
    throw new Error('O Claude Code respondeu num formato inesperado.');
  }
  if (saida.is_error) throw new Error(`Claude Code: ${saida.result || 'erro'}`);
  const [{ id: _id, ...resultado }] = lerRespostaLote(saida.result);
  return {
    resultado,
    modelo: `claude-code:${modelo}`,
    tokensEntrada: saida.usage?.input_tokens ?? null,
    tokensSaida: saida.usage?.output_tokens ?? null,
  };
}
