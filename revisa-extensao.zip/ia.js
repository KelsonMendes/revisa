// Versão da extensão de src/ia.js: a extensão não roda programas, então pede a revisão à "ponte",
// um pequeno programa instalado no computador que chama o Claude Code (extensao/host). Sem a ponte, usa-se o modo manual.
import { config } from './config.js';

export const HOST = 'br.kelson.auditorsoc';

function enviar(mensagem) {
  return new Promise((ok, erro) => {
    chrome.runtime.sendNativeMessage(HOST, mensagem, (resposta) => {
      if (chrome.runtime.lastError) {
        // Ter o Claude Code instalado não basta: o Edge só fala com ele por uma ponte registrada uma vez por computador.
        erro(new Error('O Edge não achou a ponte com o Claude Code. Ter o Claude Code instalado não basta: rode uma vez "powershell -ExecutionPolicy Bypass -File D:\\AuditorSOC\\extensao\\instalar-ponte.ps1" e feche e abra o Edge. Enquanto isso, use "Revisar pelo claude.ai".'));
        return;
      }
      ok(resposta);
    });
  });
}

export async function pontePresente() {
  try {
    return (await enviar({ tipo: 'ping' }))?.ok === true;
  } catch {
    return false;
  }
}

export async function revisar(dados) {
  const r = await enviar({ tipo: 'revisar', dados, modelo: config.modeloClaudeCode });
  if (!r?.ok) throw new Error(r?.erro || 'A ponte com o Claude Code não respondeu.');
  return r.revisao;
}
