
  // Endereço do painel: /painel no app local; a extensão e a demonstração trocam pelo atributo data-painel no <html>.
  const raiz = document.documentElement;
  raiz.classList.add('js');
  const destino = raiz.dataset.painel;
  if (destino) document.querySelectorAll('[data-painel]').forEach((a) => (a.href = destino));

  // O Windows pode pedir menos animação (Acessibilidade > Efeitos de animação; comum em PC de clínica e acesso remoto).
  // A página respeita, mas avisa e deixa religar; a escolha fica guardada neste navegador.
  const pedeCalma = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let escolha = null;
  try { escolha = localStorage.getItem('animacoes'); } catch {}
  const reduz = escolha === 'sim' ? false : escolha === 'nao' ? true : pedeCalma;
  raiz.classList.toggle('calmo', reduz);
  if (pedeCalma) {
    const aviso = document.getElementById('avisoAnim'), bt = document.getElementById('avisoBt');
    document.getElementById('avisoTxt').textContent = reduz ? 'Este computador pede menos animação.' : 'Animações ligadas neste navegador.';
    bt.textContent = reduz ? 'Ver com animações' : 'Desligar';
    bt.onclick = () => {
      try { localStorage.setItem('animacoes', reduz ? 'sim' : 'nao'); location.reload(); }
      catch { raiz.classList.toggle('calmo'); aviso.hidden = true; }
    };
    aviso.hidden = false;
    if (!reduz) setTimeout(() => { aviso.hidden = true; }, 6000);
  }
  const fino = matchMedia('(pointer: fine)').matches;

  // Dez dias de documentos: as pendências dos dias mais antigos já passaram de uma semana.
  const dias = [[5, 1], [6, 1], [4, 2], [7, 0], [5, 1], [6, 2], [5, 1], [4, 2], [6, 1], [3, 3]];
  let d = 0;
  document.getElementById('colsSemana').innerHTML = dias.map(([ok, pend], i) => {
    const docs = Array.from({ length: ok }, () => `<span class="doc" style="--d:${d++}"></span>`)
      .concat(Array.from({ length: pend }, () => `<span class="doc pend${i < 4 ? ' velho' : ''}" style="--d:${d++}"></span>`));
    return `<div class="col">${docs.join('')}</div>`;
  }).join('');

  // Manifesto: cada palavra acende num trecho da rolagem (só onde o navegador anima pela rolagem).
  if (!reduz && CSS.supports('animation-timeline: view()')) {
    const pals = [];
    const partir = (no) => {
      for (const filho of [...no.childNodes]) {
        if (filho.nodeType !== 3) { partir(filho); continue; }
        const frag = document.createDocumentFragment();
        for (const pedaco of filho.textContent.split(/(\s+)/)) {
          if (!pedaco) continue;
          if (/^\s+$/.test(pedaco)) { frag.append(pedaco); continue; }
          const s = document.createElement('span');
          s.className = 'pal'; s.textContent = pedaco; pals.push(s); frag.append(s);
        }
        filho.replaceWith(frag);
      }
    };
    partir(document.getElementById('frase'));
    pals.forEach((s, i) => { const a = (i / pals.length) * 80 + 4; s.style.setProperty('--a', a.toFixed(2)); s.style.setProperty('--b', (a + 9).toFixed(2)); });
  }

  // Números que contam ao aparecer.
  const contar = (el) => {
    const alvo = Number(el.dataset.conta), de = Number(el.dataset.de || 0), suf = el.dataset.suf;
    const pinta = (v) => { el.innerHTML = Math.round(v) + (suf ? `<small>${suf}</small>` : ''); };
    if (reduz) return pinta(alvo);
    const t0 = performance.now(), dur = 1600;
    const passo = (t) => { const p = Math.min(1, (t - t0) / dur); pinta(de + (alvo - de) * (1 - Math.pow(1 - p, 4))); if (p < 1) requestAnimationFrame(passo); };
    requestAnimationFrame(passo);
  };

  // Entradas ao rolar.
  const obs = new IntersectionObserver((itens) => {
    for (const it of itens) {
      if (!it.isIntersecting) continue;
      it.target.classList.add('visto', 'ativo');
      it.target.querySelectorAll('[data-conta]').forEach(contar);
      obs.unobserve(it.target);
    }
  }, { threshold: 0.18 });
  document.querySelectorAll('[data-surge], [data-ativar]').forEach((el) => obs.observe(el));

  // Como funciona: o passo no meio da tela decide a ilustração da tela fixa.
  const historia = document.getElementById('historia');
  const passos = [...historia.querySelectorAll('.passo')];
  // Nas telas estreitas a tela fixa some: cada passo ganha uma cópia da sua ilustração.
  for (const p of passos) {
    const ilu = historia.querySelector(`.palco2 [data-ilu="${p.dataset.passo}"]`);
    if (ilu) p.append(ilu.cloneNode(true));
  }
  const obsPasso = new IntersectionObserver((itens) => {
    for (const it of itens) {
      if (!it.isIntersecting) continue;
      passos.forEach((p) => p.classList.toggle('agora', p === it.target));
      historia.dataset.passo = it.target.dataset.passo;
    }
  }, { rootMargin: '-45% 0px -45% 0px' });
  passos.forEach((p) => obsPasso.observe(p));

  if (!reduz && fino) {
    // A mesa com as folhas acompanha o mouse.
    const heroi = document.getElementById('heroi'), mesa = document.getElementById('mesa');
    heroi.addEventListener('pointermove', (ev) => {
      const x = ev.clientX / innerWidth - 0.5, y = ev.clientY / innerHeight - 0.5;
      mesa.style.setProperty('--rx', (x * 16).toFixed(2) + 'deg');
      mesa.style.setProperty('--ry', (-y * 12).toFixed(2) + 'deg');
    });
    heroi.addEventListener('pointerleave', () => { mesa.style.removeProperty('--rx'); mesa.style.removeProperty('--ry'); });

    // Cartões que inclinam na direção do mouse.
    document.querySelectorAll('[data-tilt]').forEach((c) => {
      c.addEventListener('pointermove', (ev) => {
        const r = c.getBoundingClientRect();
        c.style.setProperty('--tx', (((ev.clientX - r.left) / r.width - 0.5) * 7).toFixed(2) + 'deg');
        c.style.setProperty('--ty', (-((ev.clientY - r.top) / r.height - 0.5) * 7).toFixed(2) + 'deg');
      });
      c.addEventListener('pointerleave', () => { c.style.removeProperty('--tx'); c.style.removeProperty('--ty'); });
    });

    // Final: a luz segue o mouse e o botão é atraído por ele.
    const final = document.getElementById('final');
    final.addEventListener('pointermove', (ev) => {
      const r = final.getBoundingClientRect();
      final.style.setProperty('--mx', (ev.clientX - r.left) + 'px');
      final.style.setProperty('--my', (ev.clientY - r.top) + 'px');
    });
    document.querySelectorAll('.ima').forEach((b) => {
      b.addEventListener('pointermove', (ev) => {
        const r = b.getBoundingClientRect();
        b.style.transform = `translate(${((ev.clientX - r.left - r.width / 2) * 0.22).toFixed(1)}px, ${((ev.clientY - r.top - r.height / 2) * 0.32).toFixed(1)}px)`;
      });
      b.addEventListener('pointerleave', () => { b.style.transform = ''; });
    });
  }

  const pular = document.getElementById('pular');
  try { pular.checked = localStorage.getItem('pularInicio') === '1'; } catch {}
  pular.onchange = () => { try { localStorage.setItem('pularInicio', pular.checked ? '1' : '0'); } catch {} };
