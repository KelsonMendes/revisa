@echo off
rem Liga a extensao revisa. ao Claude Code deste computador. Dois cliques e pronto: nao precisa de administrador nem de Node.
rem O resto deste arquivo e PowerShell, depois da marca no fim do cabecalho: a linha abaixo o executa.
powershell -NoProfile -ExecutionPolicy Bypass -Command "$t=[IO.File]::ReadAllText('%~f0',[Text.Encoding]::UTF8); $i=$t.LastIndexOf('#'+'#INSTALADOR#'+'#'); Invoke-Expression $t.Substring($i)"
exit /b
##INSTALADOR##
# Instalador da ponte: copia um pequeno programa (PowerShell) para %LOCALAPPDATA%\revisa-ponte e avisa o Edge e o Chrome
# que a extensão revisa. (só ela, pelo ID) pode chamá-lo. A ponte só sabe duas coisas: dizer se o Claude Code existe
# e rodar "claude -p" com o texto já anonimizado que a extensão manda, sem ferramentas, sem memória e sem MCP.
Add-Type -AssemblyName System.Windows.Forms
# REVISA_SILENCIOSO=1: sem caixas de mensagem (testes automáticos).
function Avisar($texto, $icone) { if (-not $env:REVISA_SILENCIOSO) { [Windows.Forms.MessageBox]::Show($texto, 'revisa.', 'OK', $icone) | Out-Null } else { Write-Output $texto } }
$ID = 'ifhapkjidcmkgcfoeccedhpkcmlllobg'
$pasta = Join-Path $env:LOCALAPPDATA 'revisa-ponte'
New-Item -ItemType Directory -Force -Path $pasta, (Join-Path $pasta 'isolado') | Out-Null

# Onde está o Claude Code? (o caminho fica gravado: o Edge às vezes abre a ponte sem o PATH do usuário)
$claude = (Get-Command claude -ErrorAction SilentlyContinue | Select-Object -First 1).Source
if (-not $claude) {
  foreach ($c in "$env:USERPROFILE\.local\bin\claude.exe", "$env:LOCALAPPDATA\Programs\claude\claude.exe", "$env:APPDATA\npm\claude.cmd") {
    if (Test-Path $c) { $claude = $c; break }
  }
}
if (-not $claude) {
  Avisar "Não encontrei o Claude Code neste computador.`n`nInstale o Claude Code (claude.com/claude-code), faça login nele uma vez e abra este arquivo de novo.`n`nEnquanto isso, o revisa. funciona copiando e colando no ChatGPT, Gemini, Claude ou Copilot." 'Warning'
  exit
}

$ponte = @'
# Ponte do revisa. com o Claude Code (protocolo "native messaging": JSON precedido do tamanho em 4 bytes).
$ErrorActionPreference = 'Stop'
$CLAUDE = '__CLAUDE__'
$ISOLADO = Join-Path $PSScriptRoot 'isolado'
$entrada = [Console]::OpenStandardInput()
$saida = [Console]::OpenStandardOutput()
$utf8 = New-Object Text.UTF8Encoding $false

function Ler([int]$n) {
  $buf = New-Object byte[] $n; $lidos = 0
  while ($lidos -lt $n) { $r = $entrada.Read($buf, $lidos, $n - $lidos); if ($r -le 0) { return $null }; $lidos += $r }
  return ,$buf
}
function Responder($obj) {
  $b = $utf8.GetBytes(($obj | ConvertTo-Json -Depth 10 -Compress))
  $saida.Write([BitConverter]::GetBytes([int]$b.Length), 0, 4); $saida.Write($b, 0, $b.Length); $saida.Flush()
}
function Citar([string]$a) {
  if ($a -eq '') { return '""' }
  if ($a -notmatch '[\s"]') { return $a }
  return '"' + (($a -replace '(\\*)"', '$1$1\"') -replace '(\\+)$', '$1$1') + '"'
}

while ($true) {
  $cab = Ler 4; if ($null -eq $cab) { break }
  $corpo = Ler ([BitConverter]::ToInt32($cab, 0)); if ($null -eq $corpo) { break }
  $msg = $utf8.GetString($corpo) | ConvertFrom-Json
  try {
    if ($msg.tipo -eq 'ping') { Responder @{ ok = (Test-Path $CLAUDE) }; continue }
    if ($msg.tipo -ne 'claude') { Responder @{ ok = $false; erro = 'Pedido desconhecido.' }; continue }
    $modelo = if ($msg.modelo -eq 'sonnet') { 'sonnet' } else { 'opus' }
    # Pasta vazia e só configurações de projeto: nada de plugins, hooks, memória ou MCP do usuário vendo o texto.
    $argumentos = @('-p', '--output-format', 'json', '--tools', '', '--no-session-persistence', '--strict-mcp-config',
      '--setting-sources', 'project', '--disable-slash-commands', '--model', $modelo)
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = $CLAUDE
    $psi.Arguments = ($argumentos | ForEach-Object { Citar $_ }) -join ' '
    $psi.WorkingDirectory = $ISOLADO
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.StandardOutputEncoding = $utf8; $psi.StandardErrorEncoding = $utf8
    $p = [Diagnostics.Process]::Start($psi)
    $fora = $p.StandardOutput.ReadToEndAsync(); $erros = $p.StandardError.ReadToEndAsync()
    $w = New-Object IO.StreamWriter($p.StandardInput.BaseStream, $utf8); $w.Write([string]$msg.prompt); $w.Close()
    $p.WaitForExit()
    if ($p.ExitCode -ne 0) {
      $det = ($erros.Result + $fora.Result); if ($det.Length -gt 300) { $det = $det.Substring(0, 300) }
      Responder @{ ok = $false; erro = "O Claude Code saiu com erro ($($p.ExitCode)): $det" }
    } else {
      Responder @{ ok = $true; saida = $fora.Result }
    }
  } catch {
    Responder @{ ok = $false; erro = "A ponte não conseguiu rodar o Claude Code: $($_.Exception.Message)" }
  }
}
'@
# PowerShell 5 só lê acentos certos em UTF-8 com BOM.
[IO.File]::WriteAllText((Join-Path $pasta 'ponte.ps1'), $ponte.Replace('__CLAUDE__', $claude.Replace("'", "''")), (New-Object Text.UTF8Encoding $true))
[IO.File]::WriteAllText((Join-Path $pasta 'ponte.cmd'), "@echo off`r`npowershell -NoProfile -ExecutionPolicy Bypass -File `"%~dp0ponte.ps1`"`r`n", [Text.Encoding]::ASCII)
$manifesto = [ordered]@{ name = 'br.kelson.auditorsoc'; description = 'Ponte do revisa. com o Claude Code'; path = (Join-Path $pasta 'ponte.cmd'); type = 'stdio'; allowed_origins = @("chrome-extension://$ID/") }
$arqManifesto = Join-Path $pasta 'br.kelson.auditorsoc.json'
[IO.File]::WriteAllText($arqManifesto, ($manifesto | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
foreach ($nav in 'Microsoft\Edge', 'Google\Chrome') {
  $chave = "HKCU:\Software\$nav\NativeMessagingHosts\br.kelson.auditorsoc"
  New-Item -Path $chave -Force | Out-Null
  Set-ItemProperty -Path $chave -Name '(default)' -Value $arqManifesto
}
Avisar "Pronto! O revisa. agora revisa com o seu Claude Code.`n`nVolte ao painel e clique em ""Revisar todos com IA"". Se o painel estava aberto, recarregue a página." 'Information'
