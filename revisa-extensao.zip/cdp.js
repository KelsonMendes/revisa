// Versão da extensão de src/cdp.js: em vez da porta de depuração do Edge, roda o código direto na aba do SOC
// (chrome.scripting, no "mundo" da própria página, para enxergar as funções do SOC). Mesmos nomes do original.

async function abaSoc() {
  const abas = await chrome.tabs.query({ url: 'https://sistema.soc.com.br/WebSoc/*' });
  if (!abas.length) return null;
  // Prefere a aba principal (menu antigo ou novo) e, entre elas, a mais recente.
  const principais = abas.filter((a) => /MainAction|cadIFrame/.test(a.url));
  return (principais.length ? principais : abas).sort((x, y) => (y.lastAccessed || 0) - (x.lastAccessed || 0))[0];
}

export async function edgeAberto() {
  return true;
}

export async function conectar() {
  const aba = await abaSoc();
  if (!aba) throw new Error('Abra o SOC numa aba do Edge e faça login.');
  return { tabId: aba.id, windowId: aba.windowId, close() {} };
}

// A versão anterior gravava window.socframe e, com isso, escondia o atalho que o próprio SOC usa para o iframe
// (o MainJava faz socframe.document...): a tela 797 não abria. Se ainda estiver gravado nesta aba, desfaz.
// O código da página agora procura o iframe por extenso (ver montar.mjs).
function devolverSocframe() {
  if (typeof window.socframe === 'function') delete window.socframe;
}

export async function rodar(sessao, fn, args = {}) {
  await chrome.scripting.executeScript({ target: { tabId: sessao.tabId }, world: 'MAIN', func: devolverSocframe });
  const [r] = await chrome.scripting.executeScript({ target: { tabId: sessao.tabId }, world: 'MAIN', func: fn, args: [args] });
  if (r && r.error) throw new Error(`Erro na página do SOC: ${r.error.message || r.error}`);
  return r ? r.result : undefined;
}

export async function trazerParaFrente(sessao) {
  await chrome.tabs.update(sessao.tabId, { active: true });
  await chrome.windows.update(sessao.windowId, { focused: true });
}

export const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

// "Alerta: Erro de Execução" do SOC ("a página solicitada não pode ser exibida"): procura na aba e nos quadros
// visíveis. Com ele na tela, a espera não adianta: para logo com aviso em vez de ficar travado.
export function erroNaTela() {
  // Só conta o aviso que está DE FATO visível: o SOC guarda textos e quadros escondidos (e um quadro escondido
  // devolve o texto inteiro no innerText), o que dava alarme falso.
  const re = /Erro de Execu[cç][aã]o|p[aá]gina solicitada n[aã]o pode ser exibida/i;
  const visivel = (el) => {
    for (let e = el; e;) {
      const r = e.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const s = e.ownerDocument.defaultView.getComputedStyle(e);
      if (s.display === 'none' || s.visibility !== 'visible' || Number(s.opacity) === 0) return false;
      e = e.parentElement || e.ownerDocument.defaultView.frameElement;
    }
    return true;
  };
  const docs = [];
  const juntar = (d, n) => {
    if (!d || n > 3) return;
    docs.push(d);
    for (const f of d.querySelectorAll('iframe,frame')) { try { juntar(f.contentDocument, n + 1); } catch {} }
  };
  juntar(document, 0);
  for (const d of docs) {
    if (!d.body) continue;
    const w = d.createTreeWalker(d.body, NodeFilter.SHOW_TEXT);
    for (let t = w.nextNode(); t; t = w.nextNode()) {
      const pai = t.parentElement;
      if (!pai || /^(SCRIPT|STYLE|TEMPLATE|NOSCRIPT)$/.test(pai.tagName)) continue;
      if (re.test(t.nodeValue) && visivel(pai)) return true;
    }
  }
  return false;
}

export const MSG_ERRO_SOC = 'O SOC mostrou "Erro de Execução" (a página não pôde ser exibida). Clique em OK no SOC, abra a agenda no dia e local que quer, e use o botão "Ler agenda aberta".';

export async function esperarAte(sessao, cond, args = {}, { tempo = 30000, passo = 500, descricao = 'a tela do SOC' } = {}) {
  const inicio = Date.now();
  const fim = inicio + tempo;
  let volta = 0;
  while (Date.now() < fim) {
    try {
      const v = await rodar(sessao, cond, args);
      if (v) return v;
    } catch {
      // a página pode estar no meio de uma navegação
    }
    // Só depois de 3 s esperando: o aviso do SOC é motivo para parar, não um piscar no meio da troca de tela.
    if (volta++ % 2 === 1 && Date.now() - inicio > 3000) {
      let erro = false;
      try { erro = await rodar(sessao, erroNaTela); } catch {}
      if (erro) throw new Error(MSG_ERRO_SOC);
    }
    await esperar(passo);
  }
  throw new Error(`O SOC demorou demais para carregar ${descricao}.`);
}
