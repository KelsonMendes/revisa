// Versão da extensão de src/cdp.js: em vez da porta de depuração do Edge, roda o código direto na aba do SOC
// (chrome.scripting, no "mundo" da própria página, para enxergar as funções do SOC). Mesmos nomes do original.

async function abaSoc() {
  const abas = await chrome.tabs.query({ url: 'https://sistema.soc.com.br/WebSoc/*' });
  if (!abas.length) return null;
  // Prefere a aba principal (menu antigo ou novo) e, entre elas, a mais recente.
  const principais = abas.filter((a) => /MainAction|cadIFrame/.test(a.url));
  return (principais.length ? principais : abas).sort((x, y) => (y.lastAccessed || 0) - (x.lastAccessed || 0))[0];
}

export async function edgeAberto() {
  return true;
}

export async function conectar() {
  const aba = await abaSoc();
  if (!aba) throw new Error('Abra o SOC numa aba do Edge e faça login.');
  return { tabId: aba.id, windowId: aba.windowId, close() {} };
}

// A versão anterior gravava window.socframe e, com isso, escondia o atalho que o próprio SOC usa para o iframe
// (o MainJava faz socframe.document...): a tela 797 não abria. Se ainda estiver gravado nesta aba, desfaz.
// O código da página agora procura o iframe por extenso (ver montar.mjs).
function devolverSocframe() {
  if (typeof window.socframe === 'function') delete window.socframe;
}

export async function rodar(sessao, fn, args = {}) {
  await chrome.scripting.executeScript({ target: { tabId: sessao.tabId }, world: 'MAIN', func: devolverSocframe });
  const [r] = await chrome.scripting.executeScript({ target: { tabId: sessao.tabId }, world: 'MAIN', func: fn, args: [args] });
  if (r && r.error) throw new Error(`Erro na página do SOC: ${r.error.message || r.error}`);
  return r ? r.result : undefined;
}

export async function trazerParaFrente(sessao) {
  await chrome.tabs.update(sessao.tabId, { active: true });
  await chrome.windows.update(sessao.windowId, { focused: true });
}

export const esperar = (ms) => new Promise((r) => setTimeout(r, ms));

export async function esperarAte(sessao, cond, args = {}, { tempo = 30000, passo = 500, descricao = 'a tela do SOC' } = {}) {
  const fim = Date.now() + tempo;
  while (Date.now() < fim) {
    try {
      const v = await rodar(sessao, cond, args);
      if (v) return v;
    } catch {
      // a página pode estar no meio de uma navegação
    }
    await esperar(passo);
  }
  throw new Error(`O SOC demorou demais para carregar ${descricao}.`);
}
