// Leitura do SOC dentro do Edge do auditor. Mapeamento das telas em NOTAS.md.
// Regra do Kelson: o app lê livremente; a única escrita é `colarNoCampo`, que preenche o campo
// em modo Alterar e NUNCA chama doAcao('save'), doAcao('save_parc') nem assinatura.
import { rodar, esperarAte, esperar, trazerParaFrente } from './cdp.js';
import { veu, tirarVeu } from './veu.js';
import { NOME_DOCUMENTO, estadoPelosDocumentos } from './estado.js';

// ---------- funções que rodam na página (serializadas por cdp.rodar) ----------

export const pg = {
  frameInfo: function () {
    const f = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'));
    if (!f) return { semFrame: true, titulo: document.title };
    const d = f.contentDocument;
    return { titulo: d.title, url: d.location.href, ac: d.forms[0]?.ac?.value ?? null, pronto: d.readyState === 'complete' };
  },

  // Quem está logado: o SOC escreve o nome do usuário na barra de baixo de cada tela (#barraInferior .barraTxt).
  usuarioLogado: function () {
    const docs = [document];
    try { if (((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentDocument) docs.push(((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument); } catch {}
    for (const d of docs) {
      const t = d.querySelector('#barraInferior .barraTxt')?.textContent.replace(/\s+/g, ' ').trim();
      if (t && t.length >= 3) return t;
    }
    return '';
  },

  // Agenda que está aberta agora no SOC, sem navegar (só se a tela atual for a agenda).
  agendaSeAberta: function () {
    const f = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentDocument?.forms?.sis028Form;
    return f?.codigoUsuarioAgenda?.value ? { codigo: f.codigoUsuarioAgenda.value, nome: f.nomeUsuarioAgenda?.value || '' } : null;
  },

  logado: function () {
    return !!((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')) && (typeof window.MainJava === 'function' || !!document.getElementById('frm-acesso-programa-frame'));
  },

  // Menu antigo: MainJava. Menu novo: o form #frm-acesso-programa-frame, com o token da página na URL.
  abrirPrograma: function ({ acao, codigo }) {
    if (typeof window.MainJava === 'function') {
      window.MainJava(acao, '', codigo);
      return true;
    }
    const f = document.getElementById('frm-acesso-programa-frame');
    if (!f) throw new Error('Não achei o menu do SOC nesta aba.');
    const token = (f.getAttribute('action').match(/TOKEN=([^&]*)/) || [])[1] || '';
    f.setAttribute('action', `${acao}?org.apache.struts.taglib.html.TOKEN=${token}&&param=&codPrg=${codigo}`);
    f.target = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).name || 'socframe';
    f.submit();
    return true;
  },

  agendaPronta: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    return d.readyState === 'complete' && !!d.forms.sis028Form && !!d.getElementById('targetTable');
  },

  agendaAtual: function () {
    const f = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.forms.sis028Form;
    return {
      codigo: f.codigoUsuarioAgenda.value,
      nome: f.nomeUsuarioAgenda.value,
      dia: f.auxDia.value, mes: f.auxMes.value, ano: f.auxAno.value,
    };
  },

  // Troca agenda e dia do mesmo jeito que o calendário da agenda (função altdata do SOC):
  // ac=browse, valorPeriodo = período marcado, registro no log da agenda e envio por loadSubmit (que põe o token).
  irParaDia: function ({ codigo, nome, data }) {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const f = w.document.forms.sis028Form;
    const [dia, mes, ano] = data.split('/');
    const trocaAgenda = !!codigo && codigo !== f.codigoUsuarioAgenda.value;
    if (codigo) f.codigoUsuarioAgenda.value = codigo;
    if (nome) f.nomeUsuarioAgenda.value = nome;
    // Troca de agenda do mesmo jeito que a janela "Agendas" do SOC (executaTrocaAgenda): usuarioAgenda e ";changeuser".
    if (trocaAgenda) {
      if (f.usuarioAgenda) f.usuarioAgenda.value = codigo;
      if (f.nomeTelaHidden) f.nomeTelaHidden.value = '';
      if (f.usuarioAgendaSocnet) f.usuarioAgendaSocnet.value = '';
      if (f.logAcaoAgendaInterceptor) f.logAcaoAgendaInterceptor.value += ';changeuser';
    }
    f.auxDia.value = String(Number(dia));
    f.auxMes.value = String(Number(mes));
    f.auxAno.value = ano;
    const periodos = [...f.querySelectorAll('input[name=agendaPeriodo]')];
    const dia3 = periodos.find((i) => i.value === '3');
    if (dia3) dia3.checked = true;
    const marcado = periodos.findIndex((i) => i.checked);
    if (f.valorPeriodo && marcado >= 0) f.valorPeriodo.value = String(marcado + 1);
    f.ac.value = 'browse';
    if (f.logAcaoAgendaInterceptor && !trocaAgenda) f.logAcaoAgendaInterceptor.value += ';altData';
    if (typeof w.loadSubmit === 'function') w.loadSubmit(f);
    else f.submit();
    return true;
  },

  // Lista de agendas que o SOC oferece no botão "Trocar agenda" (janela trocaAgenda!browser.action).
  // Só lê: pede a mesma janela que o SOC abriria e tira dela o código e o nome de cada agenda.
  listarAgendas: async function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const achadas = new Map();
    const add = (codigo, nome, empresa) => {
      codigo = String(codigo || '').trim();
      nome = String(nome || '').replace(/\s+/g, ' ').trim();
      if (/^\d{3,}$/.test(codigo) && nome && !/^\d+$/.test(nome) && !achadas.has(codigo)) achadas.set(codigo, { codigo, nome, empresa: String(empresa || '').trim() });
    };
    const lerItens = (doc) => doc.querySelectorAll('[data-codigo-agenda]')
      .forEach((el) => add(el.dataset.codigoAgenda, el.dataset.nomeAgenda || el.textContent, el.dataset.nomeEmp));
    // Na janela: chamadas de escolha de agenda, como executaTrocaAgenda('NOME', '123', ...), com um código e um nome.
    const lerChamadas = (html) => {
      for (const m of html.matchAll(/\b((?:executa|troca|trocar|seleciona|selecionar|escolhe|escolher)\w*agenda\w*)\s*\(([^()]*)\)/gi)) {
        const args = [...m[2].matchAll(/'([^']*)'|"([^"]*)"|(\d+)/g)].map((x) => x[1] ?? x[2] ?? x[3]);
        const codigo = args.find((x) => /^\d{3,}$/.test(x));
        const nome = args.find((x) => x && !/^\d+$/.test(x) && !/^(true|false|null|S|N)$/i.test(x) && /[A-Za-zÀ-ú]/.test(x));
        if (codigo && nome) add(codigo, nome);
      }
    };
    lerItens(d); // algumas versões do SOC já trazem a lista pronta na própria agenda (#lista-agendas)
    const f = d.forms.trocaAgendaForm;
    let amostra = '';
    if (f) {
      const r = await fetch(new URL(f.getAttribute('action'), d.location.href), { method: 'POST', body: new URLSearchParams(new FormData(f)) });
      const charset = (r.headers.get('content-type') || '').match(/charset=([\w-]+)/i)?.[1] || 'windows-1252';
      const html = new TextDecoder(charset).decode(await r.arrayBuffer());
      const doc = new DOMParser().parseFromString(html, 'text/html');
      lerItens(doc);
      lerChamadas(html);
      amostra = (doc.body?.innerText || '').replace(/\s+/g, ' ').slice(0, 400);
    }
    const sf = d.forms.sis028Form;
    add(sf.codigoUsuarioAgenda.value, sf.nomeUsuarioAgenda.value);
    // Se não vier nada além da agenda atual, deixa um rastro no console da aba do SOC para entender o formato.
    if (achadas.size <= 1) console.info('[revisa.] janela de agendas sem lista reconhecida:', amostra);
    return { agendas: [...achadas.values()], reconheceu: achadas.size > 1 };
  },

  agendaDoDia: function ({ data }) {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const f = d.forms.sis028Form;
    const [dia, mes, ano] = data.split('/');
    if (Number(f.auxDia.value) !== Number(dia) || Number(f.auxMes.value) !== Number(mes) || f.auxAno.value !== ano) return null;
    const args = (href, nome) => {
      const m = href.match(new RegExp(nome + '\\(([^)]*)\\)'));
      return m ? [...m[1].matchAll(/"([^"]*)"|(true|false)/g)].map((x) => x[1] ?? x[2]) : null;
    };
    // Cabeçalho: Hora | [Profissional da Agenda] | Compromisso | Tipo Compromisso | Empresa | Funcionário | Atendido.
    // Algumas agendas (local de um médico só) não têm a coluna "Profissional da Agenda". O cabeçalho pode estar
    // numa tabela separada ou na própria tabela: vale a linha que tem "Hora" e "Funcionário".
    const tabela = d.getElementById('targetTable');
    const texto = (c) => c.textContent.trim().replace(/\s+/g, ' ');
    const linhaCab = [...d.querySelectorAll('tr')].find((tr) => {
      const t = [...tr.cells].map(texto);
      return t.some((x) => /^Hora$/i.test(x)) && t.some((x) => /^Funcion[áa]rio$/i.test(x));
    });
    const cab = linhaCab ? [...linhaCab.cells].map(texto) : [];
    while (cab.length && !cab[cab.length - 1]) cab.pop(); // o cabeçalho tem uma célula vazia a mais no fim
    const col = (nome) => cab.findIndex((x) => x.toLowerCase().startsWith(nome.toLowerCase()));
    const iProf = col('Profissional');
    const iTipo = col('Tipo Compromisso');
    const iEmp = col('Empresa');
    const iAtendido = col('Atendido');
    // semColuna: a agenda não mostra quem atende; o app traz os atendimentos com a etiqueta "profissional não definido".
    const semColuna = cab.length > 0 && iProf < 0;
    const celula = (tr, i) => (i >= 0 && tr.cells.length >= cab.length ? texto(tr.cells[i]) : null);
    const linhas = [];
    for (const tr of tabela.querySelectorAll('tr')) {
      const links = [...tr.querySelectorAll('a')].map((a) => a.getAttribute('href') || '');
      const ficha = links.find((h) => h.includes('irFichaClinica('));
      if (!ficha) continue;
      const a = args(ficha, 'irFichaClinica');
      const nomeLink = [...tr.querySelectorAll('a')].find((x) => (x.getAttribute('href') || '').includes('linkempfun('));
      // Se a linha não bate com o cabeçalho, cai no layout antigo ("Tipo - Profissional" na 2ª coluna).
      const antigo = (tr.cells[1]?.textContent.trim() || '').split(' - ');
      linhas.push({
        hora: tr.cells[0]?.textContent.trim() || '',
        profissional: semColuna ? '' : celula(tr, iProf) ?? antigo.slice(1).join(' - ').trim(),
        semColunaProfissional: semColuna || !cab.length,
        atendido: celula(tr, iAtendido) || '',
        tipoTexto: celula(tr, iTipo) ?? antigo[0],
        empresa: celula(tr, iEmp) ?? (tr.cells[3]?.textContent.trim() || ''),
        paciente: (nomeLink?.textContent.trim() || tr.cells[4]?.textContent.trim().split('\n')[0] || '').trim(),
        crecid: a[0], tipo: a[1], data: a[2], codFuncionario: a[3], seqCompromisso: a[4], codEmp: a[5],
        hrefFicha: ficha,
      });
    }
    return linhas;
  },

  // Leitura por código (Kelson, 31/10): com a agenda aberta na tela, o próprio SOC monta o pedido da ficha
  // (irFichaClinica, inclusive a troca de empresa), mas o envio é interceptado e feito por fetch. A tela não sai
  // da agenda. Os tokens da tela são atualizados com os que o servidor devolve, para ela continuar válida.
  baixarFicha: async function ({ href }) {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const d = w.document;
    if (!d.forms.sis028Form || !/^javascript:/i.test(href || '')) return { ok: false };
    const capturar = (fn) => {
      const orig = w.HTMLFormElement.prototype.submit;
      const carregando = w.CarregandoAbrir;
      let pego = null;
      w.HTMLFormElement.prototype.submit = function () {
        const c = new URLSearchParams(new FormData(this));
        c.append('controleToken', String(window.controleToken?.get?.()));
        pego = { action: new URL(this.getAttribute('action') || this.action, d.location.href).href, corpo: c, nome: this.name };
      };
      w.CarregandoAbrir = () => {};
      try { fn(); } finally { w.HTMLFormElement.prototype.submit = orig; w.CarregandoAbrir = carregando; }
      return pego;
    };
    const enviar = async (p) => {
      const r = await fetch(p.action, { method: 'POST', body: p.corpo });
      const html = await r.text();
      if (/nosession/i.test(r.url)) throw new Error('A sessão do SOC caiu. Faça login de novo.');
      const t = html.match(/name="org\.apache\.struts\.taglib\.html\.TOKEN" value="([^"]+)"/);
      if (t) for (const i of d.querySelectorAll('input[name="org.apache.struts.taglib.html.TOKEN"]')) i.value = t[1];
      return { html, url: r.url };
    };
    const js = decodeURIComponent(href.replace(/^javascript:/i, ''));
    const codemp = (href.match(/,\s*["'](\d+)["']\s*,\s*(true|false)\s*\)\s*;?\s*$/) || [])[1];
    // Paciente de outra empresa: a troca de empresa do SOC recarrega a página principal, e fazê-la por fora
    // derrubou a sessão (erro=4). Esses vão pela tela (a troca de verdade); os da mesma empresa vão por código.
    const atual = d.getElementById('hiddenCodEmp')?.value;
    if (codemp && atual && codemp !== atual) return { ok: false, troca: true };
    const muda = w.mudaDeEmpresa;
    w.mudaDeEmpresa = () => false;
    let pedido;
    try { pedido = capturar(() => w.eval(js)); } finally { w.mudaDeEmpresa = muda; }
    if (!pedido) return { ok: false };
    const r = await enviar(pedido);
    if (!/cad009|cad016/.test(r.url) || !/<textarea|Anamnese|Licen/i.test(r.html)) return { ok: false };
    // Cópia sem scripts: a ficha renderiza (innerText funciona), mas nada dela roda nem navega.
    document.getElementById('revisaInerte')?.remove();
    const fr = document.createElement('iframe');
    fr.id = 'revisaInerte';
    fr.setAttribute('sandbox', 'allow-same-origin');
    fr.setAttribute('aria-hidden', 'true');
    fr.style.cssText = 'position:fixed;left:-30000px;top:0;width:1280px;height:1000px;border:0;visibility:hidden';
    const base = `<base href="${r.url.replace(/"/g, '')}">`;
    fr.srcdoc = /<head[^>]*>/i.test(r.html) ? r.html.replace(/<head[^>]*>/i, (m) => m + base) : base + r.html;
    document.body.appendChild(fr);
    await new Promise((ok) => { fr.onload = ok; setTimeout(ok, 5000); });
    window.__revisaInerte = true;
    return { ok: true };
  },

  soltarFichaInerte: function () {
    window.__revisaInerte = false;
    document.getElementById('revisaInerte')?.remove();
    return true;
  },

  abrirFichaPorHref: function ({ href }) {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    d.location.href = href;
    return true;
  },

  fichaPronta: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    if (d.readyState !== 'complete' || !d.forms[0]) return false;
    return /cad009|cad016/.test(d.location.href) && !!d.forms[0].ac ? d.forms[0].ac.value : false;
  },

  // Lê a ficha aberta (cad009 periódico/admissional/retorno ou cad016 licença/perícia).
  lerFicha: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const f = d.forms[0];
    const v = (n) => (f.elements[n] ? f.elements[n].value : '');
    const prog = /cad016/.test(d.baseURI) ? 'cad016' : 'cad009';
    const rotulo = (txt) => {
      const l = [...d.querySelectorAll('td.label, td')].find((e) => e.children.length === 0 && e.textContent.trim() === txt);
      if (!l) return '';
      const c = l.nextElementSibling;
      return c ? c.innerText.trim() : '';
    };
    const textarea = (n) => d.querySelector(`textarea[name="${n}"]`)?.value || '';
    const selTexto = (n) => {
      const s = d.querySelector(`select[name="${n}"]`);
      return s && s.selectedIndex >= 0 ? s.options[s.selectedIndex].text.trim() : '';
    };
    const textoCorpo = d.body.innerText.replace(/\s+/g, ' ');
    // Questionário "Preenchimento do Funcionário" (itens it0…): por pergunta, o que foi marcado.
    // Regra do Kelson: pergunta de opções sem nada marcado = o paciente negou (ex.: antecedentes familiares).
    const lerQuestionario = () => {
      const limpo = (el) => (el?.innerText ?? el?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const grupos = new Map();
      // Título do bloco: a linha sem campos mais próxima acima (ex.: "ANTECEDENTES FAMILIARES"), subindo pelas tabelas.
      const tituloAntes = (tr) => {
        for (let el = tr; el && el !== d.body; el = el.parentElement?.closest('tr')) {
          for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
            if (p.querySelector('input, select, textarea')) continue;
            const t = limpo(p);
            if (t && t.length <= 80) return t;
          }
        }
        return '';
      };
      for (const inp of d.querySelectorAll('input[name^="it0"]')) {
        const tipo = (inp.type || '').toLowerCase();
        const td = inp.closest('td');
        const tr = inp.closest('tr');
        // Pergunta: a célula de rótulo da mesma linha (td.label) ou a primeira célula da linha.
        const rotuloLinha = tr ? (tr.querySelector('td.label') || (tr.cells[0] !== td ? tr.cells[0] : null)) : null;
        const rotulo = limpo(rotuloLinha) || limpo(td?.previousElementSibling);
        const titulo = tr ? tituloAntes(tr) : '';
        const pergunta = (titulo && rotulo && titulo !== rotulo ? `${titulo} › ${rotulo}` : rotulo || titulo || 'Questionário').slice(0, 120);
        let opcao = '';
        if (inp.id) opcao = limpo(d.querySelector(`label[for="${inp.id}"]`));
        for (let n = inp.nextSibling; !opcao && n; n = n.nextSibling) {
          if (n.nodeType === 1 && n.matches('input, br')) break;
          opcao = (n.nodeType === 3 ? n.textContent : limpo(n)).trim();
        }
        if (!grupos.has(pergunta)) grupos.set(pergunta, { pergunta, opcoes: [], marcadas: [], textos: [] });
        const g = grupos.get(pergunta);
        if (tipo === 'checkbox' || tipo === 'radio') {
          g.opcoes.push(opcao || inp.value);
          if (tipo === 'radio') g.radio = true; // Sim/Não sem resposta não é "nega"
          if (inp.checked) g.marcadas.push(opcao || inp.value);
        } else if (tipo !== 'hidden' && inp.value.trim()) {
          g.textos.push(inp.value.trim().slice(0, 200));
        }
      }
      return [...grupos.values()].filter((g) => g.opcoes.length || g.textos.length);
    };
    const auditoria = textoCorpo.match(/Incluído por (.*?) Data Criação (\S+) Alterado por (.*?) Dt\.Últ\.Alteração (\S+)/);
    // Ficha gravada (consulta): o questionário aparece como texto, "Item ▷ Sim/Não", em blocos com título em
    // maiúsculas ("DOENÇAS NA FAMÍLIA", "HISTÓRIA OCUPACIONAL"…), depois de "PREENCHIMENTO DO FUNCIONÁRIO".
    const lerQuestionarioTexto = () => {
      const t = d.body.innerText || '';
      const ini = t.search(/PREENCHIMENTO DO FUNCION[ÁA]RIO/i);
      if (ini < 0) return [];
      const resto = t.slice(ini).replace(/^[^\n]*\n/, '');
      const fim = resto.search(/\n\s*(EXAME F[ÍI]SICO|Exame F[íi]sico|CONCLUS[ÕO]ES|Conclus[õo]es|SOLICITA[ÇC][ÕO]ES|Solicita[çc][õo]es|ASSINATURAS|Assinaturas)\b/);
      const bloco = fim < 0 ? resto.slice(0, 8000) : resto.slice(0, fim);
      const grupos = [];
      let g = null;
      const limpa = (x) => x.replace(/\s+/g, ' ').trim();
      const ehTitulo = (x) => x.length <= 90 && x === x.toLocaleUpperCase('pt-BR') && /[A-ZÀ-Ú]{3}/.test(x) && !/[▷►▶]/.test(x);
      const item = (x) => {
        const m = x.match(/^(.+?)\s*[▷►▶]\s*(.+)$/) || x.match(/^(.+?)\s+(Sim|N[ãa]o|nunca|raramente|às vezes|sempre)$/i);
        return m ? { item: m[1].trim(), valor: m[2].trim() } : null;
      };
      // Dois jeitos de as colunas lado a lado chegarem no texto:
      //  a) um quadro inteiro, depois o outro, emendados por tab ("Alergias ▷ Não<tab>HISTÓRIA SOCIAL");
      //  b) os títulos numa linha ("A<tab>B") e cada linha seguinte com um item de cada coluna.
      let colunas = null;
      for (const bruta of bloco.split('\n')) {
        const pedacos = bruta.split('\t').map(limpa).filter(Boolean);
        if (!pedacos.length) continue;
        if (pedacos.length > 1 && pedacos.every(ehTitulo)) {
          colunas = pedacos.map((titulo) => ({ titulo, itens: [] }));
          grupos.push(...colunas);
          continue;
        }
        if (colunas && pedacos.length <= colunas.length && pedacos.every((x) => item(x))) {
          // Linha com menos itens que colunas: a coluna da esquerda é a que costuma ser mais comprida.
          pedacos.forEach((x, k) => colunas[k].itens.push(item(x)));
          continue;
        }
        colunas = null;
        for (let i = 0; i < pedacos.length; i++) {
          const x = pedacos[i];
          const it = item(x);
          if (it) { g?.itens.push(it); continue; }
          if (ehTitulo(x)) { g = { titulo: x, itens: [] }; grupos.push(g); continue; }
          // Rótulo e valor em pedaços separados ("Calmo" + "Não").
          const prox = pedacos[i + 1];
          if (g && prox && prox.length <= 25 && !ehTitulo(prox)) { g.itens.push({ item: x.replace(/[▷►▶]\s*$/, '').trim(), valor: prox }); i++; }
        }
      }
      return grupos.filter((x) => x.itens.length);
    };
    // Riscos do funcionário (do PGR/PCMSO), que o SOC mostra no topo da ficha.
    const riscos = (textoCorpo.match(/Riscos do Funcion[áa]rio\s*(.{3,1500}?)\s*(?:O funcion[áa]rio encontra-se|Conduta dos Exames|Exame Cl[íi]nico|Funcion[áa]rio Matr[íi]cula)/i) || [])[1] || '';
    const base = {
      riscos: riscos.trim(),
      programa: prog,
      ac: v('ac'),
      existe: v('ac') !== 'inc' && !!v('rowidFicha'),
      rowidFicha: v('rowidFicha'),
      codigoSequencialFicha: v('codigoSequencialFicha'),
      rowidFuncionario: v('rowidFuncionario'),
      fichaPossuiGed: v('fichaPossuiGed') === 'true',
      dataFicha: v('dataFicha'),
      incluidoPor: auditoria?.[1] || '',
      dataCriacao: auditoria?.[2] || '',
      alteradoPor: auditoria?.[3] || '',
      dataAlteracao: auditoria?.[4] || '',
      cargo: v('nomeCargo') || rotulo('Cargo'),
      setor: v('nomeSetor') || rotulo('Setor'),
      idade: rotulo('Idade'),
      sexo: rotulo('Sexo'),
    };
    if (prog === 'cad009') {
      return {
        ...base,
        medico: rotulo('Médico(a)'),
        tipoExame: rotulo('Tipo'),
        textos: {
          anamnese: textarea('anamnese') || rotulo('Anamnese'),
          observacaoComplemento: textarea('observacaoComplemento'),
          textoLivre: textarea('textoLivre'),
        },
        parecer: (textoCorpo.match(/Parecer (Apto|Inapto|Apto com restri\S*)/i) || [])[1] || selTexto('parecerAso'),
        exameFisico: (d.body.innerText.match(/Exame Físico[\s\S]{0,1500}?Conclusões/) || [''])[0],
        questionario: lerQuestionario(),
        questionarioSoc: lerQuestionarioTexto(),
        // Sinais vitais e medidas: no modo Alterar são campos; na consulta, texto ao lado do rótulo.
        sinais: {
          temperatura: v('temperatura') || rotulo('Temperatura'),
          frequenciaRespiratoria: v('frequenciaRespiratoria') || rotulo('Frequência Respiratória (IPM)'),
          pressao: v('pressaoMaxima') ? `${v('pressaoMaxima')}x${v('pressaoMinima')}` : rotulo('Pressão Arterial (mmHg)'),
          frequenciaPulso: v('frequenciaPulso') || rotulo('Frequência de Pulso (BPM)'),
          altura: v('altura') || rotulo('Altura'),
          peso: v('peso') || rotulo('Peso (Kg)'),
          imc: v('imc') || rotulo('IMC'),
          cintura: v('perimetroCintura') || rotulo('Perímetro Cintura (cm)'),
          biotipo: selTexto('biotipo'),
        },
      };
    }
    return {
      ...base,
      medico: selTexto('inputMedico_codigoMedico') || rotulo('Médico(a)'),
      tipoExame: 'Licença Médica',
      textos: {
        periciaLicenca: textarea('periciaLicenca'),
        motivoAfastamento_EDITORHTML: textarea('motivoAfastamento_EDITORHTML'),
        restricaoRetorno: textarea('restricaoRetorno'),
      },
      licenca: {
        tipo: selTexto('codigoTipoLicencaTela'),
        motivo: selTexto('codigoMotivoLicencaTela'),
        inicio: v('dataLicencaInicio'),
        fim: v('dataLicencaFim'),
        dias: v('diasAfastamento'),
        diasValidados: v('diasValidadosPeloMedico'),
        situacao: selTexto('situacao'),
        cidValidado: [...(d.querySelector('select[name=cValidMedico]')?.options || [])].map((o) => o.text).join('; '),
        cidsAdicionais: [...(d.querySelector('select[name=cdiag]')?.options || [])].map((o) => o.text).join('; '),
        incapacitado: !!d.querySelector('input[name=trabalhadorIncapacitado]')?.checked,
      },
    };
  },

  // Assinatura Digital (797): lista documentos do GED por classificação e modo, com paginação.
  listarGed: async function ({ classificacao, modo, de, ate }) {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const form = d.getElementById('frm-browser-assinatura-digital');
    if (!form) throw new Error('Tela Assinatura Digital não carregada');
    const set = (id, val) => { const e = d.getElementById(id); if (e) e.value = val; };
    set('ipt-hdn-valor-modo-visualizacao', modo);
    set('ipt-hdn-valor-classificacao-ged', String(classificacao));
    set('ipt-hdn-valor-buscar-por', '0');
    set('ipt-periodo-selecao', `${de} - ${ate}`);
    set('ipt-data-inicio', de);
    set('ipt-data-fim', ate);
    const parse = (html) => {
      const doc = new DOMParser().parseFromString(`<table><tbody>${html}</tbody></table>`, 'text/html');
      const rows = [...doc.querySelectorAll('tr')].filter((tr) => tr.querySelector('.crecidArquivo'));
      return rows.map((tr) => ({
        codigoArquivoGed: tr.querySelector('.codigoArquivoGed')?.value || '',
        codigoGed: tr.querySelector('.codigoGed')?.textContent.trim() || '',
        nomeArquivo: tr.querySelector('.nomeDoArquivo')?.textContent.trim() || '',
        nomeGed: (tr.querySelector('.nomeDoGed .link-ged') || tr.querySelector('.nomeDoGed'))?.getAttribute('data-tooltip-padrao-acao') || tr.querySelector('.nomeDoGed')?.textContent.trim() || '',
        dataUpload: (tr.textContent.match(/\d{2}\/\d{2}\/\d{4}/) || [''])[0],
        assinaturas: Number(tr.querySelector('.quantidade-assinaturas')?.value || 0),
        assinaturasNecessarias: Number(tr.querySelector('.ipt-numero-assinaturas')?.value || 1),
      }));
    };
    const post = async (url, extra = {}) => {
      const body = new URLSearchParams(new FormData(form));
      for (const [k, val] of Object.entries(extra)) body.set(k, val);
      const r = await fetch(url, { method: 'POST', body, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!r.ok) throw new Error(`Assinatura Digital respondeu ${r.status}`);
      return r.text();
    };
    let html = await post('cad422!getArquivos.action');
    const todos = parse(html);
    for (let i = 0; i < 50 && /possuiProximo/.test(html); i++) {
      html = await post('cad422!getArquivosCarregarMais.action', { indiceBuscaBrowser: String(todos.length) });
      const mais = parse(html);
      if (!mais.length) break;
      todos.push(...mais);
    }
    return todos;
  },

  telaAssinaturaPronta: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    return d.readyState === 'complete' && !!d.getElementById('frm-browser-assinatura-digital');
  },

  entrarModoAlterar: function () {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    w.doAcao('alt');
    return true;
  },

  // Preenche o campo e destaca. Não salva.
  // Caixas de diálogo do SOC durante uma ação do app: alerta vira mensagem guardada (para mostrar o erro ao médico);
  // pergunta só recebe "sim" se for a esperada (salvar, gravar, criar o SOCGED, gerar o PDF). Vale até a página recarregar.
  prepararDialogos: function ({ aceitar }) {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const permitido = new RegExp(aceitar, 'i');
    w.__revisaAlertas = [];
    w.__revisaMarca = Date.now();
    w.alert = (m) => { w.__revisaAlertas.push(String(m)); };
    w.confirm = (m) => { const ok = permitido.test(String(m)); w.__revisaAlertas.push(`${ok ? '✓' : '✗'} ${m}`); return ok; };
    return true;
  },

  estadoAcao: function () {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentWindow;
    const d = w?.document;
    return {
      recarregou: !w?.__revisaMarca,
      pronto: d?.readyState === 'complete',
      ac: d?.forms?.[0]?.ac?.value ?? null,
      alertas: w?.__revisaAlertas || [],
      fichaPossuiGed: d?.forms?.[0]?.fichaPossuiGed?.value === 'true',
    };
  },

  salvarFicha: function () {
    ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow.doAcao('save');
    return true;
  },

  // PDF da ficha clínica (Outras Impressões → gera o PDF e vincula ao SOCGED). Classificação 8 = Ficha Clínica.
  gerarPdfFicha: function () {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    if (typeof w.validaAcessoGed !== 'function') return { ok: false, motivo: 'Não achei a opção de gerar o PDF nesta ficha.' };
    w.validaAcessoGed('gera_pdf', '8');
    return { ok: true };
  },

  // Documentos da ficha aberta: a mesma lista da pastinha "SOCGED Relacionado" (canto superior direito da ficha).
  // É a fonte certa do estado: "Ficha_Clinica_…pdf" é o PDF da ficha; "Termo_de_Aceite_…" e outros não contam.
  documentosDaFicha: async function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const f = d.forms[0];
    if (!f) return null;
    const corpo = new URLSearchParams();
    for (const e of f.elements) {
      if (!e.name || ((e.type === 'checkbox' || e.type === 'radio') && !e.checked)) continue;
      if (e.tagName === 'SELECT' && e.multiple) { for (const o of e.selectedOptions) corpo.append(e.name, o.value); continue; }
      corpo.append(e.name, e.value);
    }
    corpo.set('ac', 'socgedAjuda'); // o mesmo que o clique na pastinha manda; nunca o "ac" de outra ação que ficou no form
    const r = await fetch(new URL('socgedAjuda!socgedAjuda.action?ask=COMMAND_NAME_1', d.baseURI), { method: 'POST', body: corpo, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
    if (!r.ok) return null;
    const doc = new DOMParser().parseFromString(await r.text(), 'text/html');
    return [...doc.querySelectorAll('td.td-nome-arquivo, [data-nome-arquivo]')].map((td) => ({
      nome: td.dataset.nomeArquivo || td.textContent.trim(),
      assinado: td.dataset.assinado === 'true',
      assinaturas: Number(td.dataset.assinaturas || 0),
      necessarias: Number(td.dataset.assinaturasPermitida || 1),
    }));
  },

  // PDF pelo SOC: validaAcessoGed pergunta "Deseja criar um SOCGED e vincular esse documento?" numa janela da
  // própria página (#idDivGed), não num confirm do navegador. O "Sim" dela é concluiAviso(2), que pede o PDF
  // ao SOC (ac=pedidoProcessamento). Só gera; assinar continua com o médico.
  responderVincularGed: function () {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const aviso = w.document.getElementById('idDivGed');
    if (!aviso || getComputedStyle(aviso).display === 'none' || typeof w.concluiAviso !== 'function') return false;
    w.concluiAviso('2');
    return true;
  },

  // Depois do "Sim", o SOC responde em #mensagemProc: "FICHA CLINICA EM PDF Código de Identificação do Pedido: N".
  // O PDF entra numa fila do SOC e aparece na pastinha da ficha alguns minutos depois (no teste: ~3 min).
  // PDF pelo caminho que o Kelson usa à mão (bem mais rápido que o pedido de processamento):
  // Imprimir Ficha Clínica (doAcao('relatorio') → rel009) → ícone "Capturar Biometria, Criar PDF e Assinar
  // Digitalmente" → Avançar → "Gerar PDF no SOCGED". A impressão abre num iframe escondido dentro da própria
  // ficha, em vez de uma aba nova. O passo 3 ("Assinar PDF Digitalmente") nunca é clicado.
  abrirImpressaoFicha: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const w = d.defaultView;
    const f = d.forms[0];
    if (!f || typeof w.doAcao !== 'function' || typeof w.loadSubmit !== 'function') return { ok: false, motivo: 'Não achei a impressão da ficha.' };
    d.getElementById('revisaImpressao')?.remove();
    const fr = d.createElement('iframe');
    fr.id = 'revisaImpressao';
    fr.name = 'revisaImpressao';
    fr.style.cssText = 'position:fixed;left:-20000px;top:0;width:1100px;height:900px;border:0;visibility:hidden';
    d.body.appendChild(fr);
    // O doAcao('relatorio') manda o form para uma aba nova (_blank) pelo loadSubmit. Troca só esse envio para o
    // iframe, sem a tela de "Carregando" da ficha (o loadSubmit original só a abre quando o alvo não é _blank).
    const original = w.loadSubmit;
    w.loadSubmit = function (form) {
      w.loadSubmit = original;
      if (form !== f) return original.apply(this, arguments);
      const $f = w.$(form);
      if (!w.$.isFormValid($f)) return undefined;
      if (w.top?.criaToken) w.top.criaToken(form);
      form.target = 'revisaImpressao';
      $f.submit();
      return undefined;
    };
    try { w.doAcao('relatorio'); } finally { w.loadSubmit = original; f.target = '_self'; }
    return { ok: true };
  },

  // Impressão do ASO (cad017): o ícone de imprimir abre uma aba nova (documentoCustomizavel) com a mesma janela
  // Biometria → Criar PDF → Assinatura. Igual à ficha, o envio vai para um iframe escondido.
  abrirImpressaoAso: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const w = d.defaultView;
    const dica = (e) => `${e.getAttribute('onmouseover') || ''} ${e.title || ''} ${e.getAttribute('tooltype') || ''} ${e.alt || ''}`;
    const icone = [...d.querySelectorAll('img, a')].find((e) => /imprim(e|ir)\s*(o\s*)?aso/i.test(dica(e)) && !/branco|envelope|etiqueta|segunda/i.test(dica(e)));
    const alvo = icone?.closest('a') || icone;
    if (!alvo) return { ok: false, motivo: 'Não achei o botão de imprimir o ASO.' };
    d.getElementById('revisaImpressao')?.remove();
    const fr = d.createElement('iframe');
    fr.id = 'revisaImpressao';
    fr.name = 'revisaImpressao';
    fr.style.cssText = 'position:fixed;left:-20000px;top:0;width:1100px;height:900px;border:0;visibility:hidden';
    d.body.appendChild(fr);
    // Qualquer envio para aba nova (form com target ou window.open) vai para o iframe, uma vez só.
    const loadSubmit = w.loadSubmit;
    const abrirJanela = w.open;
    const restaurar = () => { if (loadSubmit) w.loadSubmit = loadSubmit; w.open = abrirJanela; };
    if (loadSubmit) {
      w.loadSubmit = function (form) {
        restaurar();
        if (form.target && form.target !== '_self') {
          if (w.top?.criaToken) w.top.criaToken(form);
          const alvoAntes = form.target;
          form.target = 'revisaImpressao';
          w.$(form).submit();
          form.target = alvoAntes;
          return undefined;
        }
        return loadSubmit.apply(this, arguments);
      };
    }
    w.open = function (url) { restaurar(); if (url) fr.src = url; return fr.contentWindow; };
    const href = alvo.getAttribute('href') || '';
    if (/^javascript:/i.test(href)) w.eval(decodeURIComponent(href.replace(/^javascript:/i, '')));
    else alvo.click();
    setTimeout(restaurar, 5000);
    return { ok: true };
  },

  // ASO recusado: quais exames do atendimento estão sem data (Resultado de Exames, cad012).
  examesSemData: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const limpo = (el) => (el?.innerText || el?.textContent || '').replace(/\s+/g, ' ').trim();
    for (const tr of d.querySelectorAll('tr')) {
      const cab = [...tr.cells].map(limpo);
      const iNome = cab.findIndex((t) => /todos exames/i.test(t));
      const iData = cab.findIndex((t) => /dt\.?\s*resultado/i.test(t));
      if (iNome < 0 || iData < 0) continue;
      const faltam = [];
      for (let n = tr.nextElementSibling; n && n.cells?.length >= cab.length - 1; n = n.nextElementSibling) {
        const nome = limpo(n.cells[iNome]);
        if (nome && !/\d{2}\/\d{2}\/\d{4}/.test(limpo(n.cells[iData]))) faltam.push(nome);
      }
      return { ok: true, faltam };
    }
    return { ok: false, faltam: [] };
  },

  // Licença (cad016): ícone "Gerar PDF da Licença Médica". Vira um pedido de processamento; o PDF chega na
  // pastinha de 5 a 30 minutos depois.
  gerarPdfLicenca: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const dica = (e) => `${e.getAttribute('onmouseover') || ''} ${e.title || ''} ${e.getAttribute('tooltype') || ''}`;
    const icone = [...d.querySelectorAll('img, a')].find((e) => /gerar pdf da licen/i.test(dica(e)));
    const alvo = icone?.closest('a') || icone;
    if (!alvo) return { ok: false, motivo: 'Não achei o botão "Gerar PDF da Licença Médica".' };
    const href = alvo.getAttribute('href') || '';
    if (/^javascript:/i.test(href)) d.defaultView.eval(decodeURIComponent(href.replace(/^javascript:/i, '')));
    else alvo.click();
    return { ok: true };
  },

  impressaoPronta: function () {
    const fr = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.getElementById('revisaImpressao');
    const d = fr?.contentDocument;
    return !!(d && d.readyState === 'complete' && d.location.href !== 'about:blank' && d.getElementById('processoCompletoAssinar') && d.getElementById('processoCompletoConteudo'));
  },

  // Um passo por chamada. Devolve a fase: 'abriu', 'avancou', 'gerando', 'pronto' ou 'erro'.
  passoPdfImpressao: function ({ assinar = false } = {}) {
    const fr = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.getElementById('revisaImpressao');
    const d = fr?.contentDocument;
    if (!d) return { fase: 'erro', motivo: 'A impressão da ficha fechou.' };
    const w = d.defaultView;
    const c = d.getElementById('processoCompletoConteudo');
    const visivel = (el) => !!el && getComputedStyle(el).display !== 'none' && !el.classList.contains('botaoInstalacao-gray');
    const passo2 = c.querySelector('.passo2');
    const limpo = (el) => (el?.innerText || '').replace(/\s+/g, ' ').trim();
    for (const id of ['alertaBiometria', 'erro', 'alertaGeracaoPdf']) {
      const a = d.getElementById(id);
      if (a && getComputedStyle(a).display !== 'none' && limpo(a)) return { fase: 'erro', motivo: limpo(a).slice(0, 300) };
    }
    if (passo2.classList.contains('done')) {
      if (!assinar) return { fase: 'pronto' };
      // Passo 3 ("Assinar PDF Digitalmente"): só quando o médico pediu para assinar. No fim o SOC dá um alert
      // ("E-mail enviado"); os diálogos da impressão ficam respondidos para a página não travar.
      const passo3 = c.querySelector('.passo3');
      if (passo3?.classList.contains('done')) return { fase: 'assinado' };
      if (passo3?.classList.contains('error')) return { fase: 'erro', motivo: limpo(passo3) || 'O SOC não assinou o PDF.' };
      if (!w.__revisaAvisos) {
        w.__revisaAvisos = [];
        w.alert = (m) => { w.__revisaAvisos.push(String(m)); };
        w.confirm = (m) => { w.__revisaAvisos.push(String(m)); return true; };
      }
      if (w.__revisaAssinou) return { fase: 'assinando', avisos: w.__revisaAvisos };
      const assinarBt = c.querySelector('.pcBotaoConcluir');
      if (visivel(assinarBt)) { w.__revisaAssinou = true; assinarBt.click(); return { fase: 'assinando' }; }
      return { fase: 'pronto_sem_assinar' };
    }
    if (passo2.classList.contains('error')) return { fase: 'erro', motivo: limpo(passo2) || 'O SOC não criou o PDF.' };
    const modal = d.getElementById('processoCompletoModal');
    if (!w.__revisaAbriu) {
      w.__revisaAbriu = true;
      d.getElementById('processoCompletoAssinar').click();
      return { fase: 'abriu' };
    }
    if (!modal || getComputedStyle(modal).display === 'none') return { fase: 'esperando' };
    if (w.__revisaGerou) return { fase: 'gerando' };
    // Nunca clica o "Assinar PDF Digitalmente": se ele já está na tela, algo saiu do roteiro.
    if (visivel(c.querySelector('.pcBotaoConcluir'))) return { fase: 'erro', motivo: 'A janela do SOC já está no passo de assinar.' };
    const gerar = c.querySelector('.pcBotaoProximo');
    if (visivel(gerar)) {
      w.__revisaGerou = true;
      gerar.click();
      return { fase: 'gerando' };
    }
    const avancar = c.querySelector('.pcBotaoAvancar');
    if (visivel(avancar)) { avancar.click(); return { fase: 'avancou' }; }
    return { fase: 'esperando' };
  },

  fecharImpressao: function () {
    ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.getElementById('revisaImpressao')?.remove();
    return true;
  },

  // Assinar (só quando o médico escolhe "…e assinar" no painel): abre a pastinha "SOCGED Relacionado" da ficha e
  // clica no ícone "Assinar arquivo digitalmente" da linha do PDF. Daí em diante é a assinatura do próprio SOC,
  // com o certificado do médico.
  abrirPastinha: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    if (d.querySelector('td.td-nome-arquivo')) return true;
    const icone = [...d.querySelectorAll('[onmouseover], [title], [tooltype]')].find((e) => /socged relacionado/i.test(`${e.getAttribute('onmouseover') || ''} ${e.title || ''} ${e.getAttribute('tooltype') || ''}`));
    const alvo = icone?.closest('a') || icone;
    if (alvo) { alvo.click(); return true; }
    if (typeof d.defaultView.doAcao === 'function') { d.defaultView.doAcao('socgedAjuda'); return true; }
    return false;
  },

  linhaNaPastinha: function ({ nome }) {
    return !![...((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.querySelectorAll('td.td-nome-arquivo')].find((t) => t.dataset.nomeArquivo === nome);
  },

  clicarAssinarNaPastinha: function ({ nome }) {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const td = [...d.querySelectorAll('td.td-nome-arquivo')].find((t) => t.dataset.nomeArquivo === nome);
    if (!td) return { ok: false, motivo: 'Não achei o PDF na pastinha da ficha.' };
    const dica = (e) => `${e.getAttribute('onmouseover') || ''} ${e.title || ''} ${e.getAttribute('tooltype') || ''} ${e.alt || ''}`;
    const linha = td.closest('tr') || td.parentElement;
    const icone = [...linha.querySelectorAll('*')].find((e) => /assinar arquivo/i.test(dica(e)));
    if (!icone) return { ok: false, motivo: 'Não achei o ícone de assinar desse PDF.' };
    (icone.closest('a') || icone).click();
    return { ok: true };
  },

  pedidoDoPdf: function () {
    const m = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.getElementById('mensagemProc');
    const n = (m?.innerText || '').match(/Pedido:\s*(\d+)/i);
    return n ? n[1] : null;
  },

  // ASO (cad017): na ficha, menu Atendimento → ASO = doAcao('aso'). Mapa em soc-mapeamento/NOTAS.md, seção 10.
  abrirAso: function () {
    ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow.doAcao('aso');
    return true;
  },

  asoPronto: function () {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    return d.readyState === 'complete' && /cad017/.test(d.location.href) && d.forms[0]?.ac ? d.forms[0].ac.value : false;
  },

  // Parecer do ASO = o parecer que o médico deu na ficha (só "Apto" é automático). Observação é opcional.
  preencherAso: function ({ observacao, altura = false }) {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const f = w.document.forms[0];
    const sel = f?.parecerAso;
    if (!sel) return { ok: false, motivo: 'Não achei o campo Parecer no ASO.' };
    const apto = [...sel.options].find((o) => /^apto/i.test(o.text.trim()));
    if (!apto) return { ok: false, motivo: 'O ASO não tem a opção "Apto para função".' };
    sel.value = apto.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    sel.style.outline = '3px solid #F5B82E';
    // "Parecer Trabalho em Altura": só quando a evolução do médico diz apto para altura (Kelson, vídeo de 31/10).
    let parecerAltura = null;
    if (altura) {
      const selAltura = [...f.elements].find((e) => e.tagName === 'SELECT' && e !== sel && [...e.options].some((o) => /apto para trabalho em altura/i.test(o.text)));
      const op = selAltura && [...selAltura.options].find((o) => /^apto para trabalho em altura/i.test(o.text.trim()));
      if (op) { selAltura.value = op.value; selAltura.dispatchEvent(new Event('change', { bubbles: true })); parecerAltura = op.text.trim(); }
    }
    if (observacao) {
      const el = f.comentarioAso_EDITORHTML;
      const editor = w.CKEDITOR?.instances?.[el?.id] || w.CKEDITOR?.instances?.comentarioAso_EDITORHTML;
      if (editor) editor.setData(`<p>${observacao.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</p>`);
      else if (el) el.value = observacao;
    }
    return { ok: true, parecer: apto.text.trim(), parecerAltura };
  },

  asoTemGed: function () {
    const f = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.forms[0];
    return !!(f?.codigoSocGed?.value);
  },

  gerarPdfAso: function () {
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    if (typeof w.validaAcessoGed !== 'function') return { ok: false, motivo: 'Não achei a opção de gerar o PDF do ASO.' };
    w.validaAcessoGed('gera_pdf', '6');
    return { ok: true };
  },

  // Ajustes do questionário que o médico escolheu na Fila: marca/desmarca as caixas no modo Alterar. Não salva.
  marcarQuestionario: function ({ ajustes }) {
    const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const limpo = (el) => (el?.innerText ?? el?.textContent ?? '').replace(/\s+/g, ' ').trim();
    const norm = (x) => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
    const tituloAntes = (tr) => {
      for (let el = tr; el && el !== d.body; el = el.parentElement?.closest('tr')) {
        for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
          if (p.querySelector('input, select, textarea')) continue;
          const t = limpo(p);
          if (t && t.length <= 80) return t;
        }
      }
      return '';
    };
    const opcaoDe = (inp) => {
      let t = inp.id ? limpo(d.querySelector(`label[for="${inp.id}"]`)) : '';
      for (let n = inp.nextSibling; !t && n; n = n.nextSibling) {
        if (n.nodeType === 1 && n.matches('input, br')) break;
        t = (n.nodeType === 3 ? n.textContent : limpo(n)).trim();
      }
      return t;
    };
    const itens = [...d.querySelectorAll('input[name^="it0"]')].filter((i) => i.type === 'checkbox' || i.type === 'radio').map((inp) => {
      const tr = inp.closest('tr');
      const td = inp.closest('td');
      const rotulo = limpo(tr?.querySelector('td.label') || (tr && tr.cells[0] !== td ? tr.cells[0] : null));
      return { inp, opcao: norm(opcaoDe(inp)), rotulo: norm(rotulo), titulo: norm(tr ? tituloAntes(tr) : '') };
    });
    const feitos = [];
    const faltaram = [];
    for (const a of ajustes || []) {
      const item = norm(a.item);
      const grupo = norm(a.grupo);
      const sim = /^sim$/i.test(a.para);
      const doGrupo = (x) => !grupo || x.titulo.includes(grupo) || grupo.includes(x.titulo);
      // Caixa com o nome do item ao lado (ex.: "Pressão Alta").
      let alvo = itens.filter((x) => x.inp.type === 'checkbox' && x.opcao === item);
      if (alvo.length > 1) alvo = alvo.filter(doGrupo);
      if (alvo.length === 1) {
        alvo[0].inp.checked = sim;
      } else {
        // Pergunta com opções Sim/Não (rádio) na mesma linha.
        const radios = itens.filter((x) => x.inp.type === 'radio' && x.rotulo === item && doGrupo(x));
        const escolhido = radios.find((x) => x.opcao === norm(a.para)) || (radios.length && radios.find((x) => (sim ? /^s/ : /^n/).test(x.opcao)));
        if (!escolhido) { faltaram.push(`${a.grupo} › ${a.item}`); continue; }
        escolhido.inp.checked = true;
        alvo = [escolhido];
      }
      const el = alvo[0].inp;
      el.dispatchEvent(new Event('click', { bubbles: true }));
      if (el.type === 'checkbox' && el.checked !== sim) el.checked = sim; // o clique de alguns SOCs inverte de novo
      el.dispatchEvent(new Event('change', { bubbles: true }));
      (el.closest('td') || el).style.outline = '3px solid #F5B82E';
      feitos.push(`${a.item} → ${a.para}`);
    }
    return { feitos, faltaram };
  },

  colarNoCampo: function ({ campo, texto: textoInteiro, esperado }) {
    let texto = textoInteiro;
    const w = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const d = w.document;
    const el = d.querySelector(`textarea[name="${campo}"]`);
    if (!el) return { ok: false, motivo: `Campo ${campo} não encontrado nesta ficha` };
    // Se o texto no SOC mudou depois da revisão, não sobrescreve: a revisão está desatualizada.
    const limpo = (x) => String(x || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    if (esperado != null && limpo(el.value) !== limpo(esperado)) {
      return { ok: false, motivo: 'O texto deste campo mudou no SOC depois da revisão. Leia o dia de novo e revise outra vez.' };
    }
    // Limite do campo (a anamnese tem 3900). Passou: o exame físico vai para o "Texto Livre" (Kelson, 31/10).
    const limiteDe = (t) => {
      if (t.maxLength > 0) return t.maxLength;
      const perto = (t.closest('tr')?.innerText || '').match(/Limite de caracteres:\s*(\d+)/i);
      return perto ? Number(perto[1]) : null;
    };
    const limite = limiteDe(el);
    let movido = null;
    if (limite && texto.length > limite - 20) {
      const livre = d.querySelector('textarea[name="textoLivre"]');
      const linhas = texto.split('\n');
      const ini = linhas.findIndex((l) => /^\s*exame f[ií]sico/i.test(l));
      let fim = ini < 0 ? -1 : linhas.findIndex((l, i) => i > ini && /^\s*(conduta|parecer|apt[oa]|inapt[oa])\b/i.test(l));
      if (fim < 0) fim = linhas.length;
      if (!livre || ini < 0) return { ok: false, motivo: `O texto passa do limite do campo (${limite} caracteres) e não achei o exame físico para levar ao Texto Livre. Encurte o texto.` };
      const exame = linhas.slice(ini, fim).join('\n').trim();
      texto = [...linhas.slice(0, ini), ...linhas.slice(fim)].join('\n').replace(/\n{3,}/g, '\n\n').trim();
      const limiteLivre = limiteDe(livre);
      const novoLivre = [livre.value.trim(), exame].filter(Boolean).join('\n\n');
      if (texto.length > limite - 20 || (limiteLivre && novoLivre.length > limiteLivre - 20)) return { ok: false, motivo: `Mesmo com o exame físico no Texto Livre, o texto passa do limite (${limite} caracteres). Encurte o texto.` };
      livre.value = novoLivre;
      livre.dispatchEvent(new Event('input', { bubbles: true }));
      livre.dispatchEvent(new Event('change', { bubbles: true }));
      livre.style.outline = '3px solid #F5B82E';
      movido = 'o exame físico foi para o Texto Livre (a anamnese passava do limite)';
    }
    const editor = w.CKEDITOR?.instances?.[el.id] || w.CKEDITOR?.instances?.[campo];
    if (editor) {
      editor.setData(texto.split('\n').map((l) => `<p>${l.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</p>`).join(''));
    } else {
      el.value = texto;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    el.scrollIntoView({ block: 'center' });
    el.style.outline = '3px solid #F5B82E';
    el.focus();
    return { ok: true, movido };
  },
};

// ---------- orquestração (Node) ----------

const AGENDA = { acao: 'sis028.do', codigo: '236' };
const ASSINATURA = { acao: 'cad422!browser.action', codigo: '797' };

export async function estadoSoc(sessao) {
  let agendaAberta = null;
  try { agendaAberta = await rodar(sessao, pg.agendaSeAberta); } catch {}
  return { logado: await rodar(sessao, pg.logado), frame: await rodar(sessao, pg.frameInfo), usuario: await usuarioLogado(sessao), agendaAberta };
}

export async function usuarioLogado(sessao) {
  try {
    return (await rodar(sessao, pg.usuarioLogado)) || '';
  } catch {
    return '';
  }
}

export async function abrirAgenda(sessao) {
  await rodar(sessao, pg.abrirPrograma, AGENDA);
  await esperar(800);
  await esperarAte(sessao, pg.agendaPronta, {}, { descricao: 'a agenda' });
}

export async function agendaAtual(sessao) {
  await abrirAgenda(sessao);
  return rodar(sessao, pg.agendaAtual);
}

export async function lerAgenda(sessao, { data, agenda }) {
  await abrirAgenda(sessao);
  let atual = await rodar(sessao, pg.agendaAtual);
  // 1) Troca de agenda (no dia que já está aberto), como o botão "Trocar agenda" do SOC.
  if (agenda?.codigo && agenda.codigo !== atual.codigo) {
    await rodar(sessao, pg.irParaDia, { codigo: agenda.codigo, nome: agenda.nome, data: `${atual.dia}/${atual.mes}/${atual.ano}` });
    await esperar(800);
    await esperarAte(sessao, pg.agendaPronta, {}, { descricao: `a agenda ${agenda.nome}` });
    atual = await rodar(sessao, pg.agendaAtual);
    if (atual.codigo !== agenda.codigo) throw new Error(`O SOC não trocou para a agenda ${agenda.nome}.`);
  }
  // 2) Troca de dia, como o calendário da agenda.
  const [dia, mes, ano] = data.split('/');
  const mesmoDia = Number(atual.dia) === Number(dia) && Number(atual.mes) === Number(mes) && atual.ano === ano;
  if (!mesmoDia) {
    await rodar(sessao, pg.irParaDia, { data });
    await esperar(800);
    await esperarAte(sessao, pg.agendaPronta, {}, { descricao: 'a agenda do dia' });
  }
  const linhas = await rodar(sessao, pg.agendaDoDia, { data });
  if (!linhas) throw new Error(`A agenda não abriu no dia ${data}. Confira a data e o local.`);
  return { agenda: await rodar(sessao, pg.agendaAtual), linhas };
}

// Clica em Salvar (doAcao('save')) e confere: a página recarrega fora do modo Alterar, sem alerta de erro.
export async function salvarEConferir(sessao) {
  await rodar(sessao, pg.prepararDialogos, { aceitar: 'salvar|gravar|confirma|deseja continuar' });
  await rodar(sessao, pg.salvarFicha);
  const fim = Date.now() + 45000;
  let e;
  while (Date.now() < fim) {
    await esperar(700);
    try { e = await rodar(sessao, pg.estadoAcao); } catch { continue; } // no meio da recarga
    if (e.recarregou && e.pronto && e.ac && e.ac !== 'alt') return { ok: true };
    if (!e.recarregou && e.alertas.some((a) => !a.startsWith('✓'))) return { ok: false, motivo: e.alertas.join(' / ') };
  }
  return { ok: false, motivo: e?.alertas?.length ? e.alertas.join(' / ') : 'O SOC não confirmou que gravou. Confira a ficha.' };
}

// Gera o PDF da ficha e confere pelo sinal da própria ficha (fichaPossuiGed).
export async function gerarPdfEConferir(sessao, linha, { assinar = false } = {}) {
  const r = await gerarPdfPelaImpressao(sessao, { assinar });
  if (r.ok || !r.tentarOutro) return r;
  return gerarPdfPorPedido(sessao, linha);
}

const contarFichasPdf = async (sessao) => ((await rodar(sessao, pg.documentosDaFicha)) || []).filter((x) => /^ficha_?cl/i.test(x.nome)).length;

// Caminho principal (o do Kelson): impressão da ficha → "Gerar PDF no SOCGED". Para antes de assinar.
async function gerarPdfPelaImpressao(sessao, { assinar = false } = {}) {
  let antes = 0;
  try { antes = await contarFichasPdf(sessao); } catch { /* sem a lista, conta como zero */ }
  const a = await rodar(sessao, pg.abrirImpressaoFicha);
  if (!a?.ok) return { ok: false, tentarOutro: true, motivo: a?.motivo };
  try {
    try {
      await esperarAte(sessao, pg.impressaoPronta, {}, { descricao: 'a impressão da ficha', tempo: 45000 });
    } catch {
      return { ok: false, tentarOutro: true, motivo: 'A impressão da ficha não abriu.' };
    }
    const r = await passarJanelaPdf(sessao, { assinar, oQue: 'da ficha' });
    if (!r.ok) return r;
    if (assinar) return r;
    // Confere na pastinha (no caminho manual o arquivo aparece em segundos).
    const confere = Date.now() + 30000;
    while (Date.now() < confere) {
      try { if (await contarFichasPdf(sessao) > antes) return { ok: true }; } catch { /* tenta de novo */ }
      await esperar(2000);
    }
    return { ok: true, aviso: 'O SOC disse que criou o PDF, mas ele ainda não apareceu na pastinha da ficha.' };
  } finally {
    try { await rodar(sessao, pg.fecharImpressao); } catch { /* a ficha pode ter recarregado */ }
  }
}

// Licença: pede o PDF ao SOC (fila de 5 a 30 min). Não espera o arquivo: o lote seguinte assina quando ele chegar.
export async function pedirPdfLicenca(sessao) {
  await rodar(sessao, pg.prepararDialogos, { aceitar: 'socged|vincular|pdf|gerar|deseja continuar' });
  const r = await rodar(sessao, pg.gerarPdfLicenca);
  if (!r?.ok) return r;
  const fim = Date.now() + 45000;
  while (Date.now() < fim) {
    await esperar(1500);
    try {
      await rodar(sessao, pg.responderVincularGed);
      const pedido = await rodar(sessao, pg.pedidoDoPdf);
      if (pedido) return { ok: true, pedido };
      const e = await rodar(sessao, pg.estadoAcao);
      if (!e.recarregou && e.alertas.some((a) => a.startsWith('✗') || (!a.startsWith('✓') && RECUSA_SOC.test(a)))) return { ok: false, motivo: e.alertas.join(' / ') };
    } catch { /* recarregando */ }
  }
  return { ok: false, motivo: 'O SOC não confirmou o pedido do PDF da licença.' };
}

// Um atendimento do lote: abre a ficha (ou licença) e faz só o que falta, sem mexer no texto.
// pdf: gera o PDF que falta. assinar: assina. aso: grava o ASO como Apto (só se a ficha já diz Apto), gera e assina.
export async function passoDoLote(sessao, { linha, data, agenda, programa, estadoPrincipal, estadoAso, pdf, assinar, aso, altura = false }) {
  const r = {};
  await lerAgenda(sessao, { data, agenda });
  await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
  await esperar(800);
  await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha', tempo: 45000 });
  const docs = (await rodar(sessao, pg.documentosDaFicha)) || null;
  if (programa === 'cad016') {
    const atual = estadoPelosDocumentos(docs, 'licenca');
    if (atual === 'pdf_pendente' && assinar) r.assinatura = await assinarPdfDoc(sessao, 'licenca');
    else if (atual === 'sem_pdf' && pdf && estadoPrincipal !== 'pdf_pedido') r.pedido = await pedirPdfLicenca(sessao);
    else if (atual === 'sem_pdf' && estadoPrincipal === 'pdf_pedido') r.aguardando = true;
    return r;
  }
  const atual = estadoPelosDocumentos(docs, 'ficha');
  if (atual === 'sem_pdf' && pdf) r.pdf = await gerarPdfEConferir(sessao, linha, { assinar });
  else if (atual === 'pdf_pendente' && assinar) r.assinatura = await assinarPdfDoc(sessao, 'ficha');
  if (aso && estadoAso !== 'assinada') {
    await veu(sessao, { titulo: 'Gravando o ASO', detalhe: 'Parecer da ficha: Apto para função' });
    r.aso = await gravarAso(sessao, { linha, assinar, altura });
  }
  return r;
}

// Assina o PDF de ficha mais novo ainda sem assinatura, pelo ícone da pastinha. O véu sai e a janela do SOC vem
// para a frente: se o SOC pedir o certificado ou a senha, quem responde é o médico. O app só espera e confere.
export const assinarPdfFicha = (sessao) => assinarPdfDoc(sessao, 'ficha');

// Assina pela pastinha (quadradinho amarelo "Assinar arquivo digitalmente") o PDF mais novo do tipo, sem assinatura.
export async function assinarPdfDoc(sessao, tipo) {
  const docs = (await rodar(sessao, pg.documentosDaFicha)) || [];
  const alvo = docs.filter((x) => NOME_DOCUMENTO[tipo].test(x.nome) && !x.assinado && x.assinaturas < x.necessarias).at(-1);
  if (!alvo) return { ok: false, motivo: `Não achei PDF ${tipo === 'licenca' ? 'da licença' : 'da ficha'} sem assinatura na pastinha.` };
  if (!(await rodar(sessao, pg.abrirPastinha))) return { ok: false, motivo: 'Não consegui abrir a pastinha da ficha.' };
  try {
    await esperarAte(sessao, pg.linhaNaPastinha, { nome: alvo.nome }, { descricao: 'a pastinha da ficha', tempo: 20000 });
  } catch {
    return { ok: false, motivo: 'A pastinha da ficha não mostrou o PDF.' };
  }
  await tirarVeu(sessao);
  await trazerParaFrente(sessao);
  const c = await rodar(sessao, pg.clicarAssinarNaPastinha, { nome: alvo.nome });
  if (!c?.ok) return c;
  const fim = Date.now() + 180000;
  while (Date.now() < fim) {
    await esperar(3000);
    try {
      const d = ((await rodar(sessao, pg.documentosDaFicha)) || []).find((x) => x.nome === alvo.nome);
      if (d && (d.assinado || d.assinaturas >= d.necessarias)) return { ok: true };
    } catch { /* a ficha pode estar recarregando */ }
  }
  return { ok: false, motivo: 'A assinatura não terminou. Se o SOC pediu o certificado, conclua na janela do SOC.' };
}

// Anda pela janela Biometria → Criar PDF → Assinatura que está no iframe escondido. Com assinar, também clica em
// "Assinar PDF Digitalmente" (o médico escolheu "…e assinar" ou o lote com assinatura).
async function passarJanelaPdf(sessao, { assinar = false, oQue = '' } = {}) {
  const alvo = assinar ? 'assinado' : 'pronto';
  let fase = '';
  const fim = Date.now() + (assinar ? 150000 : 90000);
  while (Date.now() < fim && fase !== alvo) {
    await esperar(1000);
    const p = await rodar(sessao, pg.passoPdfImpressao, { assinar });
    fase = p.fase;
    if (fase === 'erro') return { ok: false, motivo: p.motivo };
  }
  if (fase === alvo) return { ok: true, assinado: assinar };
  if (assinar && ['assinando', 'pronto_sem_assinar'].includes(fase)) return { ok: true, assinado: false, aviso: `O PDF ${oQue} foi gerado, mas a assinatura não terminou.` };
  return { ok: false, motivo: `O SOC não terminou de criar o PDF ${oQue}.` };
}

// Reserva: "Gerar PDF" da própria ficha. Vira um pedido de processamento e o PDF chega minutos depois.
async function gerarPdfPorPedido(sessao, linha) {
  await rodar(sessao, pg.prepararDialogos, { aceitar: 'socged|vincular|pdf|gerar|deseja continuar' });
  const r = await rodar(sessao, pg.gerarPdfFicha);
  if (!r?.ok) return r;
  // O "Sim" da pergunta do SOC vira um pedido de processamento; o PDF chega na pastinha minutos depois.
  // Aqui basta o SOC confirmar o pedido. A próxima leitura do dia confere o PDF pela pastinha.
  let respondeu = false;
  const fim = Date.now() + 60000;
  while (Date.now() < fim) {
    await esperar(1500);
    let e;
    try {
      if (!respondeu) respondeu = await rodar(sessao, pg.responderVincularGed);
      const pedido = respondeu && await rodar(sessao, pg.pedidoDoPdf);
      if (pedido) return { ok: true, pedido };
      e = await rodar(sessao, pg.estadoAcao);
    } catch { continue; }
    if (!e.recarregou && e.alertas.some((a) => a.startsWith('✗') || (!a.startsWith('✓') && /erro|não foi|nao foi|inválid/i.test(a)))) return { ok: false, motivo: e.alertas.join(' / ') };
  }
  return { ok: false, motivo: respondeu ? 'O SOC não confirmou o pedido do PDF. Confira a pastinha da ficha.' : 'O SOC não abriu a pergunta de criar o PDF. Gere pela ficha (Imprimir Ficha Clínica).' };
}

// ASO a partir da ficha aberta: Alterar → parecer Apto → Salvar → PDF do ASO. Se o SOC recusar (exames ainda não
// prontos, por exemplo), o ASO fica pendente e o motivo volta para o médico.
// O SOC recusa o parecer quando faltam exames ("Não é permitido gravar esse ASO com Parecer, pois a Ficha Clínica
// possui Resultado de Exames sem data"). Esse aviso é um alert: os diálogos ficam preparados antes de mexer no parecer
// (senão o alert trava a página) e, se ele vier, o ASO não é salvo: a ficha é reaberta e o ASO fica pendente.
const RECUSA_SOC = /erro|não foi|nao foi|inválid|invalid|não é permitido|nao e permitido|não pode|nao pode|obrigat/i;

export async function gravarAso(sessao, { observacao = '', linha = null, assinar = false, altura = false } = {}) {
  const voltarParaFicha = async () => {
    if (!linha?.hrefFicha) return;
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
  };
  const desistir = async (motivo) => {
    let faltam = [];
    try {
      await voltarParaFicha();
      // Quais exames estão sem data (Resultado de Exames): é isso que o SOC cobra para aceitar o parecer.
      if (/exame|sem data/i.test(motivo || '')) {
        await rodar(sessao, (a) => { ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow.doAcao(a); return true; }, 'resultado');
        await esperar(800);
        await esperarAte(sessao, () => { const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument; return d.readyState === 'complete' && /cad012/.test(d.location.href); }, {}, { descricao: 'o resultado de exames', tempo: 30000 });
        faltam = (await rodar(sessao, pg.examesSemData)).faltam || [];
        await voltarParaFicha();
      }
    } catch { /* a ficha reabre na próxima ação */ }
    // Como o Kelson resume: "ASO retido por falta de exames", com a lista do que falta.
    if (faltam.length || /exame|sem data/i.test(motivo || '')) return { ok: false, pendente: true, motivo: `ASO retido por falta de exames${faltam.length ? `: ${faltam.join(', ')}` : ''}.`, faltam };
    return { ok: false, pendente: true, motivo, faltam };
  };
  try {
    await rodar(sessao, pg.abrirAso);
    await esperar(800);
    await esperarAte(sessao, pg.asoPronto, {}, { descricao: 'o ASO', tempo: 45000 });
    await rodar(sessao, pg.entrarModoAlterar);
    await esperar(800);
    await esperarAte(sessao, () => { const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument; return d.readyState === 'complete' && /cad017/.test(d.location.href) && d.forms[0]?.ac?.value === 'alt'; }, {}, { descricao: 'o ASO em modo Alterar' });
    await rodar(sessao, pg.prepararDialogos, { aceitar: 'salvar|gravar|confirma|deseja continuar' });
    const p = await rodar(sessao, pg.preencherAso, { observacao, altura });
    if (!p?.ok) return desistir(p?.motivo);
    await esperar(1200);
    const aviso = (await rodar(sessao, pg.estadoAcao)).alertas.find((a) => !a.startsWith('✓'));
    if (aviso) return desistir(`o SOC não deixou gravar o parecer: "${aviso.replace(/^✗ /, '')}"`);
    const salvo = await salvarEConferir(sessao);
    if (!salvo.ok) return desistir(salvo.motivo);
    await veu(sessao, { titulo: assinar ? 'Gerando e assinando o PDF do ASO' : 'Gerando o PDF do ASO', detalhe: 'Imprimir ASO → Gerar PDF no SOCGED' });
    // Caminho do Kelson: Imprimir ASO → "Gerar PDF no SOCGED" (→ "Assinar PDF Digitalmente").
    try {
      await esperarAte(sessao, pg.asoPronto, {}, { descricao: 'o ASO gravado', tempo: 30000 });
      const imp = await rodar(sessao, pg.abrirImpressaoAso);
      if (imp?.ok) {
        try {
          await esperarAte(sessao, pg.impressaoPronta, {}, { descricao: 'a impressão do ASO', tempo: 45000 });
          const j = await passarJanelaPdf(sessao, { assinar, oQue: 'do ASO' });
          if (j.ok) return { ok: true, pdf: true, assinado: !!j.assinado, aviso: j.aviso };
          return { ok: true, pdf: false, motivo: j.motivo };
        } finally {
          try { await rodar(sessao, pg.fecharImpressao); } catch { /* */ }
        }
      }
    } catch { /* segue pela reserva */ }
    // Reserva: pedido de processamento (mais lento, sem assinar).
    await rodar(sessao, pg.prepararDialogos, { aceitar: 'socged|vincular|pdf|gerar|deseja continuar' });
    const g = await rodar(sessao, pg.gerarPdfAso);
    if (!g?.ok) return { ok: true, pdf: false, motivo: g?.motivo };
    const fim = Date.now() + 60000;
    while (Date.now() < fim) {
      await esperar(1500);
      try {
        await rodar(sessao, pg.responderVincularGed);
        const pedido = await rodar(sessao, pg.pedidoDoPdf);
        if (pedido) return { ok: true, pdf: true, pedido };
        if (await rodar(sessao, pg.asoTemGed)) return { ok: true, pdf: true };
        const e = await rodar(sessao, pg.estadoAcao);
        if (!e.recarregou && e.alertas.some((a) => a.startsWith('✗') || (!a.startsWith('✓') && RECUSA_SOC.test(a)))) return { ok: true, pdf: false, motivo: e.alertas.join(' / ') };
      } catch { /* recarregando */ }
    }
    return { ok: true, pdf: false, motivo: 'O SOC não confirmou o PDF do ASO.' };
  } catch (e) {
    return { ok: false, motivo: e.message };
  }
}

// Todas as agendas que o SOC oferece para troca (mesma lista do botão "Trocar agenda").
export async function agendasDoSoc(sessao) {
  await abrirAgenda(sessao);
  return rodar(sessao, pg.listarAgendas);
}

// O mesmo, com o véu sobre o SOC (para quando o médico pede a lista pelo painel).
export async function listarAgendas(sessao) {
  await veu(sessao, { titulo: 'Buscando a lista de agendas', detalhe: 'A mesma do botão Trocar agenda do SOC' });
  try {
    return await agendasDoSoc(sessao);
  } finally {
    await tirarVeu(sessao);
  }
}

// Leitura por código: a agenda tem de estar aberta na tela (lerAgenda). Devolve null se não deu; aí vale o caminho
// normal (abrir a ficha na tela).
export async function lerFichaPorCodigo(sessao, linha) {
  let b;
  try {
    b = await rodar(sessao, pg.baixarFicha, { href: linha.hrefFicha });
  } catch (e) {
    if (/sessão do SOC caiu/.test(e.message)) throw e;
    return null;
  }
  if (!b?.ok) return null;
  try {
    const ficha = await rodar(sessao, pg.lerFicha);
    if (ficha?.existe) {
      try { ficha.documentos = await rodar(sessao, pg.documentosDaFicha); } catch { ficha.documentos = null; }
    }
    return ficha;
  } finally {
    await rodar(sessao, pg.soltarFichaInerte);
  }
}

// Abre a ficha de uma linha da agenda (a própria função do SOC troca de empresa se precisar) e lê.
export async function lerFichaDaLinha(sessao, linha) {
  await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
  await esperar(800);
  await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
  const ficha = await rodar(sessao, pg.lerFicha);
  if (ficha?.existe) {
    try { ficha.documentos = await rodar(sessao, pg.documentosDaFicha); } catch { ficha.documentos = null; }
  }
  return ficha;
}

export async function listarAssinaturas(sessao, { de, ate, classificacoes = [8, 15, 6] }) {
  await rodar(sessao, pg.abrirPrograma, ASSINATURA);
  await esperar(800);
  await esperarAte(sessao, pg.telaAssinaturaPronta, {}, { descricao: 'a Assinatura Digital' });
  const saida = [];
  for (const classificacao of classificacoes) {
    for (const modo of ['TODOS_DOCUMENTOS_PENDENTES', 'TODOS_DOCUMENTOS_ASSINADOS']) {
      const docs = await rodar(sessao, pg.listarGed, { classificacao, modo, de, ate });
      for (const doc of docs) saida.push({ ...doc, classificacao, assinado: modo.endsWith('ASSINADOS') });
    }
  }
  return saida;
}

// Só abre a ficha no Edge e traz a janela para frente (para gerar ficha, PDF ou assinar). Não muda nada.
export async function abrirFicha(sessao, { linha, data, agenda }) {
  await veu(sessao, { titulo: 'Abrindo a ficha', detalhe: `${data} · ${linha.hora}` });
  try {
    await lerAgenda(sessao, { data, agenda });
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
  } finally {
    await tirarVeu(sessao);
  }
  await trazerParaFrente(sessao);
}

// Abre a ficha em modo Alterar e cola o texto. Quem confere e salva é o médico.
export async function colar(sessao, { linha, data, agenda, campo, texto, esperado, ajustes, salvar = false, gerarPdf = false, assinar = false, aso = false, altura = false }) {
  let r;
  await veu(sessao, { titulo: 'Preparando a ficha para colar', detalhe: `${data} · ${linha.hora}` });
  try {
    await lerAgenda(sessao, { data, agenda });
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
    await veu(sessao, { titulo: 'Preparando a ficha para colar', detalhe: 'Entrando em modo Alterar (nada será salvo)' });
    await rodar(sessao, pg.entrarModoAlterar);
    await esperar(800);
    await esperarAte(sessao, (a) => {
      const d = ((window.__revisaInerte && document.getElementById('revisaInerte')) || document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
      return d.readyState === 'complete' && d.forms[0]?.ac?.value === 'alt' && !!d.querySelector(`textarea[name="${a.campo}"]`);
    }, { campo }, { descricao: 'o modo Alterar' });
    // Um alert do SOC (ex.: "excede a quantidade de caracteres") travaria a aba: os diálogos ficam respondidos.
    await rodar(sessao, pg.prepararDialogos, { aceitar: '^$' });
    r = await rodar(sessao, pg.colarNoCampo, { campo, texto, esperado });
    if (r?.ok && ajustes?.length) r.questionario = await rodar(sessao, pg.marcarQuestionario, { ajustes });
    if (r?.ok && salvar) {
      await veu(sessao, { titulo: 'Salvando a ficha no SOC', detalhe: `${data} · ${linha.hora}` });
      r.salvo = await salvarEConferir(sessao);
      if (r.salvo.ok && gerarPdf) {
        await veu(sessao, { titulo: 'Gerando o PDF da ficha', detalhe: 'O SOC grava o PDF no SOCGED' });
        r.pdf = await gerarPdfEConferir(sessao, linha, { assinar });
        if (r.pdf.ok && assinar) r.assinatura = r.pdf.assinado ? { ok: true } : await assinarPdfFicha(sessao);
      }
      if (r.salvo.ok && aso) {
        await veu(sessao, { titulo: 'Gravando o ASO', detalhe: 'Parecer: Apto para função' });
        r.aso = await gravarAso(sessao, { linha, assinar, altura });
      }
    }
  } finally {
    // O véu sai antes de devolver a janela: agora quem confere e salva é o médico.
    await tirarVeu(sessao);
  }
  await trazerParaFrente(sessao);
  return r;
}
