// Leitura do SOC dentro do Edge do auditor. Mapeamento das telas em NOTAS.md.
// Regra do Kelson: o app lê livremente; a única escrita é `colarNoCampo`, que preenche o campo
// em modo Alterar e NUNCA chama doAcao('save'), doAcao('save_parc') nem assinatura.
import { rodar, esperarAte, esperar, trazerParaFrente } from './cdp.js';
import { veu, tirarVeu } from './veu.js';

// ---------- funções que rodam na página (serializadas por cdp.rodar) ----------

export const pg = {
  frameInfo: function () {
    const f = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'));
    if (!f) return { semFrame: true, titulo: document.title };
    const d = f.contentDocument;
    return { titulo: d.title, url: d.location.href, ac: d.forms[0]?.ac?.value ?? null, pronto: d.readyState === 'complete' };
  },

  // Quem está logado: o SOC escreve o nome do usuário na barra de baixo de cada tela (#barraInferior .barraTxt).
  usuarioLogado: function () {
    const docs = [document];
    try { if ((document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentDocument) docs.push((document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument); } catch {}
    for (const d of docs) {
      const t = d.querySelector('#barraInferior .barraTxt')?.textContent.replace(/\s+/g, ' ').trim();
      if (t && t.length >= 3) return t;
    }
    return '';
  },

  // Agenda que está aberta agora no SOC, sem navegar (só se a tela atual for a agenda).
  agendaSeAberta: function () {
    const f = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentDocument?.forms?.sis028Form;
    return f?.codigoUsuarioAgenda?.value ? { codigo: f.codigoUsuarioAgenda.value, nome: f.nomeUsuarioAgenda?.value || '' } : null;
  },

  logado: function () {
    return !!(document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')) && (typeof window.MainJava === 'function' || !!document.getElementById('frm-acesso-programa-frame'));
  },

  // Menu antigo: MainJava. Menu novo: o form #frm-acesso-programa-frame, com o token da página na URL.
  abrirPrograma: function ({ acao, codigo }) {
    if (typeof window.MainJava === 'function') {
      window.MainJava(acao, '', codigo);
      return true;
    }
    const f = document.getElementById('frm-acesso-programa-frame');
    if (!f) throw new Error('Não achei o menu do SOC nesta aba.');
    const token = (f.getAttribute('action').match(/TOKEN=([^&]*)/) || [])[1] || '';
    f.setAttribute('action', `${acao}?org.apache.struts.taglib.html.TOKEN=${token}&&param=&codPrg=${codigo}`);
    f.target = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).name || 'socframe';
    f.submit();
    return true;
  },

  agendaPronta: function () {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    return d.readyState === 'complete' && !!d.forms.sis028Form && !!d.getElementById('targetTable');
  },

  agendaAtual: function () {
    const f = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument.forms.sis028Form;
    return {
      codigo: f.codigoUsuarioAgenda.value,
      nome: f.nomeUsuarioAgenda.value,
      dia: f.auxDia.value, mes: f.auxMes.value, ano: f.auxAno.value,
    };
  },

  // Troca agenda e dia do mesmo jeito que o calendário da agenda (função altdata do SOC):
  // ac=browse, valorPeriodo = período marcado, registro no log da agenda e envio por loadSubmit (que põe o token).
  irParaDia: function ({ codigo, nome, data }) {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const f = w.document.forms.sis028Form;
    const [dia, mes, ano] = data.split('/');
    const trocaAgenda = !!codigo && codigo !== f.codigoUsuarioAgenda.value;
    if (codigo) f.codigoUsuarioAgenda.value = codigo;
    if (nome) f.nomeUsuarioAgenda.value = nome;
    // Troca de agenda do mesmo jeito que a janela "Agendas" do SOC (executaTrocaAgenda): usuarioAgenda e ";changeuser".
    if (trocaAgenda) {
      if (f.usuarioAgenda) f.usuarioAgenda.value = codigo;
      if (f.nomeTelaHidden) f.nomeTelaHidden.value = '';
      if (f.usuarioAgendaSocnet) f.usuarioAgendaSocnet.value = '';
      if (f.logAcaoAgendaInterceptor) f.logAcaoAgendaInterceptor.value += ';changeuser';
    }
    f.auxDia.value = String(Number(dia));
    f.auxMes.value = String(Number(mes));
    f.auxAno.value = ano;
    const periodos = [...f.querySelectorAll('input[name=agendaPeriodo]')];
    const dia3 = periodos.find((i) => i.value === '3');
    if (dia3) dia3.checked = true;
    const marcado = periodos.findIndex((i) => i.checked);
    if (f.valorPeriodo && marcado >= 0) f.valorPeriodo.value = String(marcado + 1);
    f.ac.value = 'browse';
    if (f.logAcaoAgendaInterceptor && !trocaAgenda) f.logAcaoAgendaInterceptor.value += ';altData';
    if (typeof w.loadSubmit === 'function') w.loadSubmit(f);
    else f.submit();
    return true;
  },

  // Lista de agendas que o SOC oferece no botão "Trocar agenda" (janela trocaAgenda!browser.action).
  // Só lê: pede a mesma janela que o SOC abriria e tira dela o código e o nome de cada agenda.
  listarAgendas: async function () {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const achadas = new Map();
    const add = (codigo, nome, empresa) => {
      codigo = String(codigo || '').trim();
      nome = String(nome || '').replace(/\s+/g, ' ').trim();
      if (/^\d{3,}$/.test(codigo) && nome && !/^\d+$/.test(nome) && !achadas.has(codigo)) achadas.set(codigo, { codigo, nome, empresa: String(empresa || '').trim() });
    };
    const lerItens = (doc) => doc.querySelectorAll('[data-codigo-agenda]')
      .forEach((el) => add(el.dataset.codigoAgenda, el.dataset.nomeAgenda || el.textContent, el.dataset.nomeEmp));
    // Na janela: chamadas de escolha de agenda, como executaTrocaAgenda('NOME', '123', ...), com um código e um nome.
    const lerChamadas = (html) => {
      for (const m of html.matchAll(/\b((?:executa|troca|trocar|seleciona|selecionar|escolhe|escolher)\w*agenda\w*)\s*\(([^()]*)\)/gi)) {
        const args = [...m[2].matchAll(/'([^']*)'|"([^"]*)"|(\d+)/g)].map((x) => x[1] ?? x[2] ?? x[3]);
        const codigo = args.find((x) => /^\d{3,}$/.test(x));
        const nome = args.find((x) => x && !/^\d+$/.test(x) && !/^(true|false|null|S|N)$/i.test(x) && /[A-Za-zÀ-ú]/.test(x));
        if (codigo && nome) add(codigo, nome);
      }
    };
    lerItens(d); // algumas versões do SOC já trazem a lista pronta na própria agenda (#lista-agendas)
    const f = d.forms.trocaAgendaForm;
    let amostra = '';
    if (f) {
      const r = await fetch(new URL(f.getAttribute('action'), d.location.href), { method: 'POST', body: new URLSearchParams(new FormData(f)) });
      const charset = (r.headers.get('content-type') || '').match(/charset=([\w-]+)/i)?.[1] || 'windows-1252';
      const html = new TextDecoder(charset).decode(await r.arrayBuffer());
      const doc = new DOMParser().parseFromString(html, 'text/html');
      lerItens(doc);
      lerChamadas(html);
      amostra = (doc.body?.innerText || '').replace(/\s+/g, ' ').slice(0, 400);
    }
    const sf = d.forms.sis028Form;
    add(sf.codigoUsuarioAgenda.value, sf.nomeUsuarioAgenda.value);
    // Se não vier nada além da agenda atual, deixa um rastro no console da aba do SOC para entender o formato.
    if (achadas.size <= 1) console.info('[revisa.] janela de agendas sem lista reconhecida:', amostra);
    return { agendas: [...achadas.values()], reconheceu: achadas.size > 1 };
  },

  agendaDoDia: function ({ data }) {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const f = d.forms.sis028Form;
    const [dia, mes, ano] = data.split('/');
    if (Number(f.auxDia.value) !== Number(dia) || Number(f.auxMes.value) !== Number(mes) || f.auxAno.value !== ano) return null;
    const args = (href, nome) => {
      const m = href.match(new RegExp(nome + '\\(([^)]*)\\)'));
      return m ? [...m[1].matchAll(/"([^"]*)"|(true|false)/g)].map((x) => x[1] ?? x[2]) : null;
    };
    // Cabeçalho: Hora | [Profissional da Agenda] | Compromisso | Tipo Compromisso | Empresa | Funcionário | Atendido.
    // Algumas agendas (local de um médico só) não têm a coluna "Profissional da Agenda". O cabeçalho pode estar
    // numa tabela separada ou na própria tabela: vale a linha que tem "Hora" e "Funcionário".
    const tabela = d.getElementById('targetTable');
    const texto = (c) => c.textContent.trim().replace(/\s+/g, ' ');
    const linhaCab = [...d.querySelectorAll('tr')].find((tr) => {
      const t = [...tr.cells].map(texto);
      return t.some((x) => /^Hora$/i.test(x)) && t.some((x) => /^Funcion[áa]rio$/i.test(x));
    });
    const cab = linhaCab ? [...linhaCab.cells].map(texto) : [];
    while (cab.length && !cab[cab.length - 1]) cab.pop(); // o cabeçalho tem uma célula vazia a mais no fim
    const col = (nome) => cab.findIndex((x) => x.toLowerCase().startsWith(nome.toLowerCase()));
    const iProf = col('Profissional');
    const iTipo = col('Tipo Compromisso');
    const iEmp = col('Empresa');
    const iAtendido = col('Atendido');
    // semColuna: a agenda não mostra quem atende; o app traz os atendimentos com a etiqueta "profissional não definido".
    const semColuna = cab.length > 0 && iProf < 0;
    const celula = (tr, i) => (i >= 0 && tr.cells.length >= cab.length ? texto(tr.cells[i]) : null);
    const linhas = [];
    for (const tr of tabela.querySelectorAll('tr')) {
      const links = [...tr.querySelectorAll('a')].map((a) => a.getAttribute('href') || '');
      const ficha = links.find((h) => h.includes('irFichaClinica('));
      if (!ficha) continue;
      const a = args(ficha, 'irFichaClinica');
      const nomeLink = [...tr.querySelectorAll('a')].find((x) => (x.getAttribute('href') || '').includes('linkempfun('));
      // Se a linha não bate com o cabeçalho, cai no layout antigo ("Tipo - Profissional" na 2ª coluna).
      const antigo = (tr.cells[1]?.textContent.trim() || '').split(' - ');
      linhas.push({
        hora: tr.cells[0]?.textContent.trim() || '',
        profissional: semColuna ? '' : celula(tr, iProf) ?? antigo.slice(1).join(' - ').trim(),
        semColunaProfissional: semColuna || !cab.length,
        atendido: celula(tr, iAtendido) || '',
        tipoTexto: celula(tr, iTipo) ?? antigo[0],
        empresa: celula(tr, iEmp) ?? (tr.cells[3]?.textContent.trim() || ''),
        paciente: (nomeLink?.textContent.trim() || tr.cells[4]?.textContent.trim().split('\n')[0] || '').trim(),
        crecid: a[0], tipo: a[1], data: a[2], codFuncionario: a[3], seqCompromisso: a[4], codEmp: a[5],
        hrefFicha: ficha,
      });
    }
    return linhas;
  },

  abrirFichaPorHref: function ({ href }) {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    d.location.href = href;
    return true;
  },

  fichaPronta: function () {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    if (d.readyState !== 'complete' || !d.forms[0]) return false;
    return /cad009|cad016/.test(d.location.href) && !!d.forms[0].ac ? d.forms[0].ac.value : false;
  },

  // Lê a ficha aberta (cad009 periódico/admissional/retorno ou cad016 licença/perícia).
  lerFicha: function () {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const f = d.forms[0];
    const v = (n) => (f.elements[n] ? f.elements[n].value : '');
    const prog = /cad016/.test(d.location.href) ? 'cad016' : 'cad009';
    const rotulo = (txt) => {
      const l = [...d.querySelectorAll('td.label, td')].find((e) => e.children.length === 0 && e.textContent.trim() === txt);
      if (!l) return '';
      const c = l.nextElementSibling;
      return c ? c.innerText.trim() : '';
    };
    const textarea = (n) => d.querySelector(`textarea[name="${n}"]`)?.value || '';
    const selTexto = (n) => {
      const s = d.querySelector(`select[name="${n}"]`);
      return s && s.selectedIndex >= 0 ? s.options[s.selectedIndex].text.trim() : '';
    };
    const textoCorpo = d.body.innerText.replace(/\s+/g, ' ');
    // Questionário "Preenchimento do Funcionário" (itens it0…): por pergunta, o que foi marcado.
    // Regra do Kelson: pergunta de opções sem nada marcado = o paciente negou (ex.: antecedentes familiares).
    const lerQuestionario = () => {
      const limpo = (el) => (el?.innerText ?? el?.textContent ?? '').replace(/\s+/g, ' ').trim();
      const grupos = new Map();
      // Título do bloco: a linha sem campos mais próxima acima (ex.: "ANTECEDENTES FAMILIARES"), subindo pelas tabelas.
      const tituloAntes = (tr) => {
        for (let el = tr; el && el !== d.body; el = el.parentElement?.closest('tr')) {
          for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
            if (p.querySelector('input, select, textarea')) continue;
            const t = limpo(p);
            if (t && t.length <= 80) return t;
          }
        }
        return '';
      };
      for (const inp of d.querySelectorAll('input[name^="it0"]')) {
        const tipo = (inp.type || '').toLowerCase();
        const td = inp.closest('td');
        const tr = inp.closest('tr');
        // Pergunta: a célula de rótulo da mesma linha (td.label) ou a primeira célula da linha.
        const rotuloLinha = tr ? (tr.querySelector('td.label') || (tr.cells[0] !== td ? tr.cells[0] : null)) : null;
        const rotulo = limpo(rotuloLinha) || limpo(td?.previousElementSibling);
        const titulo = tr ? tituloAntes(tr) : '';
        const pergunta = (titulo && rotulo && titulo !== rotulo ? `${titulo} › ${rotulo}` : rotulo || titulo || 'Questionário').slice(0, 120);
        let opcao = '';
        if (inp.id) opcao = limpo(d.querySelector(`label[for="${inp.id}"]`));
        for (let n = inp.nextSibling; !opcao && n; n = n.nextSibling) {
          if (n.nodeType === 1 && n.matches('input, br')) break;
          opcao = (n.nodeType === 3 ? n.textContent : limpo(n)).trim();
        }
        if (!grupos.has(pergunta)) grupos.set(pergunta, { pergunta, opcoes: [], marcadas: [], textos: [] });
        const g = grupos.get(pergunta);
        if (tipo === 'checkbox' || tipo === 'radio') {
          g.opcoes.push(opcao || inp.value);
          if (tipo === 'radio') g.radio = true; // Sim/Não sem resposta não é "nega"
          if (inp.checked) g.marcadas.push(opcao || inp.value);
        } else if (tipo !== 'hidden' && inp.value.trim()) {
          g.textos.push(inp.value.trim().slice(0, 200));
        }
      }
      return [...grupos.values()].filter((g) => g.opcoes.length || g.textos.length);
    };
    const auditoria = textoCorpo.match(/Incluído por (.*?) Data Criação (\S+) Alterado por (.*?) Dt\.Últ\.Alteração (\S+)/);
    // Ficha gravada (consulta): o questionário aparece como texto, "Item ▷ Sim/Não", em blocos com título em
    // maiúsculas ("DOENÇAS NA FAMÍLIA", "HISTÓRIA OCUPACIONAL"…), depois de "PREENCHIMENTO DO FUNCIONÁRIO".
    const lerQuestionarioTexto = () => {
      const t = d.body.innerText || '';
      const ini = t.search(/PREENCHIMENTO DO FUNCION[ÁA]RIO/i);
      if (ini < 0) return [];
      const resto = t.slice(ini).replace(/^[^\n]*\n/, '');
      const fim = resto.search(/\n\s*(EXAME F[ÍI]SICO|Exame F[íi]sico|CONCLUS[ÕO]ES|Conclus[õo]es|SOLICITA[ÇC][ÕO]ES|Solicita[çc][õo]es|ASSINATURAS|Assinaturas)\b/);
      const bloco = fim < 0 ? resto.slice(0, 8000) : resto.slice(0, fim);
      const grupos = [];
      let g = null;
      const limpa = (x) => x.replace(/\s+/g, ' ').trim();
      const ehTitulo = (x) => x.length <= 90 && x === x.toLocaleUpperCase('pt-BR') && /[A-ZÀ-Ú]{3}/.test(x) && !/[▷►▶]/.test(x);
      const item = (x) => {
        const m = x.match(/^(.+?)\s*[▷►▶]\s*(.+)$/) || x.match(/^(.+?)\s+(Sim|N[ãa]o|nunca|raramente|às vezes|sempre)$/i);
        return m ? { item: m[1].trim(), valor: m[2].trim() } : null;
      };
      // Dois jeitos de as colunas lado a lado chegarem no texto:
      //  a) um quadro inteiro, depois o outro, emendados por tab ("Alergias ▷ Não<tab>HISTÓRIA SOCIAL");
      //  b) os títulos numa linha ("A<tab>B") e cada linha seguinte com um item de cada coluna.
      let colunas = null;
      for (const bruta of bloco.split('\n')) {
        const pedacos = bruta.split('\t').map(limpa).filter(Boolean);
        if (!pedacos.length) continue;
        if (pedacos.length > 1 && pedacos.every(ehTitulo)) {
          colunas = pedacos.map((titulo) => ({ titulo, itens: [] }));
          grupos.push(...colunas);
          continue;
        }
        if (colunas && pedacos.length <= colunas.length && pedacos.every((x) => item(x))) {
          // Linha com menos itens que colunas: a coluna da esquerda é a que costuma ser mais comprida.
          pedacos.forEach((x, k) => colunas[k].itens.push(item(x)));
          continue;
        }
        colunas = null;
        for (let i = 0; i < pedacos.length; i++) {
          const x = pedacos[i];
          const it = item(x);
          if (it) { g?.itens.push(it); continue; }
          if (ehTitulo(x)) { g = { titulo: x, itens: [] }; grupos.push(g); continue; }
          // Rótulo e valor em pedaços separados ("Calmo" + "Não").
          const prox = pedacos[i + 1];
          if (g && prox && prox.length <= 25 && !ehTitulo(prox)) { g.itens.push({ item: x.replace(/[▷►▶]\s*$/, '').trim(), valor: prox }); i++; }
        }
      }
      return grupos.filter((x) => x.itens.length);
    };
    // Riscos do funcionário (do PGR/PCMSO), que o SOC mostra no topo da ficha.
    const riscos = (textoCorpo.match(/Riscos do Funcion[áa]rio\s*(.{3,1500}?)\s*(?:O funcion[áa]rio encontra-se|Conduta dos Exames|Exame Cl[íi]nico|Funcion[áa]rio Matr[íi]cula)/i) || [])[1] || '';
    const base = {
      riscos: riscos.trim(),
      programa: prog,
      ac: v('ac'),
      existe: v('ac') !== 'inc' && !!v('rowidFicha'),
      rowidFicha: v('rowidFicha'),
      codigoSequencialFicha: v('codigoSequencialFicha'),
      rowidFuncionario: v('rowidFuncionario'),
      fichaPossuiGed: v('fichaPossuiGed') === 'true',
      dataFicha: v('dataFicha'),
      incluidoPor: auditoria?.[1] || '',
      dataCriacao: auditoria?.[2] || '',
      alteradoPor: auditoria?.[3] || '',
      dataAlteracao: auditoria?.[4] || '',
      cargo: v('nomeCargo') || rotulo('Cargo'),
      setor: v('nomeSetor') || rotulo('Setor'),
      idade: rotulo('Idade'),
      sexo: rotulo('Sexo'),
    };
    if (prog === 'cad009') {
      return {
        ...base,
        medico: rotulo('Médico(a)'),
        tipoExame: rotulo('Tipo'),
        textos: {
          anamnese: textarea('anamnese') || rotulo('Anamnese'),
          observacaoComplemento: textarea('observacaoComplemento'),
          textoLivre: textarea('textoLivre'),
        },
        parecer: (textoCorpo.match(/Parecer (Apto|Inapto|Apto com restri\S*)/i) || [])[1] || selTexto('parecerAso'),
        exameFisico: (d.body.innerText.match(/Exame Físico[\s\S]{0,1500}?Conclusões/) || [''])[0],
        questionario: lerQuestionario(),
        questionarioSoc: lerQuestionarioTexto(),
        // Sinais vitais e medidas: no modo Alterar são campos; na consulta, texto ao lado do rótulo.
        sinais: {
          temperatura: v('temperatura') || rotulo('Temperatura'),
          frequenciaRespiratoria: v('frequenciaRespiratoria') || rotulo('Frequência Respiratória (IPM)'),
          pressao: v('pressaoMaxima') ? `${v('pressaoMaxima')}x${v('pressaoMinima')}` : rotulo('Pressão Arterial (mmHg)'),
          frequenciaPulso: v('frequenciaPulso') || rotulo('Frequência de Pulso (BPM)'),
          altura: v('altura') || rotulo('Altura'),
          peso: v('peso') || rotulo('Peso (Kg)'),
          imc: v('imc') || rotulo('IMC'),
          cintura: v('perimetroCintura') || rotulo('Perímetro Cintura (cm)'),
          biotipo: selTexto('biotipo'),
        },
      };
    }
    return {
      ...base,
      medico: selTexto('inputMedico_codigoMedico') || rotulo('Médico(a)'),
      tipoExame: 'Licença Médica',
      textos: {
        periciaLicenca: textarea('periciaLicenca'),
        motivoAfastamento_EDITORHTML: textarea('motivoAfastamento_EDITORHTML'),
        restricaoRetorno: textarea('restricaoRetorno'),
      },
      licenca: {
        tipo: selTexto('codigoTipoLicencaTela'),
        motivo: selTexto('codigoMotivoLicencaTela'),
        inicio: v('dataLicencaInicio'),
        fim: v('dataLicencaFim'),
        dias: v('diasAfastamento'),
        diasValidados: v('diasValidadosPeloMedico'),
        situacao: selTexto('situacao'),
        cidValidado: [...(d.querySelector('select[name=cValidMedico]')?.options || [])].map((o) => o.text).join('; '),
        cidsAdicionais: [...(d.querySelector('select[name=cdiag]')?.options || [])].map((o) => o.text).join('; '),
        incapacitado: !!d.querySelector('input[name=trabalhadorIncapacitado]')?.checked,
      },
    };
  },

  // Assinatura Digital (797): lista documentos do GED por classificação e modo, com paginação.
  listarGed: async function ({ classificacao, modo, de, ate }) {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const form = d.getElementById('frm-browser-assinatura-digital');
    if (!form) throw new Error('Tela Assinatura Digital não carregada');
    const set = (id, val) => { const e = d.getElementById(id); if (e) e.value = val; };
    set('ipt-hdn-valor-modo-visualizacao', modo);
    set('ipt-hdn-valor-classificacao-ged', String(classificacao));
    set('ipt-hdn-valor-buscar-por', '0');
    set('ipt-periodo-selecao', `${de} - ${ate}`);
    set('ipt-data-inicio', de);
    set('ipt-data-fim', ate);
    const parse = (html) => {
      const doc = new DOMParser().parseFromString(`<table><tbody>${html}</tbody></table>`, 'text/html');
      const rows = [...doc.querySelectorAll('tr')].filter((tr) => tr.querySelector('.crecidArquivo'));
      return rows.map((tr) => ({
        codigoArquivoGed: tr.querySelector('.codigoArquivoGed')?.value || '',
        codigoGed: tr.querySelector('.codigoGed')?.textContent.trim() || '',
        nomeArquivo: tr.querySelector('.nomeDoArquivo')?.textContent.trim() || '',
        nomeGed: (tr.querySelector('.nomeDoGed .link-ged') || tr.querySelector('.nomeDoGed'))?.getAttribute('data-tooltip-padrao-acao') || tr.querySelector('.nomeDoGed')?.textContent.trim() || '',
        dataUpload: (tr.textContent.match(/\d{2}\/\d{2}\/\d{4}/) || [''])[0],
        assinaturas: Number(tr.querySelector('.quantidade-assinaturas')?.value || 0),
        assinaturasNecessarias: Number(tr.querySelector('.ipt-numero-assinaturas')?.value || 1),
      }));
    };
    const post = async (url, extra = {}) => {
      const body = new URLSearchParams(new FormData(form));
      for (const [k, val] of Object.entries(extra)) body.set(k, val);
      const r = await fetch(url, { method: 'POST', body, headers: { 'X-Requested-With': 'XMLHttpRequest' } });
      if (!r.ok) throw new Error(`Assinatura Digital respondeu ${r.status}`);
      return r.text();
    };
    let html = await post('cad422!getArquivos.action');
    const todos = parse(html);
    for (let i = 0; i < 50 && /possuiProximo/.test(html); i++) {
      html = await post('cad422!getArquivosCarregarMais.action', { indiceBuscaBrowser: String(todos.length) });
      const mais = parse(html);
      if (!mais.length) break;
      todos.push(...mais);
    }
    return todos;
  },

  telaAssinaturaPronta: function () {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    return d.readyState === 'complete' && !!d.getElementById('frm-browser-assinatura-digital');
  },

  entrarModoAlterar: function () {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    w.doAcao('alt');
    return true;
  },

  // Preenche o campo e destaca. Não salva.
  // Caixas de diálogo do SOC durante uma ação do app: alerta vira mensagem guardada (para mostrar o erro ao médico);
  // pergunta só recebe "sim" se for a esperada (salvar, gravar, criar o SOCGED, gerar o PDF). Vale até a página recarregar.
  prepararDialogos: function ({ aceitar }) {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const permitido = new RegExp(aceitar, 'i');
    w.__revisaAlertas = [];
    w.__revisaMarca = Date.now();
    w.alert = (m) => { w.__revisaAlertas.push(String(m)); };
    w.confirm = (m) => { const ok = permitido.test(String(m)); w.__revisaAlertas.push(`${ok ? '✓' : '✗'} ${m}`); return ok; };
    return true;
  },

  estadoAcao: function () {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]'))?.contentWindow;
    const d = w?.document;
    return {
      recarregou: !w?.__revisaMarca,
      pronto: d?.readyState === 'complete',
      ac: d?.forms?.[0]?.ac?.value ?? null,
      alertas: w?.__revisaAlertas || [],
      fichaPossuiGed: d?.forms?.[0]?.fichaPossuiGed?.value === 'true',
    };
  },

  salvarFicha: function () {
    (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow.doAcao('save');
    return true;
  },

  // PDF da ficha clínica (Outras Impressões → gera o PDF e vincula ao SOCGED). Classificação 8 = Ficha Clínica.
  gerarPdfFicha: function () {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    if (typeof w.validaAcessoGed !== 'function') return { ok: false, motivo: 'Não achei a opção de gerar o PDF nesta ficha.' };
    w.validaAcessoGed('gera_pdf', '8');
    return { ok: true };
  },

  // Ajustes do questionário que o médico escolheu na Fila: marca/desmarca as caixas no modo Alterar. Não salva.
  marcarQuestionario: function ({ ajustes }) {
    const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
    const limpo = (el) => (el?.innerText ?? el?.textContent ?? '').replace(/\s+/g, ' ').trim();
    const norm = (x) => String(x || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
    const tituloAntes = (tr) => {
      for (let el = tr; el && el !== d.body; el = el.parentElement?.closest('tr')) {
        for (let p = el.previousElementSibling; p; p = p.previousElementSibling) {
          if (p.querySelector('input, select, textarea')) continue;
          const t = limpo(p);
          if (t && t.length <= 80) return t;
        }
      }
      return '';
    };
    const opcaoDe = (inp) => {
      let t = inp.id ? limpo(d.querySelector(`label[for="${inp.id}"]`)) : '';
      for (let n = inp.nextSibling; !t && n; n = n.nextSibling) {
        if (n.nodeType === 1 && n.matches('input, br')) break;
        t = (n.nodeType === 3 ? n.textContent : limpo(n)).trim();
      }
      return t;
    };
    const itens = [...d.querySelectorAll('input[name^="it0"]')].filter((i) => i.type === 'checkbox' || i.type === 'radio').map((inp) => {
      const tr = inp.closest('tr');
      const td = inp.closest('td');
      const rotulo = limpo(tr?.querySelector('td.label') || (tr && tr.cells[0] !== td ? tr.cells[0] : null));
      return { inp, opcao: norm(opcaoDe(inp)), rotulo: norm(rotulo), titulo: norm(tr ? tituloAntes(tr) : '') };
    });
    const feitos = [];
    const faltaram = [];
    for (const a of ajustes || []) {
      const item = norm(a.item);
      const grupo = norm(a.grupo);
      const sim = /^sim$/i.test(a.para);
      const doGrupo = (x) => !grupo || x.titulo.includes(grupo) || grupo.includes(x.titulo);
      // Caixa com o nome do item ao lado (ex.: "Pressão Alta").
      let alvo = itens.filter((x) => x.inp.type === 'checkbox' && x.opcao === item);
      if (alvo.length > 1) alvo = alvo.filter(doGrupo);
      if (alvo.length === 1) {
        alvo[0].inp.checked = sim;
      } else {
        // Pergunta com opções Sim/Não (rádio) na mesma linha.
        const radios = itens.filter((x) => x.inp.type === 'radio' && x.rotulo === item && doGrupo(x));
        const escolhido = radios.find((x) => x.opcao === norm(a.para)) || (radios.length && radios.find((x) => (sim ? /^s/ : /^n/).test(x.opcao)));
        if (!escolhido) { faltaram.push(`${a.grupo} › ${a.item}`); continue; }
        escolhido.inp.checked = true;
        alvo = [escolhido];
      }
      const el = alvo[0].inp;
      el.dispatchEvent(new Event('click', { bubbles: true }));
      if (el.type === 'checkbox' && el.checked !== sim) el.checked = sim; // o clique de alguns SOCs inverte de novo
      el.dispatchEvent(new Event('change', { bubbles: true }));
      (el.closest('td') || el).style.outline = '3px solid #F5B82E';
      feitos.push(`${a.item} → ${a.para}`);
    }
    return { feitos, faltaram };
  },

  colarNoCampo: function ({ campo, texto, esperado }) {
    const w = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentWindow;
    const d = w.document;
    const el = d.querySelector(`textarea[name="${campo}"]`);
    if (!el) return { ok: false, motivo: `Campo ${campo} não encontrado nesta ficha` };
    // Se o texto no SOC mudou depois da revisão, não sobrescreve: a revisão está desatualizada.
    const limpo = (x) => String(x || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
    if (esperado != null && limpo(el.value) !== limpo(esperado)) {
      return { ok: false, motivo: 'O texto deste campo mudou no SOC depois da revisão. Leia o dia de novo e revise outra vez.' };
    }
    const editor = w.CKEDITOR?.instances?.[el.id] || w.CKEDITOR?.instances?.[campo];
    if (editor) {
      editor.setData(texto.split('\n').map((l) => `<p>${l.replace(/&/g, '&amp;').replace(/</g, '&lt;')}</p>`).join(''));
    } else {
      el.value = texto;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    el.scrollIntoView({ block: 'center' });
    el.style.outline = '3px solid #F5B82E';
    el.focus();
    return { ok: true };
  },
};

// ---------- orquestração (Node) ----------

const AGENDA = { acao: 'sis028.do', codigo: '236' };
const ASSINATURA = { acao: 'cad422!browser.action', codigo: '797' };

export async function estadoSoc(sessao) {
  let agendaAberta = null;
  try { agendaAberta = await rodar(sessao, pg.agendaSeAberta); } catch {}
  return { logado: await rodar(sessao, pg.logado), frame: await rodar(sessao, pg.frameInfo), usuario: await usuarioLogado(sessao), agendaAberta };
}

export async function usuarioLogado(sessao) {
  try {
    return (await rodar(sessao, pg.usuarioLogado)) || '';
  } catch {
    return '';
  }
}

export async function abrirAgenda(sessao) {
  await rodar(sessao, pg.abrirPrograma, AGENDA);
  await esperar(800);
  await esperarAte(sessao, pg.agendaPronta, {}, { descricao: 'a agenda' });
}

export async function agendaAtual(sessao) {
  await abrirAgenda(sessao);
  return rodar(sessao, pg.agendaAtual);
}

export async function lerAgenda(sessao, { data, agenda }) {
  await abrirAgenda(sessao);
  let atual = await rodar(sessao, pg.agendaAtual);
  // 1) Troca de agenda (no dia que já está aberto), como o botão "Trocar agenda" do SOC.
  if (agenda?.codigo && agenda.codigo !== atual.codigo) {
    await rodar(sessao, pg.irParaDia, { codigo: agenda.codigo, nome: agenda.nome, data: `${atual.dia}/${atual.mes}/${atual.ano}` });
    await esperar(800);
    await esperarAte(sessao, pg.agendaPronta, {}, { descricao: `a agenda ${agenda.nome}` });
    atual = await rodar(sessao, pg.agendaAtual);
    if (atual.codigo !== agenda.codigo) throw new Error(`O SOC não trocou para a agenda ${agenda.nome}.`);
  }
  // 2) Troca de dia, como o calendário da agenda.
  const [dia, mes, ano] = data.split('/');
  const mesmoDia = Number(atual.dia) === Number(dia) && Number(atual.mes) === Number(mes) && atual.ano === ano;
  if (!mesmoDia) {
    await rodar(sessao, pg.irParaDia, { data });
    await esperar(800);
    await esperarAte(sessao, pg.agendaPronta, {}, { descricao: 'a agenda do dia' });
  }
  const linhas = await rodar(sessao, pg.agendaDoDia, { data });
  if (!linhas) throw new Error(`A agenda não abriu no dia ${data}. Confira a data e o local.`);
  return { agenda: await rodar(sessao, pg.agendaAtual), linhas };
}

// Clica em Salvar (doAcao('save')) e confere: a página recarrega fora do modo Alterar, sem alerta de erro.
export async function salvarEConferir(sessao) {
  await rodar(sessao, pg.prepararDialogos, { aceitar: 'salvar|gravar|confirma|deseja continuar' });
  await rodar(sessao, pg.salvarFicha);
  const fim = Date.now() + 45000;
  let e;
  while (Date.now() < fim) {
    await esperar(700);
    try { e = await rodar(sessao, pg.estadoAcao); } catch { continue; } // no meio da recarga
    if (e.recarregou && e.pronto && e.ac && e.ac !== 'alt') return { ok: true };
    if (!e.recarregou && e.alertas.some((a) => !a.startsWith('✓'))) return { ok: false, motivo: e.alertas.join(' / ') };
  }
  return { ok: false, motivo: e?.alertas?.length ? e.alertas.join(' / ') : 'O SOC não confirmou que gravou. Confira a ficha.' };
}

// Gera o PDF da ficha e confere pelo sinal da própria ficha (fichaPossuiGed).
export async function gerarPdfEConferir(sessao, linha) {
  await rodar(sessao, pg.prepararDialogos, { aceitar: 'socged|vincular|pdf|gerar|deseja continuar' });
  const r = await rodar(sessao, pg.gerarPdfFicha);
  if (!r?.ok) return r;
  const fim = Date.now() + 60000;
  while (Date.now() < fim) {
    await esperar(1500);
    let e;
    try { e = await rodar(sessao, pg.estadoAcao); } catch { continue; }
    if (e.fichaPossuiGed) return { ok: true };
    if (!e.recarregou && e.alertas.some((a) => a.startsWith('✗') || (!a.startsWith('✓') && /erro|não foi|nao foi|inválid/i.test(a)))) return { ok: false, motivo: e.alertas.join(' / ') };
  }
  // Reabre a ficha para ler o sinal de novo (o PDF pode ter sido gerado sem recarregar a tela).
  try {
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
    if ((await rodar(sessao, pg.estadoAcao)).fichaPossuiGed) return { ok: true };
  } catch { /* segue para o aviso */ }
  return { ok: false, motivo: 'O SOC não confirmou o PDF. Gere pela ficha (Outras Impressões).' };
}

// Todas as agendas que o SOC oferece para troca (mesma lista do botão "Trocar agenda").
export async function agendasDoSoc(sessao) {
  await abrirAgenda(sessao);
  return rodar(sessao, pg.listarAgendas);
}

// O mesmo, com o véu sobre o SOC (para quando o médico pede a lista pelo painel).
export async function listarAgendas(sessao) {
  await veu(sessao, { titulo: 'Buscando a lista de agendas', detalhe: 'A mesma do botão Trocar agenda do SOC' });
  try {
    return await agendasDoSoc(sessao);
  } finally {
    await tirarVeu(sessao);
  }
}

// Abre a ficha de uma linha da agenda (a própria função do SOC troca de empresa se precisar) e lê.
export async function lerFichaDaLinha(sessao, linha) {
  await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
  await esperar(800);
  await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
  return rodar(sessao, pg.lerFicha);
}

export async function listarAssinaturas(sessao, { de, ate, classificacoes = [8, 15, 6] }) {
  await rodar(sessao, pg.abrirPrograma, ASSINATURA);
  await esperar(800);
  await esperarAte(sessao, pg.telaAssinaturaPronta, {}, { descricao: 'a Assinatura Digital' });
  const saida = [];
  for (const classificacao of classificacoes) {
    for (const modo of ['TODOS_DOCUMENTOS_PENDENTES', 'TODOS_DOCUMENTOS_ASSINADOS']) {
      const docs = await rodar(sessao, pg.listarGed, { classificacao, modo, de, ate });
      for (const doc of docs) saida.push({ ...doc, classificacao, assinado: modo.endsWith('ASSINADOS') });
    }
  }
  return saida;
}

// Só abre a ficha no Edge e traz a janela para frente (para gerar ficha, PDF ou assinar). Não muda nada.
export async function abrirFicha(sessao, { linha, data, agenda }) {
  await veu(sessao, { titulo: 'Abrindo a ficha', detalhe: `${data} · ${linha.hora}` });
  try {
    await lerAgenda(sessao, { data, agenda });
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
  } finally {
    await tirarVeu(sessao);
  }
  await trazerParaFrente(sessao);
}

// Abre a ficha em modo Alterar e cola o texto. Quem confere e salva é o médico.
export async function colar(sessao, { linha, data, agenda, campo, texto, esperado, ajustes, salvar = false, gerarPdf = false }) {
  let r;
  await veu(sessao, { titulo: 'Preparando a ficha para colar', detalhe: `${data} · ${linha.hora}` });
  try {
    await lerAgenda(sessao, { data, agenda });
    await rodar(sessao, pg.abrirFichaPorHref, { href: linha.hrefFicha });
    await esperar(800);
    await esperarAte(sessao, pg.fichaPronta, {}, { descricao: 'a ficha clínica', tempo: 45000 });
    await veu(sessao, { titulo: 'Preparando a ficha para colar', detalhe: 'Entrando em modo Alterar (nada será salvo)' });
    await rodar(sessao, pg.entrarModoAlterar);
    await esperar(800);
    await esperarAte(sessao, (a) => {
      const d = (document.getElementById('socframe') || document.getElementById('novosocFrame') || document.querySelector('iframe[name=socframe]')).contentDocument;
      return d.readyState === 'complete' && d.forms[0]?.ac?.value === 'alt' && !!d.querySelector(`textarea[name="${a.campo}"]`);
    }, { campo }, { descricao: 'o modo Alterar' });
    r = await rodar(sessao, pg.colarNoCampo, { campo, texto, esperado });
    if (r?.ok && ajustes?.length) r.questionario = await rodar(sessao, pg.marcarQuestionario, { ajustes });
    if (r?.ok && salvar) {
      await veu(sessao, { titulo: 'Salvando a ficha no SOC', detalhe: `${data} · ${linha.hora}` });
      r.salvo = await salvarEConferir(sessao);
      if (r.salvo.ok && gerarPdf) {
        await veu(sessao, { titulo: 'Gerando o PDF da ficha', detalhe: 'O SOC grava o PDF no SOCGED' });
        r.pdf = await gerarPdfEConferir(sessao, linha);
      }
    }
  } finally {
    // O véu sai antes de devolver a janela: agora quem confere e salva é o médico.
    await tirarVeu(sessao);
  }
  await trazerParaFrente(sessao);
  return r;
}
