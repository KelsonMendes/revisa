// Clique no ícone do Auditor: abre o painel numa aba (ou volta para a que já está aberta).
async function abrirPainel() {
  const url = chrome.runtime.getURL('painel.html');
  const [aberta] = await chrome.tabs.query({ url });
  if (aberta) {
    await chrome.tabs.update(aberta.id, { active: true });
    await chrome.windows.update(aberta.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
}

chrome.action.onClicked.addListener(abrirPainel);

// O site de instalação (manifest: externally_connectable) pergunta se a extensão está aqui e pede para abrir o painel.
// Só responde a esses dois pedidos; nenhum dado sai da extensão.
chrome.runtime.onMessageExternal.addListener((msg, _remetente, responder) => {
  if (msg?.tipo === 'ping') {
    responder({ ok: true, versao: chrome.runtime.getManifest().version });
  } else if (msg?.tipo === 'abrirPainel') {
    abrirPainel().then(() => responder({ ok: true }), (e) => responder({ ok: false, erro: e.message }));
    return true;
  }
  return false;
});
