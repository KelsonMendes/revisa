// Clique no ícone do Auditor: abre o painel numa aba (ou volta para a que já está aberta).
chrome.action.onClicked.addListener(async () => {
  const url = chrome.runtime.getURL('painel.html');
  const [aberta] = await chrome.tabs.query({ url });
  if (aberta) {
    await chrome.tabs.update(aberta.id, { active: true });
    await chrome.windows.update(aberta.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url });
  }
});
