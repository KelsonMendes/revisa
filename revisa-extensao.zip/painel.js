
const $ = (id) => document.getElementById(id);
try { if (localStorage.getItem('animacoes') === 'sim') document.documentElement.classList.add('animar'); } catch {}
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ic = (nome) => `<svg class="ic"><use href="#i-${nome}"/></svg>`;
const girando = `<svg class="ic gira"><use href="#i-gira"/></svg>`;
// Memória do último desenho: só anima o que é novo ou mudou (a tela redesenha a cada 2 s durante a leitura).
const vistos = new Set();
const revVistas = new Set();
const estadosAntes = new Map();
const contagensAntes = new Map();
let ultimoProgresso = null;
let atendimentos = [];
let filtroEstado = null;
let filaIdx = 0;
const editando = new Set();

// ---------------- avisos rápidos (no lugar de alert) ----------------

function avisar(texto, tipo = 'info') {
  const el = document.createElement('div');
  el.className = `aviso-rapido ${tipo}`;
  el.innerHTML = `${ic(tipo === 'ok' ? 'ok' : tipo === 'erro' ? 'alerta' : 'relogio')}<span>${esc(texto)}</span>`;
  $('avisos').append(el);
  setTimeout(() => { el.classList.add('saindo'); el.addEventListener('animationend', () => el.remove(), { once: true }); }, tipo === 'erro' ? 8000 : 5000);
}

// ---------------- diff por palavras (LCS) ----------------

function tokens(s) {
  return String(s || '').match(/\s+|[\wÀ-ÿ]+|[^\s\wÀ-ÿ]/g) || [];
}

function diff(a, b) {
  const A = tokens(a), B = tokens(b);
  const n = A.length, m = B.length;
  const L = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const ops = [];
  let i = 0, j = 0;
  const push = (t, s) => { const u = ops[ops.length - 1]; u && u.t === t ? (u.s += s) : ops.push({ t, s }); };
  while (i < n && j < m) {
    if (A[i] === B[j]) { push('=', A[i]); i++; j++; }
    else if (L[i + 1][j] >= L[i][j + 1]) { push('-', A[i]); i++; }
    else { push('+', B[j]); j++; }
  }
  while (i < n) push('-', A[i++]);
  while (j < m) push('+', B[j++]);
  // junta "- espaço +" em um bloco só e não marca mudanças só de espaço
  const blocos = [];
  for (const o of ops) {
    if (o.t === '=' && /^\s+$/.test(o.s) && blocos.length && blocos[blocos.length - 1].t !== '=') {
      const u = blocos[blocos.length - 1]; u.de += o.s; u.para += o.s; continue;
    }
    if (o.t === '=') { blocos.push({ t: '=', s: o.s }); continue; }
    let u = blocos[blocos.length - 1];
    if (!u || u.t !== 'x') { u = { t: 'x', de: '', para: '' }; blocos.push(u); }
    if (o.t === '-') u.de += o.s; else u.para += o.s;
  }
  return blocos;
}

const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

// Acha, entre as alterações explicadas pela IA, a que corresponde a um bloco do diff.
function motivoDe(bloco, alteracoes) {
  const de = norm(bloco.de), para = norm(bloco.para);
  let melhor = null, nota = 0;
  for (const a of alteracoes || []) {
    const ad = norm(a.de), ap = norm(a.para);
    let p = 0;
    if (para && ap && (ap.includes(para) || para.includes(ap))) p += Math.min(para.length, ap.length) + 5;
    if (de && ad && (ad.includes(de) || de.includes(ad))) p += Math.min(de.length, ad.length) + 5;
    if (p > nota) { nota = p; melhor = a; }
  }
  return melhor;
}

function realcarCompletar(html) {
  return html.replace(/\[COMPLETAR:?[^\]]*\]/gi, (m) => `<mark class="c" data-motivo="Falta informação: preencha antes de aprovar.">${m}</mark>`);
}

// Divide um trecho alterado nos pedaços que a IA explicou (cada "de"/"para" achado dentro dele).
function pedacos(texto, alteracoes, campo) {
  const marcas = [];
  const baixo = texto.toLowerCase();
  for (const a of alteracoes || []) {
    const alvo = String(a[campo] || '').trim().toLowerCase();
    if (alvo.length < 3) continue;
    const i = baixo.indexOf(alvo);
    if (i >= 0 && !marcas.some((m) => i < m.fim && i + alvo.length > m.ini)) marcas.push({ ini: i, fim: i + alvo.length, a });
  }
  marcas.sort((x, y) => x.ini - y.ini);
  const out = [];
  let pos = 0;
  for (const m of marcas) {
    if (m.ini > pos) out.push({ s: texto.slice(pos, m.ini), a: null });
    out.push({ s: texto.slice(m.ini, m.fim), a: m.a });
    pos = m.fim;
  }
  if (pos < texto.length) out.push({ s: texto.slice(pos), a: null });
  return out;
}

function renderDiff(original, sugerido, alteracoes, rid) {
  const blocos = diff(original, sugerido);
  const ids = new Map(); // alteração → id do par (liga o pedaço da esquerda com o da direita)
  let esq = '', dir = '', k = 0;
  const marcar = (tag, b, pedaco, padrao) => {
    if (!pedaco.s.trim()) return tag === 'ins' ? realcarCompletar(esc(pedaco.s)) : esc(pedaco.s);
    const a = pedaco.a || motivoDe(b, alteracoes);
    if (a && !ids.has(a)) ids.set(a, `${rid}-${k++}`);
    const id = a ? ids.get(a) : `${rid}-${k++}`;
    const motivo = a ? a.motivo : padrao;
    const attrs = `data-par="${id}" data-motivo="${esc(motivo)}" data-de="${esc((a ? a.de : b.de).trim())}" data-para="${esc((a ? a.para : b.para).trim())}"`;
    const corpo = tag === 'ins' ? realcarCompletar(esc(pedaco.s)) : esc(pedaco.s);
    return tag === 'ins' ? `<ins class="i" ${attrs}>${corpo}</ins>` : `<del class="d" ${attrs}>${corpo}</del>`;
  };
  for (const b of blocos) {
    if (b.t === '=') { esq += esc(b.s); dir += realcarCompletar(esc(b.s)); continue; }
    if (!b.de.trim() && !b.para.trim()) { esq += esc(b.de); dir += esc(b.para); continue; }
    for (const p of pedacos(b.de, alteracoes, 'de')) esq += marcar('del', b, p, 'Trecho retirado pela revisão.');
    for (const p of pedacos(b.para, alteracoes, 'para')) dir += marcar('ins', b, p, 'Ajuste de redação.');
  }
  return { esq, dir, mudancas: new Set([...(esq + dir).matchAll(/data-par="([^"]+)"/g)].map((m) => m[1])).size };
}

// ---------------- dica ao passar o mouse ----------------

document.addEventListener('mouseover', (ev) => {
  const simples = ev.target.closest('[data-dica]');
  if (simples) { const d = $('dica'); d.textContent = simples.dataset.dica; d.style.display = 'block'; return; }
  const el = ev.target.closest('[data-motivo]');
  document.querySelectorAll('.par').forEach((x) => x.classList.remove('par'));
  const dica = $('dica');
  if (!el) { dica.style.display = 'none'; return; }
  if (el.dataset.par) document.querySelectorAll(`[data-par="${el.dataset.par}"]`).forEach((x) => x.classList.add('par'));
  const de = el.dataset.de, para = el.dataset.para;
  dica.innerHTML = `<span class="rot">Por que mudou</span>${esc(el.dataset.motivo)}` +
    (de || para ? `<div class="antes">${de ? `Antes: “${esc(de.slice(0, 140))}”` : 'Acréscimo'}${para && de ? `<br>Depois: “${esc(para.slice(0, 140))}”` : ''}</div>` : '');
  dica.style.display = 'block';
});
document.addEventListener('mousemove', (ev) => {
  const d = $('dica');
  if (d.style.display !== 'block') return;
  const x = Math.min(ev.clientX + 14, innerWidth - d.offsetWidth - 8);
  const y = ev.clientY + 18 + d.offsetHeight > innerHeight ? ev.clientY - d.offsetHeight - 10 : ev.clientY + 18;
  d.style.left = x + 'px'; d.style.top = y + 'px';
});

// ---------------- dados ----------------

function dataBR() {
  const v = $('data').value;
  if (!v) return null;
  const [a, m, d] = v.split('-');
  return `${d}/${m}/${a}`;
}

async function api(metodo, rota, corpo) {
  const r = await fetch(rota, { method: metodo, headers: { 'Content-Type': 'application/json' }, body: corpo ? JSON.stringify(corpo) : undefined });
  const j = await r.json();
  if (!r.ok) throw new Error(j.erro || 'Erro');
  return j;
}

function mostrarStatus(tom, texto) {
  $('status').className = `estado-soc ${tom}`;
  $('status').querySelector('span').textContent = texto;
  $('status').title = texto;
}

async function atualizarEstado() {
  try {
    const e = await api('GET', '/api/estado');
    if (!e.edgeAberto) mostrarStatus('erro', 'Edge do auditor fechado: abra pelo atalho');
    else if (e.soc?.erro) mostrarStatus('erro', e.soc.erro);
    else if (e.soc?.logado) mostrarStatus('ok', `SOC conectado · ${e.medico}`);
    else mostrarStatus('aviso', 'Faça login no SOC na janela do Edge');
    // Seletor: as duas buscas, suas agendas (onde já houve atendimento seu) e as demais que o SOC oferece.
    const sel = $('agenda');
    const atual = sel.value || localStorage.getItem('agenda') || '@minhas';
    const opc = (a) => `<option value="${esc(a.codigo)}">${esc(a.nome)}</option>`;
    const minhas = e.agendas.filter((a) => a.minha), outras = e.agendas.filter((a) => !a.minha);
    const html = '<option value="@minhas">Procurar nas minhas agendas</option><option value="@todas">Procurar em todas as agendas do SOC</option>'
      + (minhas.length ? `<optgroup label="Minhas agendas">${minhas.map(opc).join('')}</optgroup>` : '')
      + (outras.length ? `<optgroup label="${minhas.length ? 'Outras agendas do SOC' : 'Agendas do SOC'}">${outras.map(opc).join('')}</optgroup>` : '');
    if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; }
    if ([...sel.options].some((o) => o.value === atual)) sel.value = atual;
    const p = e.progresso;
    $('prog').innerHTML = p.rodando ? esc(p.etapa)
      : p.erro ? `<span class="erro-msg">Erro na leitura: ${esc(p.erro)}</span>` : p.aviso ? esc(p.aviso) : p.terminou ? `Última leitura às ${new Date(p.terminou).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : '';
    ultimoProgresso = p;
    $('barraProg').hidden = !p.rodando;
    $('barraProg').classList.toggle('indef', p.rodando && !p.total);
    $('barraProgI').style.width = p.total ? `${Math.round((100 * p.feito) / p.total)}%` : '';
    $('varrer').disabled = p.rodando;
    $('varrer').innerHTML = p.rodando ? `${girando}Lendo o SOC…` : `${ic('ler')}Ler o dia no SOC`;
    return p;
  } catch {
    mostrarStatus('erro', 'Painel sem conexão: abra pelo atalho');
  }
}

async function carregar() {
  const d = dataBR();
  if (!d) return;
  atendimentos = await api('GET', `/api/atendimentos?data=${encodeURIComponent(d)}`);
  desenhar();
}

function pendentesDaFila() {
  return atendimentos.filter((a) => a.doMedico).flatMap((a) => a.revisoes.filter((r) => r.status === 'sugerida' || r.status === 'aprovada').map((r) => ({ a, r })));
}

// ---------------- tabela do dia ----------------

function chip(estado, texto, mudou = false) {
  return estado ? `<span class="chip ${esc(estado)} ${mudou ? 'mudou' : ''}">${esc(texto)}</span>` : '<span class="chip nao_encontrado">Sem dado</span>';
}

// Filtros por tipo de atendimento, documento, local e empresa, mais a busca pelo nome (abas Dia e Pendências).
// As opções saem dos próprios atendimentos da lista, cada uma com a quantidade.
const CAMPOS_FILTRO = [
  ['tipo', 'Tipo', 'Todos os tipos', (a) => a.tipo || 'Sem tipo'],
  ['doc', 'Documento', 'Fichas e licenças', (a) => a.documentoPrincipal],
  ['local', 'Local', 'Todos os locais', (a) => a.local || 'Sem local'],
  ['empresa', 'Empresa', 'Todas as empresas', (a) => a.empresa || 'Sem empresa'],
];
const filtrosPor = { dia: {}, pend: {} };
try { Object.assign(filtrosPor.pend, JSON.parse(localStorage.getItem('filtrosPend') || '{}')); } catch {}

function aplicarFiltros(qual, lista, menos) {
  const f = filtrosPor[qual];
  const busca = (f.busca || '').trim().toUpperCase();
  return lista.filter((a) => CAMPOS_FILTRO.every(([k, , , v]) => k === menos || !f[k] || v(a) === f[k])
    && (!busca || `${a.paciente} ${a.empresa}`.toUpperCase().includes(busca)));
}

function desenharFiltros(qual, lista) {
  const caixa = $(qual === 'dia' ? 'filtrosDia' : 'filtrosPend');
  const f = filtrosPor[qual];
  if (!caixa.dataset.montado) {
    caixa.dataset.montado = '1';
    caixa.innerHTML = CAMPOS_FILTRO.map(([k, rotulo]) => `<label class="campo" data-campo="${k}">${rotulo} <select data-filtro-campo="${k}"></select></label>`).join('')
      + `<label class="campo busca">Paciente ou empresa <input type="search" data-filtro-campo="busca" placeholder="Buscar pelo nome" value="${esc(f.busca || '')}"></label>`
      + '<button class="bt fantasma peq" data-limpar-filtros hidden>Limpar filtros</button>';
    const mudou = (ev) => {
      const el = ev.target.closest('[data-filtro-campo]');
      if (!el) return;
      f[el.dataset.filtroCampo] = el.value;
      if (qual === 'pend') { try { localStorage.setItem('filtrosPend', JSON.stringify(f)); } catch {} desenharPendencias(); } else desenhar();
    };
    caixa.addEventListener('change', mudou);
    caixa.addEventListener('input', (ev) => ev.target.type === 'search' && mudou(ev));
    caixa.querySelector('[data-limpar-filtros]').onclick = () => {
      for (const k of Object.keys(f)) f[k] = '';
      caixa.querySelector('input').value = '';
      if (qual === 'pend') { try { localStorage.removeItem('filtrosPend'); } catch {} desenharPendencias(); } else desenhar();
    };
  }
  for (const [k, , todos, v] of CAMPOS_FILTRO) {
    // Cada lista conta os atendimentos que sobram com os outros filtros aplicados.
    const contas = new Map();
    for (const a of aplicarFiltros(qual, lista, k)) contas.set(v(a), (contas.get(v(a)) || 0) + 1);
    if (f[k] && !contas.has(f[k])) contas.set(f[k], 0);
    const sel = caixa.querySelector(`select[data-filtro-campo="${k}"]`);
    const total = [...contas.values()].reduce((x, y) => x + y, 0);
    const html = `<option value="">${todos} (${total})</option>` + [...contas.entries()].sort((x, y) => y[1] - x[1] || x[0].localeCompare(y[0]))
      .map(([valor, n]) => `<option value="${esc(valor)}">${esc(valor)} (${n})</option>`).join('');
    if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; }
    sel.value = f[k] || '';
    sel.classList.toggle('usado', !!f[k]);
    // Uma opção só (ex.: um local no dia) não ajuda a filtrar: some, a não ser que esteja em uso.
    sel.closest('.campo').hidden = contas.size < 2 && !f[k];
  }
  caixa.querySelector('input').classList.toggle('usado', !!(f.busca || '').trim());
  caixa.querySelector('[data-limpar-filtros]').hidden = !Object.values(f).some((x) => x && String(x).trim());
}

const FILTROS = [
  ['Todos', () => true, ''],
  ['Não geradas', (a) => a.estadoPrincipal === 'nao_gerada', 'perigo'],
  ['Sem PDF ou assinatura', (a) => ['sem_pdf', 'pdf_pendente'].includes(a.estadoPrincipal), 'atencao'],
  ['Assinadas', (a) => a.estadoPrincipal === 'assinada', 'ok'],
  ['ASO pendente', (a) => a.estadoAso && a.estadoAso !== 'assinada', 'atencao'],
];

// Pequenas cenas desenhadas para os estados vazios (mesmo traço dos ícones).
const ILUSTRA = {
  calendario: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <rect class="papel" x="28" y="18" width="62" height="64" rx="8"/><rect class="acao" x="28" y="18" width="62" height="14" rx="7"/><rect class="acao" x="28" y="25" width="62" height="7"/>
    <path class="linha" d="M40 44h8M54 44h8M68 44h8M40 56h8M54 56h8M68 56h8M40 68h8"/>
    <g class="flutua"><rect class="papel" x="74" y="40" width="40" height="46" rx="6"/><path class="linha" d="M82 52h24M82 60h18M82 68h22"/><path class="acao-l" d="M84 78l4 4 8-8"/></g></svg>`,
  escudo: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <rect class="papel" x="34" y="16" width="54" height="68" rx="6"/><path class="linha" d="M44 30h34M44 40h28M44 50h32"/>
    <circle class="carimbo" cx="72" cy="66" r="12"/><circle class="carimbo" cx="72" cy="66" r="8"/>
    <g class="flutua"><circle class="ok-f" cx="98" cy="34" r="16"/><path class="ok-l" d="M90 34l6 6 11-12"/></g></svg>`,
  caixa: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <path class="papel" d="M30 52l12-22h48l12 22v22a6 6 0 0 1-6 6H36a6 6 0 0 1-6-6z"/><path class="linha" d="M30 52h22l4 8h20l4-8h22"/>
    <g class="flutua"><circle class="ok-f" cx="66" cy="34" r="12"/><path class="ok-l" d="M60 34l4 4 8-8"/></g></svg>`,
};

function vazio(icone, titulo, texto, colunas) {
  return `<tr><td colspan="${colunas}"><div class="vazio">${ILUSTRA[icone] || ic(icone)}<b>${titulo}</b>${texto}</div></td></tr>`;
}

function statusRevisao(c, r) {
  if (r.status === 'colada') return `<span class="st-rev ok">${ic('ok')}${esc(c.rotulo)}: colado no SOC</span>`;
  if (r.status === 'aprovada') return `<span class="st-rev espera">${ic('colar')}${esc(c.rotulo)}: aprovado, falta colar</span>`;
  return `<span class="st-rev espera">${ic('relogio')}${esc(c.rotulo)}: nota ${r.resultado?.nota_completude ?? '?'}, aguardando você</span>`;
}

function desenhar() {
  const soMeus = $('soMeus').checked;
  const doMedico = atendimentos.filter((a) => !soMeus || a.doMedico);
  desenharFiltros('dia', doMedico);
  const base = aplicarFiltros('dia', doMedico);
  $('resumo').innerHTML = FILTROS.map(([t, f, tom], i) => {
    const n = base.filter(f).length;
    const pulo = contagensAntes.has(i) && contagensAntes.get(i) !== n ? 'pulo' : '';
    contagensAntes.set(i, n);
    return `<button data-filtro="${i}" data-tom="${tom}" class="${(filtroEstado ?? 0) === i ? 'ativo' : ''}">${t} <b class="${pulo}">${n}</b></button>`;
  }).join('');
  const lista = filtroEstado ? base.filter(FILTROS[filtroEstado][1]) : base;
  contador('contFila', pendentesDaFila().length);

  if (!lista.length && !atendimentos.length && ultimoProgresso?.rodando) {
    $('linhas').innerHTML = Array.from({ length: 5 }, () => `<tr class="esqueleto">${'<td><span class="barra-cinza"></span><span class="barra-cinza"></span></td>'.repeat(6)}</tr>`).join('');
    return;
  }
  if (!lista.length) {
    $('linhas').innerHTML = atendimentos.length
      ? vazio('caixa', 'Nada neste filtro', 'Escolha "Todos", limpe os filtros ou desligue "Só meus atendimentos".', 6)
      : vazio('calendario', 'Nenhum dia lido ainda', 'Escolha o dia e o local acima e clique em "Ler o dia no SOC".', 6);
    return;
  }
  let novos = 0;
  $('linhas').innerHTML = lista.map((a) => {
    const revs = a.revisoes.filter((r) => r.status !== 'descartada');
    const novo = !vistos.has(a.id);
    const ordem = novo ? Math.min(novos++, 12) : 0;
    const antes = estadosAntes.get(a.id);
    const mudou = antes && (antes.p !== a.estadoPrincipal || antes.a !== a.estadoAso);
    vistos.add(a.id);
    estadosAntes.set(a.id, { p: a.estadoPrincipal, a: a.estadoAso });
    const quem = a.doMedico === 2 ? `<div class="sub alerta">${ic('alerta')}Profissional não definido na agenda</div>`
      : a.doMedico ? '' : `<div class="sub">Profissional: ${esc(a.profissional || a.medico || '—')}</div>`;
    const acoes = [
      a.podeAbrir && a.doMedico ? `<button class="bt fantasma peq" data-abrir="${a.id}" title="Abre a ficha no Edge, sem alterar nada">${ic('abrir')}Abrir no SOC</button>` : '',
      ...a.campos.map((c) => {
        const r = revs.find((x) => x.campo === c.campo);
        if (r) return statusRevisao(c, r);
        return a.doMedico && c.texto && cfg.modoIA !== 'manual' ? `<button class="bt peq" data-rev="${a.id}" data-campo="${c.campo}">${ic('revisar')}Revisar ${esc(c.rotulo.toLowerCase())}</button>` : '';
      }),
    ].filter(Boolean).join('');
    return `
    <tr class="linha ${a.doMedico ? '' : 'outro'} ${novo ? 'novo' : ''}" style="--i:${ordem}">
      <td class="hora">${esc(a.hora)}</td>
      <td><div class="pac">${esc(a.paciente)}</div><div class="sub">${esc(a.empresa)}</div>${quem}</td>
      <td>${esc(a.tipo)}</td>
      <td><div class="doc">${a.documentoPrincipal}</div>${chip(a.estadoPrincipal, a.estadoPrincipalTexto, mudou)}${a.alerta ? `<div class="sub alerta">${ic('relogio')}Há ${a.diasDesde} dias sem assinatura</div>` : ''}${a.erro ? `<div class="sub erro-msg">${esc(a.erro)}</div>` : ''}</td>
      <td>${a.estadoAso ? `<div class="doc">ASO</div>${chip(a.estadoAso, a.estadoAsoTexto)}` : ''}</td>
      <td class="acoes-col"><div class="pilha">${acoes}</div></td>
    </tr>
    ${revs.length ? `<tr><td colspan="6" class="painel-row">${revs.map((r) => cartao(a, r)).join('')}</td></tr>` : ''}`;
  }).join('');
}

// ---------------- cartão de revisão ----------------

function tomNota(n) { return n >= 8 ? 'ok' : n >= 5 ? 'atencao' : 'perigo'; }
const ROTULO_GRAV = { alta: 'Alta', media: 'Média', baixa: 'Baixa' };

function cartao(a, r, naFila = false) {
  const res = r.resultado || {};
  const rotulo = a.campos.find((c) => c.campo === r.campo)?.rotulo || r.campo;
  const ordem = { alta: 0, media: 1, baixa: 2 };
  const lista = [...(res.achados || [])].sort((x, y) => ordem[x.gravidade] - ordem[y.gravidade]);
  const achados = lista.map((x) => `<div class="achado" data-trecho="${esc(x.trecho)}" data-rid="${r.id}">
      <span class="grav ${x.gravidade}">${ROTULO_GRAV[x.gravidade] || x.gravidade}</span>
      <div><span class="tit">${esc(x.item)}</span>${x.trecho ? ` <span class="trecho">“${esc(x.trecho)}”</span>` : ''}<p>${esc(x.sugestao)}</p></div></div>`).join('');
  const altas = lista.filter((x) => x.gravidade === 'alta').length;
  const sugerida = r.status === 'sugerida';
  const textoNovo = sugerida ? r.texto_sugerido : r.texto_aprovado;
  const emEdicao = sugerida && editando.has(r.id);
  const d = renderDiff(r.texto_original, textoNovo, res.alteracoes, r.id);
  const nCompletar = (textoNovo.match(/\[COMPLETAR/gi) || []).length;
  const nota = res.nota_completude ?? 0;
  const estado = { sugerida: 'Aguardando você', aprovada: 'Aprovado, falta colar', colada: 'Colado no SOC' }[r.status] || r.status;
  const revNova = !revVistas.has(r.id);
  revVistas.add(r.id);
  return `<div class="rev ${revNova ? 'novo' : ''}" id="rev${r.id}">
    <div class="rev-cab">
      <h4>${esc(a.hora)} · ${esc(a.paciente)} <span class="campo-nome">· ${esc(rotulo)}</span></h4>
      <span class="nota ${tomNota(nota)}" title="Completude do registro, de 0 a 10">${res.nota_completude ?? '?'}<small>/10</small></span>
      <span class="estado">${estado}</span>
    </div>
    <p class="resumo-ia">${esc(res.resumo)}</p>
    <details class="achados" ${naFila || altas ? 'open' : ''}>
      <summary>${ic('seta')}Achados do checklist <span class="cnt">${lista.length}${altas ? ` · ${altas} de gravidade alta` : ''}</span></summary>
      <div class="lista-achados">${achados}</div>
    </details>
    <div class="legenda">
      <span><del class="d">riscado</del> sai</span><span><ins class="i">sublinhado</ins> entra</span>
      <span>Passe o mouse numa mudança para ver o motivo</span>
      <span class="num">${d.mudancas} mudança(s)</span>
      ${nCompletar ? `<span class="falta">${ic('alerta')}${nCompletar} trecho(s) para completar antes de aprovar</span>` : ''}
    </div>
    <div class="comparar">
      <div><div class="lado-tit">Texto atual no SOC</div><div class="texto" id="orig${r.id}">${d.esq}</div></div>
      <div><div class="lado-tit">${sugerida ? 'Sugestão' : r.status === 'colada' ? 'Texto colado' : 'Texto aprovado'}<span class="esp"></span>
        ${sugerida ? `<button class="bt fantasma peq" data-editar="${r.id}">${ic(emEdicao ? 'revisar' : 'editar')}${emEdicao ? 'Ver alterações' : 'Editar texto'}</button>` : ''}</div>
        ${emEdicao ? `<textarea class="texto" id="t${r.id}">${esc(r.texto_sugerido)}</textarea>` : `<div class="texto">${d.dir}</div>`}</div>
    </div>
    <div class="rodape-rev">
      ${sugerida ? `<button class="bt ok" data-aprovar="${r.id}">${ic('ok')}Aprovar texto</button><button class="bt" data-descartar="${r.id}">Descartar</button>` : ''}
      ${r.status === 'aprovada' ? `<button class="bt prim" data-colar="${r.id}">${ic('colar')}Colar no SOC</button><span class="info">Abre a ficha em modo Alterar e cola. Você confere e salva.</span>` : ''}
      ${r.status === 'colada' ? `<span class="info ok">${ic('ok')}Colado. Confira na janela do Edge e clique em Salvar no SOC.</span>` : ''}
      ${naFila ? `<span class="esp"></span><span class="atalhos"><span><kbd>A</kbd> aprovar</span><span><kbd>E</kbd> editar</span><span><kbd>D</kbd> descartar</span><span><kbd>C</kbd> colar</span><span><kbd>←</kbd><kbd>→</kbd> navegar</span><span><kbd>Esc</kbd> fechar</span></span>` : ''}
    </div>
  </div>`;
}

// guarda o texto em edição antes de redesenhar
function salvarEdicoes() {
  for (const id of editando) {
    const t = $('t' + id);
    if (!t) continue;
    for (const a of atendimentos) for (const r of a.revisoes) if (r.id === id) r.texto_sugerido = t.value;
  }
}

// realça no texto original o trecho citado pelo achado
document.addEventListener('mouseover', (ev) => {
  const ach = ev.target.closest('.achado');
  document.querySelectorAll('mark.t').forEach((m) => m.replaceWith(...m.childNodes));
  if (!ach || !ach.dataset.trecho) return;
  const painel = $('orig' + ach.dataset.rid);
  if (!painel) return;
  const alvo = ach.dataset.trecho.trim();
  const w = document.createTreeWalker(painel, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const i = n.nodeValue.toLowerCase().indexOf(alvo.toLowerCase().slice(0, 60));
    if (i < 0) continue;
    const r = document.createRange();
    r.setStart(n, i); r.setEnd(n, Math.min(n.nodeValue.length, i + alvo.length));
    const m = document.createElement('mark'); m.className = 't';
    r.surroundContents(m);
    m.scrollIntoView({ block: 'nearest' });
    break;
  }
});

// ---------------- fila ----------------

function desenharFila() {
  const itens = pendentesDaFila();
  if (!itens.length) {
    $('filaCaixa').innerHTML = `<div class="folha-cab"><h3>Fila de aprovação</h3><span class="esp" style="flex:1"></span><button class="bt icone fantasma" data-fechar aria-label="Fechar">${ic('x')}</button></div>
      <div class="vazio">${ILUSTRA.caixa}<b>Fila vazia</b>Nenhuma revisão esperando você neste dia.</div>`;
    return;
  }
  filaIdx = Math.max(0, Math.min(filaIdx, itens.length - 1));
  const { a, r } = itens[filaIdx];
  $('filaCaixa').innerHTML = `<div class="folha-cab">
      <h3>Fila de aprovação</h3>
      <span class="posicao">${filaIdx + 1} de ${itens.length}</span>
      <span class="trilho"><i style="width:${Math.round((100 * (filaIdx + 1)) / itens.length)}%"></i></span>
      <button class="bt peq" data-ant ${filaIdx ? '' : 'disabled'}>${ic('esq')}Anterior</button>
      <button class="bt peq" data-prox ${filaIdx < itens.length - 1 ? '' : 'disabled'}>Próxima${ic('dir')}</button>
      <button class="bt icone fantasma" data-fechar aria-label="Fechar">${ic('x')}</button>
    </div>
    <div class="folha-corpo">${cartao(a, r, true)}</div>`;
}

function abrirFila() { filaIdx = 0; $('fila').style.display = 'block'; document.body.style.overflow = 'hidden'; desenharFila(); }
function fecharFila() { $('fila').style.display = 'none'; document.body.style.overflow = ''; desenhar(); }
const filaAberta = () => $('fila').style.display === 'block';
const redesenhar = () => (filaAberta() ? desenharFila() : desenhar());

$('fila').addEventListener('click', (ev) => { if (ev.target === $('fila')) { salvarEdicoes(); fecharFila(); } });

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape' && $('config').classList.contains('aberto')) { fecharConfig(); return; }
  if (!filaAberta() || ev.target.matches('textarea, input, select')) return;
  const clicar = (sel) => document.querySelector(`#filaCaixa ${sel}`)?.click();
  const k = ev.key.toLowerCase();
  if (['escape', 'arrowright', 'arrowleft', 'a', 'd', 'c', 'e'].includes(k)) ev.preventDefault(); // a tecla não pode cair no texto que abre em seguida
  if (k === 'escape') fecharFila();
  else if (k === 'arrowright') clicar('[data-prox]');
  else if (k === 'arrowleft') clicar('[data-ant]');
  else if (k === 'a') clicar('[data-aprovar]');
  else if (k === 'd') clicar('[data-descartar]');
  else if (k === 'c') clicar('[data-colar]');
  else if (k === 'e') clicar('[data-editar]');
});

// ---------------- ações ----------------

document.addEventListener('click', async (ev) => {
  const b = ev.target.closest('button');
  if (!b || b.dataset.abrir) return;
  try {
    if (b.dataset.filtro !== undefined) {
      const i = Number(b.dataset.filtro);
      filtroEstado = i === 0 || filtroEstado === i ? null : i;
      desenhar();
    } else if (b.dataset.editar) {
      const id = Number(b.dataset.editar);
      salvarEdicoes();
      editando.has(id) ? editando.delete(id) : editando.add(id);
      redesenhar();
      if (editando.has(id)) $('t' + id)?.focus();
    } else if (b.dataset.rev) {
      b.disabled = true; b.innerHTML = `${girando}Revisando, cerca de 30 s`;
      await api('POST', '/api/revisar', { atendimentoId: Number(b.dataset.rev), campo: b.dataset.campo });
      await carregar();
    } else if (b.dataset.aprovar) {
      salvarEdicoes();
      const id = Number(b.dataset.aprovar);
      const r = atendimentos.flatMap((a) => a.revisoes).find((x) => x.id === id);
      await api('POST', '/api/aprovar', { revisaoId: id, texto: r.texto_sugerido });
      editando.delete(id);
      avisar('Texto aprovado. Agora é só colar no SOC.', 'ok');
      await carregar(); redesenhar();
    } else if (b.dataset.descartar) {
      await api('POST', '/api/descartar', { revisaoId: Number(b.dataset.descartar) });
      await carregar(); redesenhar();
    } else if (b.dataset.colar) {
      if (!confirm('Abrir esta ficha no SOC em modo Alterar e colar o texto aprovado? Nada será salvo automaticamente.')) return;
      b.disabled = true; b.innerHTML = `${girando}Colando…`;
      const r = await api('POST', '/api/colar', { revisaoId: Number(b.dataset.colar) });
      avisar(r.aviso, 'ok');
      await carregar(); redesenhar();
    } else if (b.dataset.prox !== undefined) { salvarEdicoes(); filaIdx++; desenharFila(); }
    else if (b.dataset.ant !== undefined) { salvarEdicoes(); filaIdx--; desenharFila(); }
    else if (b.dataset.fechar !== undefined) { salvarEdicoes(); fecharFila(); }
  } catch (e) {
    avisar(e.message, 'erro');
    await carregar(); redesenhar();
  }
});

$('abrirFila').onclick = abrirFila;

function contador(id, n) {
  const e = $(id);
  const mudou = e.textContent !== String(n);
  e.textContent = n;
  e.classList.toggle('zero', !n);
  if (mudou && n) { e.classList.remove('pulo'); void e.offsetWidth; e.classList.add('pulo'); }
}

function mostrarAba(aba) {
  document.querySelectorAll('nav.abas [data-aba]').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === aba));
  $('vInicio').hidden = aba !== 'inicio';
  $('vDia').hidden = aba !== 'dia';
  $('vPend').hidden = aba !== 'pend';
  localStorage.setItem('aba', aba);
  if (aba === 'pend') carregarPendencias();
  if (aba === 'inicio') carregarPainel();
}

// ---------------- visão geral ----------------

function contarAte(el, alvo, casas = 0) {
  const ini = performance.now(), dur = 700;
  const passo = (t) => {
    const k = Math.min(1, (t - ini) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = (alvo * e).toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
    if (k < 1) requestAnimationFrame(passo);
  };
  if (matchMedia('(prefers-reduced-motion: reduce)').matches && !document.documentElement.classList.contains('animar')) el.textContent = alvo.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
  else requestAnimationFrame(passo);
}

function irParaDia(dataBRx) {
  const [d, m, a] = dataBRx.split('/');
  $('data').value = `${a}-${m}-${d}`;
  $('data').onchange();
  mostrarAba('dia');
}

async function carregarPainel() {
  let p;
  try { p = await api('GET', '/api/painel'); } catch (e) { $('grade').innerHTML = `<div class="cx" style="grid-column:span 12">${vazioTxt('alerta', 'Não consegui montar a visão geral', esc(e.message))}</div>`; return; }
  const h = new Date().getHours();
  const nome = (p.medico || '').split(' ')[0];
  $('olaTitulo').textContent = `${h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'}, ${nome}`;
  const hojeLongo = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  $('olaSub').textContent = `${hojeLongo.charAt(0).toUpperCase() + hojeLongo.slice(1)}${p.ultimaLeitura ? ` · último dia lido: ${p.ultimaLeitura.data}${p.ultimaLeitura.local ? ` em ${p.ultimaLeitura.local}` : ''}` : ' · nenhum dia lido ainda'}`;

  const at = p.atraso, totAt = at.recentes + at.semana + at.antigas;
  const faixaAtraso = totAt ? [
    ['recentes', at.recentes, 'var(--g-neutro)', 'Até 6 dias'],
    ['semana', at.semana, 'var(--g-pend)', '7 a 14 dias'],
    ['antigas', at.antigas, 'var(--g-nao)', '15 dias ou mais'],
  ] : [];

  const maxDia = Math.max(1, ...p.dias.map((d) => d.assinada + d.pendente + d.nao_gerada));
  const colunas = p.dias.map((d, i) => {
    const tot = d.assinada + d.pendente + d.nao_gerada;
    if (!d.lido) return `<div class="dia-col vazio-dia" data-dia="${d.data}" data-dica="${d.data}: dia não lido. Clique para ler." style="--i:${i}"></div>`;
    const seg = (n, cor) => (n ? `<div class="seg" style="height:${(100 * n) / maxDia}%;background:${cor};--i:${i}"></div>` : '');
    return `<div class="dia-col" data-dia="${d.data}" data-dica="${d.data}: ${tot} atendimento(s) seus · ${d.assinada} assinada(s) · ${d.pendente} sem PDF ou assinatura · ${d.nao_gerada} não gerada(s). Clique para abrir o dia." style="--i:${i}">
      ${seg(d.nao_gerada, 'var(--g-nao)')}${seg(d.pendente, 'var(--g-pend)')}${seg(d.assinada, 'var(--g-ok)')}</div>`;
  }).join('');
  const eixo = p.dias.map((d) => `<span class="${d.data === p.hoje ? 'hoje' : ''}"><span class="sem">${d.semana}<br></span>${d.data.slice(0, 2)}</span>`).join('');

  const q = p.qualidade;
  const maxHist = Math.max(1, ...q.distribuicao);
  const maxAch = Math.max(1, ...q.achados.map((a) => a.total));

  $('grade').innerHTML = `
    <article class="cx" style="--i:0">
      <h3>Sem assinatura</h3>
      <div class="grande"><span id="nAbertos">0</span> <small>registros nos últimos 60 dias</small></div>
      ${totAt ? `<div class="faixa">${faixaAtraso.filter((f) => f[1]).map(([, n, cor, rot]) => `<i style="width:${(100 * n) / totAt}%;background:${cor}" data-dica="${rot}: ${n}"></i>`).join('')}</div>
      <div class="legenda-g">${faixaAtraso.map(([, n, cor, rot]) => `<span style="--cor:${cor}">${rot} <b>${n}</b></span>`).join('')}</div>`
      : '<p class="vazio-cx">Nada pendente nos dias já lidos.</p>'}
      <div class="rodape-cx"><button class="bt fantasma peq" data-ir="pend">Ver pendências${ic('dir')}</button></div>
    </article>
    <article class="cx" style="--i:1">
      <h3>Esperando você</h3>
      <div class="fila-linhas">
        <div><b id="nAguardando">0</b><span class="leg">revisões para aprovar</span></div>
        <div><b id="nAprovadas">0</b><span class="leg">aprovadas, falta colar no SOC</span></div>
        <div><b id="nColadas">0</b><span class="leg">coladas nos últimos 30 dias</span></div>
      </div>
      <div class="rodape-cx"><button class="bt ${p.fila.aguardando + p.fila.aprovadas ? 'prim' : ''} peq" id="painelFila">Abrir fila${ic('dir')}</button></div>
    </article>
    <article class="cx" style="--i:2">
      <h3>Qualidade dos registros revisados</h3>
      ${q.revisoes ? `<div class="grande"><span id="nNota">0</span> <small>de 10, nota média · ${q.revisoes} revisões em 30 dias</small></div>
      <div class="histo">${q.distribuicao.map((n, i) => `<i style="height:${(100 * n) / maxHist}%;--i:${i}" data-dica="Nota ${i * 2} a ${i * 2 + 1}${i === 4 ? '0' : ''}: ${n} registro(s)"></i>`).join('')}</div>
      <div class="histo-eixo"><span>0–1</span><span>2–3</span><span>4–5</span><span>6–7</span><span>8–10</span></div>`
      : '<p class="vazio-cx">Ainda não há revisões. Na aba Dia, use "Revisar todos com IA".</p>'}
    </article>
    <article class="cx larga" style="--i:3">
      <h3>Seus atendimentos nos últimos 14 dias</h3>
      <div class="dias">${colunas}</div>
      <div class="dias-eixo">${eixo}</div>
      <div class="legenda-g" style="margin-top:12px">
        <span style="--cor:var(--g-ok)">Assinada</span><span style="--cor:var(--g-pend)">Sem PDF ou assinatura</span><span style="--cor:var(--g-nao)">Não gerada</span>
        <span style="--cor:transparent;">┄ tracejado: dia não lido (clique para ler)</span>
      </div>
    </article>
    <article class="cx" style="--i:4">
      <h3>Achados mais frequentes (30 dias)</h3>
      ${q.achados.length ? `<div class="barras-h">${q.achados.map((a, i) => `<div class="barra-h"><div class="rot"><span title="${esc(a.item)}">${esc(a.item)}</span><b>${a.total}</b></div>
        <div class="trilho-h" data-dica="${esc(a.item)}: ${a.total} vez(es), ${a.altas} de gravidade alta">
          ${a.altas ? `<i style="width:${(100 * a.altas) / maxAch}%;background:var(--g-nao);--i:${i}"></i>` : ''}<i style="width:${(100 * (a.total - a.altas)) / maxAch}%;background:var(--acao);--i:${i}"></i></div></div>`).join('')}</div>
      <div class="legenda-g" style="margin-top:12px"><span style="--cor:var(--g-nao)">Gravidade alta</span><span style="--cor:var(--acao)">Média ou baixa</span></div>`
      : '<p class="vazio-cx">Aparece depois das primeiras revisões.</p>'}
    </article>`;

  contarAte($('nAbertos'), p.totalAbertos);
  contarAte($('nAguardando'), p.fila.aguardando);
  contarAte($('nAprovadas'), p.fila.aprovadas);
  contarAte($('nColadas'), p.fila.coladas30);
  if (q.revisoes) contarAte($('nNota'), q.notaMedia, 1);
  contador('contPend', p.totalAbertos);
  $('painelFila').onclick = abrirFila;
}

function vazioTxt(icone, titulo, texto) { return `<div class="vazio">${ic(icone)}<b>${titulo}</b>${texto}</div>`; }

document.addEventListener('click', (ev) => {
  const ir = ev.target.closest('[data-ir]');
  if (ir) { mostrarAba(ir.dataset.ir); return; }
  const dia = ev.target.closest('.dia-col[data-dia]');
  if (dia) irParaDia(dia.dataset.dia);
});

$('lerHoje').onclick = () => {
  irParaDia(new Date().toLocaleDateString('pt-BR'));
  $('varrer').click();
};
document.querySelectorAll('nav.abas [data-aba]').forEach((b) => (b.onclick = () => mostrarAba(b.dataset.aba)));

function tomAtraso(d) { return d >= 15 ? 'perigo' : d >= 7 ? 'atencao' : 'neutro'; }

async function carregarPendencias() {
  try {
    const r = await api('GET', `/api/pendencias?dias=${$('pendDias').value}`);
    contador('contPend', r.lista.length);
    $('pendInfo').textContent = `${r.diasLidos} dia(s) lido(s) neste período. Dias que você ainda não leu na aba Dia não aparecem aqui.`;
    pendencias = r.lista;
    desenharPendencias();
  } catch (e) { $('pendLinhas').innerHTML = vazio('alerta', 'Não consegui carregar as pendências', esc(e.message), 7); }
}

let pendencias = [];
function desenharPendencias() {
    desenharFiltros('pend', pendencias);
    const lista = aplicarFiltros('pend', pendencias);
    $('pendLinhas').innerHTML = lista.length ? lista.map((a) => `<tr class="linha">
      <td><span class="atraso ${tomAtraso(a.diasDesde)}" title="Dias desde o atendimento">${a.diasDesde} d</span></td>
      <td class="num">${esc(a.data)}<div class="sub">${esc(a.hora)} · ${esc(a.local || '')}</div></td>
      <td><div class="pac">${esc(a.paciente)}</div><div class="sub">${esc(a.empresa)}</div>${a.doMedico === 2 ? `<div class="sub alerta">${ic('alerta')}Profissional não definido</div>` : ''}</td>
      <td>${esc(a.tipo)}</td>
      <td><div class="doc">${a.documentoPrincipal}</div>${chip(a.estadoPrincipal, a.estadoPrincipalTexto)}</td>
      <td>${a.estadoAso ? `<div class="doc">ASO</div>${chip(a.estadoAso, a.estadoAsoTexto)}` : ''}</td>
      <td class="acoes-col">${a.podeAbrir ? `<button class="bt fantasma peq" data-abrir="${a.id}">${ic('abrir')}Abrir no SOC</button>` : ''}</td></tr>`).join('')
      : pendencias.length ? vazio('caixa', 'Nada neste filtro', 'Limpe os filtros para ver todas as pendências.', 7)
      : vazio('escudo', 'Tudo assinado', 'Nenhuma pendência nos dias já lidos deste período.', 7);
}
$('pendDias').onchange = carregarPendencias;

document.addEventListener('click', async (ev) => {
  const b = ev.target.closest('[data-abrir]');
  if (!b) return;
  const antes = b.innerHTML;
  b.disabled = true; b.innerHTML = `${girando}Abrindo…`;
  try { await api('POST', '/api/abrir', { atendimentoId: Number(b.dataset.abrir) }); b.innerHTML = `${ic('ok')}Aberta no Edge`; }
  catch (e) { avisar(e.message, 'erro'); b.innerHTML = antes; }
  setTimeout(() => { b.disabled = false; b.innerHTML = antes; }, 4000);
});

// ---------------- configurações ----------------

let cfg = { revisoesSimultaneas: 2 };
async function carregarConfig() { try { cfg = await api('GET', '/api/config'); } catch {} aplicarModoIA(); }
function aplicarModoIA() {
  const manual = cfg.modoIA === 'manual';
  document.body.classList.toggle('modo-manual', manual);
  $('revisarTodos').hidden = manual;
}
function fecharConfig() { $('config').classList.remove('aberto'); }
$('abrirConfig').onclick = async () => {
  await carregarConfig();
  $('cfgMedico').value = cfg.medico || '';
  $('cfgModelo').value = cfg.modeloClaudeCode || 'opus';
  $('cfgModoIA').value = cfg.modoIA || 'auto';
  $('cfgParalelo').value = String(cfg.revisoesSimultaneas || 2);
  $('cfgAlerta').value = cfg.diasAlertaSemAssinatura || 7;
  $('config').classList.add('aberto');
  $('cfgMedico').focus();
};
$('cfgFechar').onclick = fecharConfig;
$('cfgCancelar').onclick = fecharConfig;
$('config').addEventListener('click', (ev) => { if (ev.target === $('config')) fecharConfig(); });
$('cfgSalvar').onclick = async () => {
  try {
    cfg = await api('POST', '/api/config', { medico: $('cfgMedico').value, modeloClaudeCode: $('cfgModelo').value, modoIA: $('cfgModoIA').value,
      revisoesSimultaneas: Number($('cfgParalelo').value), diasAlertaSemAssinatura: Number($('cfgAlerta').value) });
    fecharConfig();
    aplicarModoIA();
    avisar('Configurações salvas.', 'ok');
    atualizarEstado();
  } catch (e) { avisar(e.message, 'erro'); }
};

// ---------------- modo manual (claude.ai) ----------------

$('abrirManual').onclick = () => { $('manual').classList.add('aberto'); $('manCopiar').focus(); };
$('manFechar').onclick = () => $('manual').classList.remove('aberto');
$('manual').addEventListener('click', (ev) => { if (ev.target === $('manual')) $('manual').classList.remove('aberto'); });
$('manCopiar').onclick = async () => {
  const d = dataBR();
  if (!d) return avisar('Escolha o dia primeiro.', 'erro');
  try {
    const r = await api('POST', '/api/manual/pedido', { data: d });
    try { await navigator.clipboard.writeText(r.texto); }
    catch { $('manResposta').value = r.texto; $('manResposta').select(); avisar('Não consegui copiar sozinho: o pedido está selecionado na caixa do passo 3. Copie com Ctrl+C e depois apague.', 'info'); return; }
    $('manInfo').textContent = `Pedido com ${r.quantidade} campo(s) copiado. Agora cole no claude.ai.`;
    avisar(`Pedido com ${r.quantidade} campo(s) copiado.`, 'ok');
  } catch (e) { avisar(e.message, 'erro'); }
};
$('manLer').onclick = async () => {
  try {
    const r = await api('POST', '/api/manual/resposta', { texto: $('manResposta').value });
    $('manResposta').value = '';
    $('manual').classList.remove('aberto');
    avisar(`${r.feitas} revisão(ões) prontas na Fila${r.ignoradas.length ? `; ${r.ignoradas.length} item(ns) não reconhecido(s)` : ''}.`, 'ok');
    await carregar();
    abrirFila();
  } catch (e) { avisar(e.message, 'erro'); }
};

// ---------------- leitura e revisão em lote ----------------

$('detectar').onclick = async () => {
  try {
    const a = await api('POST', '/api/agenda/detectar');
    localStorage.setItem('agenda', a.codigo);
    await atualizarEstado();
    $('agenda').value = a.codigo;
    avisar(`Local guardado: ${a.nome}`, 'ok');
  } catch (e) { avisar(e.message, 'erro'); }
};

$('buscarAgendas').onclick = async () => {
  const b = $('buscarAgendas');
  b.disabled = true;
  try {
    const r = await api('POST', '/api/agendas/buscar');
    await atualizarEstado();
    if (r.reconheceu) avisar(`${r.agendas.length} agendas no seletor, as mesmas do SOC.`, 'ok');
    else avisar('O SOC não mostrou a lista de agendas do jeito esperado. Abra o console da aba do SOC (F12) e me mande a linha que começa com [revisa.].', 'erro');
  } catch (e) { avisar(e.message, 'erro'); } finally { b.disabled = false; }
};

// Ao trocar o dia: se o dia já foi lido, o seletor mostra a agenda em que você atendeu; senão, volta para a busca nas suas agendas.
function ajustarAgendaDoDia() {
  const codigos = [...new Set(atendimentos.filter((a) => a.doMedico === 1 && a.agendaCodigo).map((a) => a.agendaCodigo))];
  const quer = codigos.length === 1 ? codigos[0] : '@minhas';
  const sel = $('agenda');
  if ([...sel.options].some((o) => o.value === quer)) sel.value = quer;
  localStorage.setItem('agenda', sel.value);
}

$('varrer').onclick = async () => {
  const d = dataBR();
  if (!d) return avisar('Escolha o dia primeiro.', 'erro');
  localStorage.setItem('agenda', $('agenda').value);
  try {
    await api('POST', '/api/varrer', { data: d, agendaCodigo: $('agenda').value });
    const timer = setInterval(async () => {
      const p = await atualizarEstado();
      await carregar();
      if (p && !p.rodando) { clearInterval(timer); ajustarAgendaDoDia(); }
    }, 2000);
  } catch (e) { avisar(e.message, 'erro'); }
};

$('revisarTodos').onclick = async () => {
  const alvos = atendimentos.filter((a) => a.doMedico).flatMap((a) => a.campos.filter((c) => c.texto && !a.revisoes.some((r) => r.campo === c.campo && r.status !== 'descartada')).map((c) => ({ a, c })));
  if (!alvos.length) return avisar('Nada novo para revisar neste dia.', 'info');
  const n = cfg.revisoesSimultaneas || 2;
  const min = Math.ceil((alvos.length * 30) / n / 60);
  if (!confirm(`Mandar ${alvos.length} campo(s) para a IA, já anonimizados? ${n} de cada vez, uns ${min} min no total. Você pode ir aprovando na Fila enquanto isso.`)) return;
  let feito = 0, erros = 0;
  const fila = [...alvos];
  $('barraProg').hidden = false;
  $('revisarTodos').disabled = true;
  const trabalhador = async () => {
    while (fila.length) {
      const { a, c } = fila.shift();
      try { await api('POST', '/api/revisar', { atendimentoId: a.id, campo: c.campo }); } catch (e) { erros++; console.warn(e); }
      feito++;
      $('prog').textContent = `Revisando: ${feito} de ${alvos.length} prontos${erros ? ` (${erros} com erro)` : ''}`;
      $('barraProgI').style.width = `${Math.round((100 * feito) / alvos.length)}%`;
      await carregar();
      if (filaAberta()) desenharFila();
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, alvos.length) }, trabalhador));
  $('barraProg').hidden = true;
  $('revisarTodos').disabled = false;
  $('prog').textContent = `Revisão concluída: ${alvos.length - erros} campo(s)${erros ? `, ${erros} com erro (tente de novo no botão do paciente)` : ''}.`;
  if (!filaAberta()) abrirFila();
};

// ---- lixeira: dois cliques no mesmo botão (o primeiro arma, o segundo apaga) ----
const textosLimpar = { dia: () => `Apagar ${dataBR() || 'este dia'} (${atendimentos.length})`, tudo: () => 'Apagar todos os dias lidos' };
function fecharLixeira() {
  $('popLixeira').hidden = true;
  $('abrirLixeira').setAttribute('aria-expanded', 'false');
  document.querySelectorAll('[data-limpar]').forEach((b) => { b.classList.remove('armado'); b.querySelector('span').textContent = textosLimpar[b.dataset.limpar](); });
}
$('abrirLixeira').onclick = (ev) => {
  ev.stopPropagation();
  const abrir = $('popLixeira').hidden;
  fecharLixeira();
  if (abrir) {
    // Abre para o lado que cabe na tela.
    const pop = $('popLixeira');
    const r = $('abrirLixeira').getBoundingClientRect();
    const cabeDireita = r.left + Math.min(300, innerWidth - 32) <= innerWidth - 16;
    pop.style.left = cabeDireita ? '0' : 'auto';
    pop.style.right = cabeDireita ? 'auto' : '0';
    pop.hidden = false;
    $('abrirLixeira').setAttribute('aria-expanded', 'true');
  }
};
document.addEventListener('click', (ev) => { if (!ev.target.closest('#lixeira')) fecharLixeira(); });
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !$('popLixeira').hidden) fecharLixeira(); });
document.querySelectorAll('[data-limpar]').forEach((b) => b.addEventListener('click', async () => {
  const tudo = b.dataset.limpar === 'tudo';
  if (!tudo && !dataBR()) return avisar('Escolha o dia primeiro.', 'erro');
  if (!b.classList.contains('armado')) {
    document.querySelectorAll('[data-limpar].armado').forEach((x) => { x.classList.remove('armado'); x.querySelector('span').textContent = textosLimpar[x.dataset.limpar](); });
    b.classList.add('armado');
    b.querySelector('span').textContent = tudo ? 'Clique de novo para apagar tudo' : 'Clique de novo para apagar o dia';
    return;
  }
  b.disabled = true;
  try {
    const r = await api('POST', '/api/limpar', tudo ? { tudo: true } : { data: dataBR() });
    fecharLixeira();
    vistos.clear(); estadosAntes.clear(); contagensAntes.clear(); filtroEstado = null;
    await atualizarEstado();
    await carregar();
    await carregarPendencias();
    avisar(r.apagados ? `${r.apagados} atendimento(s) apagado(s). Pode ler de novo.` : 'Não havia nada lido para apagar.', 'ok');
  } catch (e) { avisar(e.message, 'erro'); } finally { b.disabled = false; }
}));

$('soMeus').onchange = desenhar;
$('data').onchange = () => { filtroEstado = null; vistos.clear(); estadosAntes.clear(); contagensAntes.clear(); localStorage.setItem('data', $('data').value); carregar().then(ajustarAgendaDoDia); };
$('agenda').onchange = () => localStorage.setItem('agenda', $('agenda').value);
// Rodapé: troca entre os dados reais e os fictícios (para mostrar o app sem expor nenhum paciente).
const ficticio = document.documentElement.dataset.ficticio === '1';
$('rodapeModo').textContent = ficticio ? 'dados fictícios, nada aqui vem do SOC' : 'dados do SOC neste computador';
$('trocarDados').textContent = ficticio ? 'voltar aos dados reais' : 'ver com dados fictícios';
$('trocarDados').hidden = document.documentElement.dataset.demo === '1';
$('trocarDados').onclick = () => {
  try { localStorage.setItem('dadosFicticios', ficticio ? '0' : '1'); } catch {}
  location.reload();
};

$('data').value = localStorage.getItem('data') || new Date().toLocaleDateString('sv-SE');
carregarConfig();
mostrarAba(localStorage.getItem('aba') || 'inicio');
atualizarEstado().then(carregar).then(ajustarAgendaDoDia).then(carregarPendencias);
setInterval(atualizarEstado, 15000);
