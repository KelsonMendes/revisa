
const $ = (id) => document.getElementById(id);
try { if (localStorage.getItem('animacoes') === 'sim') document.documentElement.classList.add('animar'); } catch {}
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const ic = (nome) => `<svg class="ic"><use href="#i-${nome}"/></svg>`;
const girando = `<svg class="ic gira"><use href="#i-gira"/></svg>`;
// Memória do último desenho: só anima o que é novo ou mudou (a tela redesenha a cada 2 s durante a leitura).
const vistos = new Set();
const revVistas = new Set();
const estadosAntes = new Map();
const contagensAntes = new Map();
let ultimoProgresso = null;
let atendimentos = [];
let filtroEstado = null;
let filaIdx = 0;
let listasDoLote = { gerar: [], assinar: [], aso: [] };
let loteAberto = null;

// O que o botão "Fazer" faz com o texto aprovado. A escolha fica lembrada neste navegador.
const ACOES_SOC = {
  copiar: { nome: 'Só copiar o texto', info: 'Copia o texto aprovado; você cola no SOC.' },
  colar: { nome: 'Colar no SOC (eu salvo)', info: 'Abre a ficha em modo Alterar e cola. Quem salva é você.',
    confirmar: 'Abrir esta ficha no SOC em modo Alterar e colar o texto aprovado? Nada será salvo automaticamente.', andamento: 'Colando…' },
  salvar: { nome: 'Colar e salvar', info: 'Cola e salva a ficha. Não gera PDF.',
    confirmar: 'Colar o texto aprovado e salvar a ficha no SOC?', andamento: 'Colando e salvando…' },
  pdf: { nome: 'Colar, salvar e gerar o PDF', info: 'Cola, salva e gera o PDF da ficha; se o parecer for Apto, grava o ASO e gera o PDF dele. Assinar fica com você.',
    confirmar: 'Colar o texto aprovado, salvar a ficha e gerar o PDF? Se o parecer for Apto, o ASO também é gravado como "Apto para função" e o PDF dele é gerado.', andamento: 'Colando, salvando e gerando o PDF…' },
  assinar: { nome: 'Colar, salvar, gerar o PDF e assinar', info: 'Tudo do item anterior e, no fim, assina o PDF da ficha pela pastinha com o seu certificado. O ASO fica para você assinar.',
    confirmar: 'Colar o texto aprovado, salvar a ficha, gerar o PDF e ASSINAR o PDF da ficha com o seu certificado? Se o SOC pedir o certificado ou a senha, responda na janela do SOC.', andamento: 'Colando, salvando, gerando e assinando…' },
};
function acaoSoc() {
  try { const v = localStorage.getItem('revisa.acaoSoc'); if (ACOES_SOC[v]) return v; } catch { /* sem armazenamento */ }
  return 'pdf';
}
// Orientar × encaminhar: o texto da opção acompanha a escolha.
document.addEventListener('change', (ev) => {
  const radio = ev.target.closest?.('[data-cond-forma]');
  if (!radio) return;
  const caixa = radio.closest('[data-cond]');
  const op = condutasDe(revisaoPorId(Number(caixa.dataset.cond)))[Number(radio.dataset.condForma)];
  const alvo = caixa.querySelector(`[data-cond-texto="${radio.dataset.condForma}"]`);
  if (op && alvo) alvo.textContent = radio.value === 'encaminhar' && op.texto_encaminhando ? op.texto_encaminhando : op.texto;
});
document.addEventListener('change', (ev) => {
  const sel = ev.target.closest?.('select.acao-soc');
  if (!sel) return;
  try { localStorage.setItem('revisa.acaoSoc', sel.value); } catch { /* sem armazenamento */ }
  const info = $(`acaoInfo${sel.id.slice(4)}`);
  if (info) info.textContent = ACOES_SOC[sel.value].info;
});
const editando = new Set();

// ---------------- avisos rápidos (no lugar de alert) ----------------

function avisar(texto, tipo = 'info') {
  const el = document.createElement('div');
  el.className = `aviso-rapido ${tipo}`;
  el.innerHTML = `${ic(tipo === 'ok' ? 'ok' : tipo === 'erro' ? 'alerta' : 'relogio')}<span>${esc(texto)}</span>`;
  $('avisos').append(el);
  setTimeout(() => { el.classList.add('saindo'); el.addEventListener('animationend', () => el.remove(), { once: true }); }, tipo === 'erro' ? 8000 : 5000);
}

// ---------------- diff por palavras (LCS) ----------------

function tokens(s) {
  return String(s || '').match(/\s+|[\wÀ-ÿ]+|[^\s\wÀ-ÿ]/g) || [];
}

function diff(a, b) {
  const A = tokens(a), B = tokens(b);
  const n = A.length, m = B.length;
  const L = Array.from({ length: n + 1 }, () => new Uint16Array(m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) L[i][j] = A[i] === B[j] ? L[i + 1][j + 1] + 1 : Math.max(L[i + 1][j], L[i][j + 1]);
  const ops = [];
  let i = 0, j = 0;
  const push = (t, s) => { const u = ops[ops.length - 1]; u && u.t === t ? (u.s += s) : ops.push({ t, s }); };
  while (i < n && j < m) {
    if (A[i] === B[j]) { push('=', A[i]); i++; j++; }
    else if (L[i + 1][j] >= L[i][j + 1]) { push('-', A[i]); i++; }
    else { push('+', B[j]); j++; }
  }
  while (i < n) push('-', A[i++]);
  while (j < m) push('+', B[j++]);
  // junta "- espaço +" em um bloco só e não marca mudanças só de espaço
  const blocos = [];
  for (const o of ops) {
    if (o.t === '=' && /^\s+$/.test(o.s) && blocos.length && blocos[blocos.length - 1].t !== '=') {
      const u = blocos[blocos.length - 1]; u.de += o.s; u.para += o.s; continue;
    }
    if (o.t === '=') { blocos.push({ t: '=', s: o.s }); continue; }
    let u = blocos[blocos.length - 1];
    if (!u || u.t !== 'x') { u = { t: 'x', de: '', para: '' }; blocos.push(u); }
    if (o.t === '-') u.de += o.s; else u.para += o.s;
  }
  return blocos;
}

const norm = (s) => String(s || '').toLowerCase().replace(/\s+/g, ' ').trim();

// Acha, entre as alterações explicadas pela IA, a que corresponde a um bloco do diff.
function motivoDe(bloco, alteracoes) {
  const de = norm(bloco.de), para = norm(bloco.para);
  let melhor = null, nota = 0;
  for (const a of alteracoes || []) {
    const ad = norm(a.de), ap = norm(a.para);
    let p = 0;
    if (para && ap && (ap.includes(para) || para.includes(ap))) p += Math.min(para.length, ap.length) + 5;
    if (de && ad && (ad.includes(de) || de.includes(ad))) p += Math.min(de.length, ad.length) + 5;
    if (p > nota) { nota = p; melhor = a; }
  }
  return melhor;
}

function realcarCompletar(html) {
  return html.replace(/\[COMPLETAR:?[^\]]*\]/gi, (m) => `<mark class="c" data-motivo="Falta informação: preencha antes de aprovar.">${m}</mark>`);
}

// Divide um trecho alterado nos pedaços que a IA explicou (cada "de"/"para" achado dentro dele).
function pedacos(texto, alteracoes, campo) {
  const marcas = [];
  const baixo = texto.toLowerCase();
  for (const a of alteracoes || []) {
    const alvo = String(a[campo] || '').trim().toLowerCase();
    if (alvo.length < 3) continue;
    const i = baixo.indexOf(alvo);
    if (i >= 0 && !marcas.some((m) => i < m.fim && i + alvo.length > m.ini)) marcas.push({ ini: i, fim: i + alvo.length, a });
  }
  marcas.sort((x, y) => x.ini - y.ini);
  const out = [];
  let pos = 0;
  for (const m of marcas) {
    if (m.ini > pos) out.push({ s: texto.slice(pos, m.ini), a: null });
    out.push({ s: texto.slice(m.ini, m.fim), a: m.a });
    pos = m.fim;
  }
  if (pos < texto.length) out.push({ s: texto.slice(pos), a: null });
  return out;
}

function renderDiff(original, sugerido, alteracoes, rid) {
  const blocos = diff(original, sugerido);
  const ids = new Map(); // alteração → id do par (liga o pedaço da esquerda com o da direita)
  let esq = '', dir = '', k = 0;
  const marcar = (tag, b, pedaco, padrao) => {
    if (!pedaco.s.trim()) return tag === 'ins' ? realcarCompletar(esc(pedaco.s)) : esc(pedaco.s);
    const a = pedaco.a || motivoDe(b, alteracoes);
    if (a && !ids.has(a)) ids.set(a, `${rid}-${k++}`);
    const id = a ? ids.get(a) : `${rid}-${k++}`;
    const motivo = a ? a.motivo : padrao;
    const attrs = `data-par="${id}" data-motivo="${esc(motivo)}" data-de="${esc((a ? a.de : b.de).trim())}" data-para="${esc((a ? a.para : b.para).trim())}"`;
    const corpo = tag === 'ins' ? realcarCompletar(esc(pedaco.s)) : esc(pedaco.s);
    return tag === 'ins' ? `<ins class="i" ${attrs}>${corpo}</ins>` : `<del class="d" ${attrs}>${corpo}</del>`;
  };
  for (const b of blocos) {
    if (b.t === '=') { esq += esc(b.s); dir += realcarCompletar(esc(b.s)); continue; }
    if (!b.de.trim() && !b.para.trim()) { esq += esc(b.de); dir += esc(b.para); continue; }
    for (const p of pedacos(b.de, alteracoes, 'de')) esq += marcar('del', b, p, 'Trecho retirado pela revisão.');
    for (const p of pedacos(b.para, alteracoes, 'para')) dir += marcar('ins', b, p, 'Ajuste de redação.');
  }
  return { esq, dir, mudancas: new Set([...(esq + dir).matchAll(/data-par="([^"]+)"/g)].map((m) => m[1])).size };
}

// ---------------- dica ao passar o mouse ----------------

document.addEventListener('mouseover', (ev) => {
  const simples = ev.target.closest('[data-dica]');
  if (simples) { const d = $('dica'); d.textContent = simples.dataset.dica; d.style.display = 'block'; return; }
  const el = ev.target.closest('[data-motivo]');
  document.querySelectorAll('.par').forEach((x) => x.classList.remove('par'));
  const dica = $('dica');
  if (!el) { dica.style.display = 'none'; return; }
  if (el.dataset.par) document.querySelectorAll(`[data-par="${el.dataset.par}"]`).forEach((x) => x.classList.add('par'));
  const de = el.dataset.de, para = el.dataset.para;
  dica.innerHTML = `<span class="rot">Por que mudou</span>${esc(el.dataset.motivo)}` +
    (de || para ? `<div class="antes">${de ? `Antes: “${esc(de.slice(0, 140))}”` : 'Acréscimo'}${para && de ? `<br>Depois: “${esc(para.slice(0, 140))}”` : ''}</div>` : '');
  dica.style.display = 'block';
});
document.addEventListener('mousemove', (ev) => {
  const d = $('dica');
  if (d.style.display !== 'block') return;
  const x = Math.min(ev.clientX + 14, innerWidth - d.offsetWidth - 8);
  const y = ev.clientY + 18 + d.offsetHeight > innerHeight ? ev.clientY - d.offsetHeight - 10 : ev.clientY + 18;
  d.style.left = x + 'px'; d.style.top = y + 'px';
});

// ---------------- dados ----------------

function dataBR() {
  const v = $('data').value;
  if (!v) return null;
  const [a, m, d] = v.split('-');
  return `${d}/${m}/${a}`;
}

async function api(metodo, rota, corpo) {
  const r = await fetch(rota, { method: metodo, headers: { 'Content-Type': 'application/json' }, body: corpo ? JSON.stringify(corpo) : undefined });
  const j = await r.json();
  if (!r.ok) throw new Error(j.erro || 'Erro');
  return j;
}

function mostrarStatus(tom, texto) {
  $('status').className = `estado-soc ${tom}`;
  $('status').querySelector('span').textContent = texto;
  $('status').title = texto;
}

async function atualizarEstado() {
  try {
    const e = await api('GET', '/api/estado');
    if (!e.edgeAberto) mostrarStatus('erro', 'Edge do auditor fechado: abra pelo atalho');
    else if (e.soc?.erro) mostrarStatus('erro', e.soc.erro);
    else if (e.soc?.logado) mostrarStatus('ok', e.medico ? `SOC conectado · ${e.medico}` : 'SOC conectado');
    else mostrarStatus('aviso', 'Faça login no SOC na janela do Edge');
    // Seletor: as duas buscas, suas agendas (onde já houve atendimento seu) e as demais que o SOC oferece.
    const sel = $('agenda');
    const atual = sel.value || localStorage.getItem('agenda') || '@minhas';
    const opc = (a) => `<option value="${esc(a.codigo)}">${esc(a.nome)}</option>`;
    const minhas = e.agendas.filter((a) => a.minha), outras = e.agendas.filter((a) => !a.minha);
    const html = '<option value="@minhas">Procurar nas minhas agendas</option><option value="@todas">Procurar em todas as agendas do SOC</option>'
      + (minhas.length ? `<optgroup label="Minhas agendas">${minhas.map(opc).join('')}</optgroup>` : '')
      + (outras.length ? `<optgroup label="${minhas.length ? 'Outras agendas do SOC' : 'Agendas do SOC'}">${outras.map(opc).join('')}</optgroup>` : '');
    if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; }
    if ([...sel.options].some((o) => o.value === atual)) sel.value = atual;
    const p = e.progresso;
    $('prog').innerHTML = p.rodando ? esc(p.etapa)
      : p.erro ? `<span class="erro-msg">Erro na leitura: ${esc(p.erro)}</span>` : p.aviso ? esc(p.aviso) : p.terminou && p.resumo ? `Última leitura às ${new Date(p.terminou).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}: ${esc(p.resumo)}` : p.terminou ? `Última leitura às ${new Date(p.terminou).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}` : '';
    ultimoProgresso = p;
    trazerAgendasSozinho(e);
    // Guarda a agenda aberta no SOC; se você ainda não escolheu outra, ela vira o local selecionado.
    if (e.soc?.agendaAberta?.codigo && e.soc.agendaAberta.codigo !== agendaAbertaSoc) {
      agendaAbertaSoc = e.soc.agendaAberta.codigo;
      try { localStorage.setItem('agendaSoc', agendaAbertaSoc); } catch {}
      if (!p.rodando) ajustarAgendaDoDia();
    }
    $('barraProg').hidden = !p.rodando;
    $('barraProg').classList.toggle('indef', p.rodando && !p.total);
    $('barraProgI').style.width = p.total ? `${Math.round((100 * p.feito) / p.total)}%` : '';
    $('varrer').disabled = p.rodando;
    if ($('varrerAberta')) $('varrerAberta').disabled = p.rodando;
    $('varrer').innerHTML = p.rodando ? `${girando}Lendo o SOC…` : `${ic('ler')}Ler o dia no SOC`;
    return p;
  } catch {
    mostrarStatus('erro', 'Painel sem conexão: abra pelo atalho');
  }
}

async function carregar() {
  const d = dataBR();
  if (!d) return;
  // O que você mexeu numa sugestão (edição, perguntas, conduta, exame) vale mais que a cópia que vem do app:
  // a leitura do SOC recarrega a lista a cada 2 s e não pode apagar o seu trabalho.
  salvarEdicoes();
  const locais = new Map(atendimentos.flatMap((a) => a.revisoes).filter((r) => r.status === 'sugerida').map((r) => [r.id, r.texto_sugerido]));
  const foco = document.activeElement?.matches?.('textarea[id^="t"]') && !document.activeElement.closest('#filaCaixa')
    ? { id: document.activeElement.id, ini: document.activeElement.selectionStart, fim: document.activeElement.selectionEnd, rolagem: document.activeElement.scrollTop } : null;
  const novos = await api('GET', `/api/atendimentos?data=${encodeURIComponent(d)}`);
  salvarEdicoes(); // o que foi digitado enquanto a lista vinha
  for (const a of atendimentos) for (const r of a.revisoes) if (r.status === 'sugerida') locais.set(r.id, r.texto_sugerido);
  for (const a of novos) for (const r of a.revisoes) if (r.status === 'sugerida' && locais.has(r.id)) r.texto_sugerido = locais.get(r.id);
  atendimentos = novos;
  desenhar();
  if (foco) {
    const t = document.querySelector(`#linhas textarea[id="${foco.id}"]`);
    if (t) { t.focus(); t.setSelectionRange(foco.ini, foco.fim); t.scrollTop = foco.rolagem; }
  }
}

function pendentesDaFila() {
  return atendimentos.filter((a) => a.doMedico && !a.concluido).flatMap((a) => a.revisoes.filter((r) => r.status === 'sugerida' || r.status === 'aprovada').map((r) => ({ a, r })));
}

// ---------------- tabela do dia ----------------

function chip(estado, texto, mudou = false) {
  return estado ? `<span class="chip ${esc(estado)} ${mudou ? 'mudou' : ''}">${esc(texto)}</span>` : '<span class="chip nao_encontrado">Sem dado</span>';
}

// Filtros por tipo de atendimento, documento, local e empresa, mais a busca pelo nome (abas Dia e Pendências).
// As opções saem dos próprios atendimentos da lista, cada uma com a quantidade.
const CAMPOS_FILTRO = [
  ['tipo', 'Tipo', 'Todos os tipos', (a) => a.tipo || 'Sem tipo'],
  ['doc', 'Documento', 'Fichas e licenças', (a) => a.documentoPrincipal],
  ['local', 'Local', 'Todos os locais', (a) => a.local || 'Sem local'],
  ['empresa', 'Empresa', 'Todas as empresas', (a) => a.empresa || 'Sem empresa'],
];
const filtrosPor = { dia: {}, pend: {} };
try { Object.assign(filtrosPor.pend, JSON.parse(localStorage.getItem('filtrosPend') || '{}')); } catch {}

function aplicarFiltros(qual, lista, menos) {
  const f = filtrosPor[qual];
  const busca = (f.busca || '').trim().toUpperCase();
  return lista.filter((a) => CAMPOS_FILTRO.every(([k, , , v]) => k === menos || !f[k] || v(a) === f[k])
    && (!busca || `${a.paciente} ${a.empresa}`.toUpperCase().includes(busca)));
}

function desenharFiltros(qual, lista) {
  const caixa = $(qual === 'dia' ? 'filtrosDia' : 'filtrosPend');
  const f = filtrosPor[qual];
  if (!caixa.dataset.montado) {
    caixa.dataset.montado = '1';
    caixa.innerHTML = CAMPOS_FILTRO.map(([k, rotulo]) => `<label class="campo" data-campo="${k}">${rotulo} <select data-filtro-campo="${k}"></select></label>`).join('')
      + `<label class="campo busca">Paciente ou empresa <input type="search" data-filtro-campo="busca" placeholder="Buscar pelo nome" value="${esc(f.busca || '')}"></label>`
      + '<button class="bt fantasma peq" data-limpar-filtros hidden>Limpar filtros</button>';
    const mudou = (ev) => {
      const el = ev.target.closest('[data-filtro-campo]');
      if (!el) return;
      f[el.dataset.filtroCampo] = el.value;
      if (qual === 'pend') { try { localStorage.setItem('filtrosPend', JSON.stringify(f)); } catch {} desenharPendencias(); } else desenhar();
    };
    caixa.addEventListener('change', mudou);
    caixa.addEventListener('input', (ev) => ev.target.type === 'search' && mudou(ev));
    caixa.querySelector('[data-limpar-filtros]').onclick = () => {
      for (const k of Object.keys(f)) f[k] = '';
      caixa.querySelector('input').value = '';
      if (qual === 'pend') { try { localStorage.removeItem('filtrosPend'); } catch {} desenharPendencias(); } else desenhar();
    };
  }
  for (const [k, , todos, v] of CAMPOS_FILTRO) {
    // Cada lista conta os atendimentos que sobram com os outros filtros aplicados.
    const contas = new Map();
    for (const a of aplicarFiltros(qual, lista, k)) contas.set(v(a), (contas.get(v(a)) || 0) + 1);
    if (f[k] && !contas.has(f[k])) contas.set(f[k], 0);
    const sel = caixa.querySelector(`select[data-filtro-campo="${k}"]`);
    const total = [...contas.values()].reduce((x, y) => x + y, 0);
    const html = `<option value="">${todos} (${total})</option>` + [...contas.entries()].sort((x, y) => y[1] - x[1] || x[0].localeCompare(y[0]))
      .map(([valor, n]) => `<option value="${esc(valor)}">${esc(valor)} (${n})</option>`).join('');
    if (sel.dataset.html !== html) { sel.innerHTML = html; sel.dataset.html = html; }
    sel.value = f[k] || '';
    sel.classList.toggle('usado', !!f[k]);
    // Uma opção só (ex.: um local no dia) não ajuda a filtrar: some, a não ser que esteja em uso.
    sel.closest('.campo').hidden = contas.size < 2 && !f[k];
  }
  caixa.querySelector('input').classList.toggle('usado', !!(f.busca || '').trim());
  caixa.querySelector('[data-limpar-filtros]').hidden = !Object.values(f).some((x) => x && String(x).trim());
}

// "A fazer" é a lista do dia sem os já inspecionados (fluxo terminado: ficha e ASO assinados). Eles ficam no último botão.
const FILTROS = [
  ['A fazer', (a) => !a.concluido, ''],
  ['Não geradas', (a) => !a.concluido && a.estadoPrincipal === 'nao_gerada', 'perigo'],
  ['Sem PDF ou assinatura', (a) => !a.concluido && ['sem_pdf', 'pdf_pendente'].includes(a.estadoPrincipal), 'atencao'],
  ['Assinadas', (a) => !a.concluido && a.estadoPrincipal === 'assinada', 'ok'],
  ['ASO pendente', (a) => !a.concluido && a.estadoAso && a.estadoAso !== 'assinada', 'atencao'],
  ['Já inspecionados', (a) => a.concluido, 'ok'],
];

// Pequenas cenas desenhadas para os estados vazios (mesmo traço dos ícones).
const ILUSTRA = {
  calendario: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <rect class="papel" x="28" y="18" width="62" height="64" rx="8"/><rect class="acao" x="28" y="18" width="62" height="14" rx="7"/><rect class="acao" x="28" y="25" width="62" height="7"/>
    <path class="linha" d="M40 44h8M54 44h8M68 44h8M40 56h8M54 56h8M68 56h8M40 68h8"/>
    <g class="flutua"><rect class="papel" x="74" y="40" width="40" height="46" rx="6"/><path class="linha" d="M82 52h24M82 60h18M82 68h22"/><path class="acao-l" d="M84 78l4 4 8-8"/></g></svg>`,
  escudo: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <rect class="papel" x="34" y="16" width="54" height="68" rx="6"/><path class="linha" d="M44 30h34M44 40h28M44 50h32"/>
    <circle class="carimbo" cx="72" cy="66" r="12"/><circle class="carimbo" cx="72" cy="66" r="8"/>
    <g class="flutua"><circle class="ok-f" cx="98" cy="34" r="16"/><path class="ok-l" d="M90 34l6 6 11-12"/></g></svg>`,
  caixa: `<svg class="ilustra" viewBox="0 0 132 96" aria-hidden="true"><rect class="fundo" x="6" y="10" width="120" height="80" rx="14"/>
    <path class="papel" d="M30 52l12-22h48l12 22v22a6 6 0 0 1-6 6H36a6 6 0 0 1-6-6z"/><path class="linha" d="M30 52h22l4 8h20l4-8h22"/>
    <g class="flutua"><circle class="ok-f" cx="66" cy="34" r="12"/><path class="ok-l" d="M60 34l4 4 8-8"/></g></svg>`,
};

function vazio(icone, titulo, texto, colunas) {
  return `<tr><td colspan="${colunas}"><div class="vazio">${ILUSTRA[icone] || ic(icone)}<b>${titulo}</b>${texto}</div></td></tr>`;
}

function statusRevisao(c, r) {
  if (r.status === 'colada') return `<span class="st-rev ok">${ic('ok')}${esc(c.rotulo)}: colado no SOC</span>`;
  if (r.status === 'aprovada') return `<span class="st-rev espera">${ic('colar')}${esc(c.rotulo)}: aprovado, falta colar</span>`;
  return `<span class="st-rev espera">${ic('relogio')}${esc(c.rotulo)}: nota ${r.resultado?.nota_completude ?? '?'}, aguardando você</span>`;
}

function desenhar() {
  // Só os seus atendimentos (e os de agenda sem profissional, para você conferir). Os de outros médicos ficam fora.
  const doMedico = atendimentos.filter((a) => a.doMedico);
  desenharFiltros('dia', doMedico);
  const base = aplicarFiltros('dia', doMedico);
  $('resumo').innerHTML = FILTROS.map(([t, f, tom], i) => {
    const n = base.filter(f).length;
    const pulo = contagensAntes.has(i) && contagensAntes.get(i) !== n ? 'pulo' : '';
    contagensAntes.set(i, n);
    return `<button data-filtro="${i}" data-tom="${tom}" class="${(filtroEstado ?? 0) === i ? 'ativo' : ''}">${t} <b class="${pulo}">${n}</b></button>`;
  }).join('');
  const lista = base.filter(FILTROS[filtroEstado ?? 0][1]);
  // Lotes (Kelson, 17/11): dois botões separados. Valem para todos os seus "A fazer" do dia (com os filtros de tipo,
  // local e empresa), qualquer que seja a aba de estado escolhida.
  const doLote = base.filter((a) => a.doMedico === 1 && !a.concluido);
  listasDoLote = {
    gerar: doLote.filter((a) => a.estadoPrincipal === 'sem_pdf'),
    assinar: doLote.filter((a) => ['pdf_pendente', 'pdf_pedido'].includes(a.estadoPrincipal)),
    aso: doLote.filter((a) => a.estadoAso && a.estadoAso !== 'assinada' && !['outro_medico', 'nao_compareceu', 'nao_gerada', 'erro'].includes(a.estadoPrincipal)),
  };
  $('loteGerarN').textContent = listasDoLote.gerar.length;
  $('loteAssinarN').textContent = listasDoLote.assinar.length;
  if (loteAberto) mostrarLote(loteAberto);
  contador('contFila', pendentesDaFila().length);

  if (!lista.length && !atendimentos.length && ultimoProgresso?.rodando) {
    $('linhas').innerHTML = Array.from({ length: 5 }, () => `<tr class="esqueleto">${'<td><span class="barra-cinza"></span><span class="barra-cinza"></span></td>'.repeat(6)}</tr>`).join('');
    return;
  }
  if (!lista.length) {
    $('linhas').innerHTML = atendimentos.length
      ? (filtroEstado ?? 0) === 0 && base.some((a) => a.concluido)
        ? vazio('caixa', 'Tudo inspecionado neste dia', 'Os pacientes concluídos estão em "Já inspecionados".', 6)
        : vazio('caixa', 'Nada neste filtro', 'Escolha "A fazer" ou limpe os filtros.', 6)
      : vazio('calendario', 'Nenhum dia lido ainda', 'Escolha o dia e o local acima e clique em "Ler o dia no SOC".', 6);
    return;
  }
  let novos = 0;
  $('linhas').innerHTML = lista.map((a) => {
    const revs = a.revisoes.filter((r) => r.status !== 'descartada');
    const novo = !vistos.has(a.id);
    const ordem = novo ? Math.min(novos++, 12) : 0;
    const antes = estadosAntes.get(a.id);
    const mudou = antes && (antes.p !== a.estadoPrincipal || antes.a !== a.estadoAso);
    vistos.add(a.id);
    estadosAntes.set(a.id, { p: a.estadoPrincipal, a: a.estadoAso });
    const quem = a.doMedico === 2 ? `<div class="sub alerta">${ic('alerta')}Profissional não definido na agenda</div>`
      : a.semProfissional && a.doMedico === 1 ? `<div class="sub" title="Esta agenda não tem a coluna Profissional da Agenda; o médico veio da ficha">Agenda sem profissional · confirmado pela ficha</div>`
      : a.doMedico ? '' : `<div class="sub">Profissional: ${esc(a.profissional || a.medico || '—')}</div>`;
    const acoes = [
      a.podeAbrir && a.doMedico ? `<button class="bt fantasma peq" data-abrir="${a.id}" title="Abre a ficha no Edge, sem alterar nada">${ic('abrir')}Abrir no SOC</button>` : '',
      a.concluido ? `<button class="bt fantasma peq" data-desconcluir="${esc(a.chaveConcluido)}" title="Volta para A fazer; a próxima leitura abre a ficha de novo">Voltar para a lista</button>` : '',
      ...a.campos.map((c) => {
        const r = revs.find((x) => x.campo === c.campo);
        if (r) return statusRevisao(c, r);
        return a.doMedico && !a.concluido && c.texto && cfg.modoIA !== 'manual' ? `<button class="bt peq" data-rev="${a.id}" data-campo="${c.campo}">${ic('revisar')}Revisar ${esc(c.rotulo.toLowerCase())}</button>` : '';
      }),
    ].filter(Boolean).join('');
    return `
    <tr class="linha ${a.doMedico ? '' : 'outro'} ${novo ? 'novo' : ''}" style="--i:${ordem}">
      <td class="hora">${esc(a.hora)}</td>
      <td><div class="pac">${esc(a.paciente)}</div><div class="sub">${esc(a.empresa)}</div>${quem}</td>
      <td>${esc(a.tipo)}</td>
      <td><div class="doc">${a.documentoPrincipal}</div>${chip(a.estadoPrincipal, a.estadoPrincipalTexto, mudou)}${a.alerta ? `<div class="sub alerta">${ic('relogio')}Há ${a.diasDesde} dias sem assinatura</div>` : ''}${a.erro ? `<div class="sub erro-msg">${esc(a.erro)}</div>` : ''}</td>
      <td>${a.estadoAso ? `<div class="doc">ASO</div>${chip(a.estadoAso, a.estadoAsoTexto)}` : ''}</td>
      <td class="acoes-col"><div class="pilha">${acoes}</div></td>
    </tr>
    ${revs.length ? `<tr><td colspan="6" class="painel-row">${revs.map((r) => cartao(a, r)).join('')}</td></tr>` : ''}`;
  }).join('');
}

// ---------------- cartão de revisão ----------------

function tomNota(n) { return n >= 8 ? 'ok' : n >= 5 ? 'atencao' : 'perigo'; }
const ROTULO_GRAV = { alta: 'Alta', media: 'Média', baixa: 'Baixa' };

function cartao(a, r, naFila = false) {
  const res = r.resultado || {};
  const rotulo = a.campos.find((c) => c.campo === r.campo)?.rotulo || r.campo;
  const ordem = { alta: 0, media: 1, baixa: 2 };
  const lista = [...(res.achados || [])].sort((x, y) => ordem[x.gravidade] - ordem[y.gravidade]);
  const achados = lista.map((x) => `<div class="achado" data-trecho="${esc(x.trecho)}" data-rid="${r.id}">
      <span class="grav ${x.gravidade}">${ROTULO_GRAV[x.gravidade] || x.gravidade}</span>
      <div><span class="tit">${esc(x.item)}</span>${x.trecho ? ` <span class="trecho">“${esc(x.trecho)}”</span>` : ''}<p>${esc(x.sugestao)}</p></div></div>`).join('');
  const altas = lista.filter((x) => x.gravidade === 'alta').length;
  const sugerida = r.status === 'sugerida';
  const textoNovo = sugerida ? r.texto_sugerido : r.texto_aprovado;
  const emEdicao = sugerida && editando.has(r.id);
  const d = renderDiff(r.texto_original, textoNovo, res.alteracoes, r.id);
  const nCompletar = (textoNovo.match(/\[(?:COMPLETAR|CONFERIR CONDUTA)/gi) || []).length;
  const nota = res.nota_completude ?? 0;
  const estado = { sugerida: 'Aguardando você', aprovada: 'Aprovado, falta colar', colada: 'Colado no SOC' }[r.status] || r.status;
  const revNova = !revVistas.has(r.id);
  revVistas.add(r.id);
  return `<div class="rev ${revNova ? 'novo' : ''}" id="rev${r.id}">
    <div class="rev-cab">
      <h4>${naFila ? `${esc(a.hora)} · ${esc(a.paciente)} <span class="campo-nome">· ${esc(rotulo)}</span>` : esc(rotulo)}</h4>
      <span class="nota ${tomNota(nota)}" title="Completude do registro, de 0 a 10">${res.nota_completude ?? '?'}<small>/10</small></span>
      <span class="estado">${estado}</span>
    </div>
    <p class="resumo-ia">${esc(res.resumo)}</p>
    <details class="achados" ${naFila || altas ? 'open' : ''}>
      <summary>${ic('seta')}Achados do checklist <span class="cnt">${lista.length}${altas ? ` · ${altas} de gravidade alta` : ''}</span></summary>
      <div class="lista-achados">${achados}</div>
    </details>
    ${sugerida ? blocoExameFisico(r) : ''}
    ${sugerida ? blocoPerguntas(r) : ''}
    ${sugerida ? blocoAjustes(r) : ''}
    ${sugerida ? blocoConduta(r) : ''}
    ${sugerida ? blocoCompletar(r) : ''}
    <div class="legenda">
      <span><del class="d">riscado</del> sai</span><span><ins class="i">sublinhado</ins> entra</span>
      <span>Passe o mouse numa mudança para ver o motivo</span>
      <span class="num">${d.mudancas} mudança(s)</span>
      ${nCompletar ? `<span class="falta">${ic('alerta')}${nCompletar} trecho(s) para completar antes de aprovar</span>` : ''}
    </div>
    <div class="comparar">
      <div><div class="lado-tit">Texto atual no SOC</div><div class="texto" id="orig${r.id}">${d.esq}</div></div>
      <div><div class="lado-tit">${sugerida ? 'Sugestão' : r.status === 'colada' ? 'Texto colado' : 'Texto aprovado'}<span class="esp"></span>
        ${sugerida ? `<button class="bt fantasma peq" data-editar="${r.id}">${ic(emEdicao ? 'revisar' : 'editar')}${emEdicao ? 'Ver alterações' : 'Editar texto'}</button>` : ''}</div>
        ${emEdicao ? `<textarea class="texto" id="t${r.id}">${esc(r.texto_sugerido)}</textarea>` : `<div class="texto">${d.dir}</div>`}</div>
    </div>
    <div class="rodape-rev">
      ${sugerida ? `<button class="bt ok" data-aprovar="${r.id}">${ic('ok')}Aprovar texto</button><button class="bt" data-descartar="${r.id}">Descartar</button>` : ''}
      ${r.status === 'aprovada' ? `<select class="acao-soc" id="acao${r.id}" aria-label="O que fazer no SOC">${Object.entries(ACOES_SOC).map(([k, v]) => `<option value="${k}"${k === acaoSoc() ? ' selected' : ''}>${v.nome}</option>`).join('')}</select><button class="bt prim" data-colar="${r.id}">${ic('colar')}Fazer</button><span class="info" id="acaoInfo${r.id}">${ACOES_SOC[acaoSoc()].info}</span>` : ''}
      ${r.status === 'colada' ? `<span class="info ok">${ic('ok')}Colado. Confira na janela do Edge e clique em Salvar no SOC.</span>` : ''}
      ${naFila ? `<span class="esp"></span><span class="atalhos"><span><kbd>A</kbd> aprovar</span><span><kbd>E</kbd> editar</span><span><kbd>D</kbd> descartar</span><span><kbd>C</kbd> fazer</span><span><kbd>←</kbd><kbd>→</kbd> navegar</span><span><kbd>Esc</kbd> fechar</span></span>` : ''}
    </div>
  </div>`;
}

// ---------- o que o médico confirma na Fila (a IA sugere; só entra no texto com o clique dele) ----------
const confirmados = new Map(); // id da revisão → Set de chaves já usadas ("n0", "c1", "conduta", "exame")
const usado = (id, k) => confirmados.get(id)?.has(k);
function usar(id, ...ks) { const s = confirmados.get(id) || new Set(); ks.forEach((k) => s.add(k)); confirmados.set(id, s); }
const revisaoPorId = (id) => atendimentos.flatMap((a) => a.revisoes).find((x) => x.id === id);

// Põe um trecho no lugar certo do texto: antes da conduta e do parecer (que é sempre a última linha).
// antesDoExame: confirmações e negativas da anamnese entram antes dos sinais vitais e do exame físico.
function inserirNoTexto(texto, trecho, { antesDaConduta = true, antesDoExame = false } = {}) {
  const linhas = texto.replace(/\s+$/, '').split('\n');
  let pos = linhas.length;
  const ultima = linhas.findLastIndex((l) => l.trim());
  if (ultima >= 0 && /^(apt[oa]|inapt[oa])\b/i.test(linhas[ultima].trim())) pos = ultima;
  if (antesDaConduta) {
    const conduta = linhas.findIndex((l) => /^conduta\s*:/i.test(l.trim()));
    if (conduta >= 0 && conduta < pos) pos = conduta;
  }
  if (antesDoExame) {
    const exame = linhas.findIndex((l) => /^(sinais vitais|exame f[ií]sico)/i.test(l.trim()));
    if (exame >= 0 && exame < pos) pos = exame;
  }
  while (pos > 0 && !linhas[pos - 1].trim()) pos--; // sem linhas em branco sobrando
  linhas.splice(pos, 0, '', trecho);
  return linhas.join('\n').replace(/\n{3,}/g, '\n\n');
}

// Perguntas: negativas da função ("Nega …") e confirmações com frase pronta (vacina, preventivos, rastreio).
function blocoPerguntas(r) {
  const neg = (r.resultado?.negativas_funcao || []).map((n, i) => ({ k: `n${i}`, rotulo: n.item })).filter((x) => !usado(r.id, x.k));
  const conf = (r.resultado?.confirmacoes || []).map((c, i) => ({ k: `c${i}`, rotulo: c.pergunta })).filter((x) => !usado(r.id, x.k));
  if (!neg.length && !conf.length) return '';
  const caixa = (x) => `<label><input type="checkbox" data-conf="${x.k}"> ${esc(x.rotulo)}</label>`;
  return `<div class="perguntas" data-perg="${r.id}">
    <div class="perg-tit"><b>Você perguntou isto ao paciente?</b><small>Marque só o que você de fato perguntou. Entra no texto pronto, antes da conduta e do parecer.</small></div>
    ${conf.length ? `<div class="opcoes">${conf.map(caixa).join('')}</div>` : ''}
    ${neg.length ? `<div class="perg-tit"><small>E ele negou:</small></div><div class="opcoes">${neg.map(caixa).join('')}</div>` : ''}
    <div class="acoes-perg"><button class="bt peq" data-incluir-neg="${r.id}">${ic('ok')}Incluir as marcadas</button><button class="bt peq fantasma" data-todas-neg="${r.id}">Perguntei todas</button></div>
  </div>`;
}
function incluirNegativas(botao, todas) {
  salvarEdicoes();
  const caixa = botao.closest('[data-perg]');
  const id = Number(caixa?.dataset.perg);
  const r = revisaoPorId(id);
  if (!r) return;
  const ks = [...caixa.querySelectorAll('[data-conf]')].filter((c) => todas || c.checked).map((c) => c.dataset.conf);
  if (!ks.length) return avisar('Marque o que você perguntou, ou use "Perguntei todas".', 'info');
  const res = r.resultado;
  const frases = ks.filter((k) => k[0] === 'n').map((k) => res.negativas_funcao[Number(k.slice(1))].frase);
  const prontos = ks.filter((k) => k[0] === 'c').map((k) => res.confirmacoes[Number(k.slice(1))].texto);
  const partes = [...prontos];
  if (frases.length) partes.push(`Nega ${frases.length > 1 ? `${frases.slice(0, -1).join(', ')} e ${frases.at(-1)}` : frases[0]}.`);
  let texto = r.texto_sugerido;
  for (const p of partes) texto = inserirNoTexto(texto, p, { antesDoExame: true });
  r.texto_sugerido = texto;
  usar(id, ...ks);
  redesenhar();
  avisar(`Incluído no texto: ${partes.join(' ')}`, 'ok');
}

// O texto do médico prevalece: itens do questionário que contradizem o texto. Os marcados aqui são ajustados
// no SOC junto com a colagem do texto (modo Alterar, sem salvar).
const ajustesEscolhidos = new Map(); // id da revisão → Set de índices desmarcados
function blocoAjustes(r) {
  const lista = r.resultado?.ajustes_questionario || [];
  if (!lista.length) return '';
  const fora = ajustesEscolhidos.get(r.id) || new Set();
  return `<div class="perguntas" data-ajustes="${r.id}">
    <div class="perg-tit"><b>Ajustar o questionário da ficha</b><small>Seu texto diz outra coisa. Os marcados são corrigidos no SOC quando você colar o texto; quem salva é você.</small></div>
    <div class="opcoes" style="display:grid;gap:6px">${lista.map((x, i) => `<label><input type="checkbox" data-ajuste="${i}" ${fora.has(i) ? '' : 'checked'}>
      ${esc(x.grupo ? `${x.grupo} › ` : '')}<b>${esc(x.item)}</b>: ${esc(x.de || '?')} → <b>${esc(x.para)}</b> <small style="color:var(--suave)">(${esc(x.motivo)})</small></label>`).join('')}</div>
  </div>`;
}
document.addEventListener('change', (ev) => {
  const c = ev.target.closest('[data-ajuste]');
  if (!c) return;
  const id = Number(c.closest('[data-ajustes]').dataset.ajustes);
  const fora = ajustesEscolhidos.get(id) || new Set();
  c.checked ? fora.delete(Number(c.dataset.ajuste)) : fora.add(Number(c.dataset.ajuste));
  ajustesEscolhidos.set(id, fora);
});
const ajustesParaColar = (r) => (r.resultado?.ajustes_questionario || []).filter((_x, i) => !(ajustesEscolhidos.get(r.id) || new Set()).has(i));

// Conduta sugerida pela IA: só entra com o clique, logo antes do parecer.
function condutasDe(r) {
  const res = r.resultado || {};
  return res.condutas?.length ? res.condutas : res.conduta_sugerida ? [{ titulo: 'Conduta', texto: res.conduta_sugerida, fonte: 'guia' }] : [];
}
function blocoConduta(r) {
  const lista = condutasDe(r);
  if (!lista.length || usado(r.id, 'conduta')) return '';
  return `<div class="perguntas" data-cond="${r.id}">
    <div class="perg-tit"><b>Conduta</b><small>Marque as que quer na evolução. Entram antes do parecer, como você escreveria.</small></div>
    <div class="opcoes" style="display:grid;gap:8px">${lista.map((c, i) => `<div><label style="align-items:flex-start"><input type="checkbox" data-cond-op="${i}" style="margin-top:3px">
      <span><b>${esc(c.titulo || 'Conduta')}</b>${/fora/i.test(c.fonte) ? ' <small style="color:var(--suave)">(fora do guia)</small>' : ''}<br><span data-cond-texto="${i}">${esc(c.texto)}</span></span></label>
      ${c.texto_encaminhando ? `<div class="orientar-encaminhar" style="margin:4px 0 0 24px;display:flex;gap:12px;font-size:13px">
        <label><input type="radio" name="oe${r.id}_${i}" value="orientar" data-cond-forma="${i}" checked> Orientar</label>
        <label title="Encaminhar exige o documento de encaminhamento"><input type="radio" name="oe${r.id}_${i}" value="encaminhar" data-cond-forma="${i}"> Encaminhar (precisa do documento)</label></div>` : ''}</div>`).join('')}</div>
    <div class="acoes-perg"><button class="bt peq" data-incluir-conduta="${r.id}">${ic('ok')}Incluir as marcadas</button></div>
  </div>`;
}
function incluirConduta(botao) {
  salvarEdicoes();
  const id = Number(botao.closest('[data-cond]')?.dataset.cond);
  const r = revisaoPorId(id);
  if (!r) return;
  const caixa = botao.closest('[data-cond]');
  // Orientar é o padrão; "Encaminhar" troca pela versão de encaminhamento (o médico precisa fazer o documento).
  const forma = (i) => caixa.querySelector(`[data-cond-forma="${i}"]:checked`)?.value || 'orientar';
  const escolhidas = [...caixa.querySelectorAll('[data-cond-op]')].filter((c) => c.checked).map((c) => {
    const i = Number(c.dataset.condOp);
    const op = condutasDe(r)[i];
    return forma(i) === 'encaminhar' && op.texto_encaminhando ? op.texto_encaminhando : op.texto;
  });
  if (!escolhidas.length) return avisar('Marque a conduta que quer incluir.', 'info');
  // Se já existe uma linha "Conduta:", as escolhidas entram nela; senão, uma linha nova antes do parecer.
  const linhas = r.texto_sugerido.split('\n');
  const i = linhas.findIndex((l) => /^conduta\s*:/i.test(l.trim()));
  if (i >= 0) { linhas[i] = `${linhas[i].trimEnd()} ${escolhidas.join(' ')}`; r.texto_sugerido = linhas.join('\n'); }
  else r.texto_sugerido = inserirNoTexto(r.texto_sugerido, `Conduta: ${escolhidas.join(' ')}`, { antesDaConduta: false });
  usar(id, 'conduta');
  redesenhar();
  avisar('Conduta incluída antes do parecer.', 'ok');
}

// [COMPLETAR: …]: um clique troca por "paciente não soube especificar" ou tira o marcador.
function blocoCompletar(r) {
  const itens = [...r.texto_sugerido.matchAll(/\[(?:COMPLETAR|CONFERIR CONDUTA):\s*([^\]]*)\]/gi)].map((m) => m[1].trim());
  if (!itens.length) return '';
  return `<div class="perguntas" data-comp="${r.id}">
    <div class="perg-tit"><b>Falta completar</b><small>Escreva no texto, ou resolva com um clique.</small></div>
    ${itens.map((x, i) => `<div class="acoes-perg" style="align-items:center"><span style="flex:1;min-width:160px">${esc(x)}</span>
      ${x.length <= 40 && !/ficha|ajust|registr|exame/i.test(x) ? `<button class="bt peq" data-nao-soube="${i}">Paciente não soube especificar</button>` : ''}<button class="bt peq fantasma" data-tirar-comp="${i}">Tirar do texto</button></div>`).join('')}
  </div>`;
}
function resolverCompletar(botao, modo) {
  salvarEdicoes();
  const id = Number(botao.closest('[data-comp]')?.dataset.comp);
  const r = revisaoPorId(id);
  if (!r) return;
  const alvo = Number(modo === 'nao-soube' ? botao.dataset.naoSoube : botao.dataset.tirarComp);
  let n = -1;
  r.texto_sugerido = r.texto_sugerido.replace(/\s?\[(?:COMPLETAR|CONFERIR CONDUTA):\s*([^\]]*)\]/gi, (m, x) => {
    n++;
    if (n !== alvo) return m;
    return modo === 'nao-soube' ? ` (paciente não soube especificar ${x.trim().replace(/^(a|o|as|os)\s+/i, '')})` : '';
  });
  redesenhar();
}

// Exame físico padrão: só entra na evolução quando o médico confirma que fez. Se a ficha já registra alguma
// alteração de exame físico, o texto entra com um [COMPLETAR] para ele ajustar antes de aprovar.
const exameIncluido = new Set();
function blocoExameFisico(r) {
  if (r.campo !== 'anamnese' || exameIncluido.has(r.id)) return '';
  const alt = r.resultado?.exame_fisico_alteracoes || [];
  return `<div class="perguntas" data-ef="${r.id}">
    <div class="perg-tit"><b>Você fez o exame físico padrão?</b><small>Ausculta, membros, punhos, ombros, coluna. Entra no texto como exame normal; depois é só editar o que estiver diferente.</small></div>
    ${alt.length ? `<div class="alerta-ef">${ic('alerta')} A ficha já registra no exame físico: ${esc(alt.join('; '))}. O texto padrão vai junto com um aviso para você ajustar.</div>` : ''}
    <details><summary>Ver o texto do exame padrão</summary><p>${esc(cfg.exameFisicoPadrao || '')}</p></details>
    <div class="acoes-perg"><button class="bt peq" data-incluir-ef="${r.id}">${ic('ok')}Sim, incluir o exame físico padrão</button></div>
  </div>`;
}
function incluirExameFisico(botao) {
  salvarEdicoes();
  const id = Number(botao.closest('[data-ef]')?.dataset.ef);
  const r = atendimentos.flatMap((a) => a.revisoes).find((x) => x.id === id);
  if (!r || !cfg.exameFisicoPadrao) return;
  const alt = r.resultado?.exame_fisico_alteracoes || [];
  const aviso = alt.length ? ` [COMPLETAR: a ficha registra ${alt.join('; ')}; ajuste o exame acima]` : '';
  // Melhor caminho: o bloco de exame que a IA já juntou com o seu exame padrão, sem repetir termos.
  const { exame_fisico_atual: atual, exame_fisico_mesclado: mesclado } = r.resultado || {};
  if (mesclado && atual && r.texto_sugerido.includes(atual.trim())) {
    r.texto_sugerido = r.texto_sugerido.replace(atual.trim(), `${mesclado}${aviso}`);
    exameIncluido.add(id);
    redesenhar();
    return avisar('Exame físico padrão juntado ao seu exame. Edite o que estiver diferente antes de aprovar.', 'ok');
  }
  if (mesclado && !atual) {
    r.texto_sugerido = inserirNoTexto(r.texto_sugerido, `${mesclado}${aviso}`);
    exameIncluido.add(id);
    redesenhar();
    return avisar('Exame físico padrão incluído no texto. Edite o que estiver diferente antes de aprovar.', 'ok');
  }
  // Sem a versão da IA: o padrão entra no bloco de exame (sem repetir o título), antes da conduta e do parecer.
  const jaTemExame = /exame f[ií]sico/i.test(r.texto_sugerido);
  const padrao = jaTemExame ? cfg.exameFisicoPadrao.replace(/^\s*exame f[ií]sico\s*:\s*/i, '') : cfg.exameFisicoPadrao;
  r.texto_sugerido = inserirNoTexto(r.texto_sugerido, `${padrao}${aviso}`);
  exameIncluido.add(id);
  redesenhar();
  avisar('Exame físico padrão incluído no texto. Edite o que estiver diferente antes de aprovar.', 'ok');
}

// guarda o texto em edição antes de redesenhar
function salvarEdicoes() {
  for (const id of editando) {
    // O mesmo texto pode estar aberto na tabela e na Fila: vale o que está com o cursor, depois o da Fila.
    const campos = [...document.querySelectorAll(`textarea[id="t${id}"]`)];
    const t = campos.find((c) => c === document.activeElement) || (filaAberta() && campos.find((c) => c.closest('#filaCaixa'))) || campos[0];
    if (!t) continue;
    for (const a of atendimentos) for (const r of a.revisoes) if (r.id === id) r.texto_sugerido = t.value;
  }
}

// realça no texto original o trecho citado pelo achado
document.addEventListener('mouseover', (ev) => {
  const ach = ev.target.closest('.achado');
  document.querySelectorAll('mark.t').forEach((m) => m.replaceWith(...m.childNodes));
  if (!ach || !ach.dataset.trecho) return;
  const painel = ach.closest('.rev')?.querySelector(`[id="orig${ach.dataset.rid}"]`);
  if (!painel) return;
  const alvo = ach.dataset.trecho.trim();
  const w = document.createTreeWalker(painel, NodeFilter.SHOW_TEXT);
  for (let n = w.nextNode(); n; n = w.nextNode()) {
    const i = n.nodeValue.toLowerCase().indexOf(alvo.toLowerCase().slice(0, 60));
    if (i < 0) continue;
    const r = document.createRange();
    r.setStart(n, i); r.setEnd(n, Math.min(n.nodeValue.length, i + alvo.length));
    const m = document.createElement('mark'); m.className = 't';
    r.surroundContents(m);
    // Rola só dentro da caixa do texto (se ela tiver rolagem); a página fica parada para você ler os achados.
    if (painel.scrollHeight > painel.clientHeight) painel.scrollTop = Math.max(0, m.offsetTop - painel.offsetTop - painel.clientHeight / 3);
    break;
  }
});

// ---------------- fila ----------------

function desenharFila() {
  const itens = pendentesDaFila();
  if (!itens.length) {
    $('filaCaixa').innerHTML = `<div class="folha-cab"><h3>Fila de aprovação</h3><span class="esp" style="flex:1"></span><button class="bt icone fantasma" data-fechar aria-label="Fechar">${ic('x')}</button></div>
      <div class="vazio">${ILUSTRA.caixa}<b>Fila vazia</b>Nenhuma revisão esperando você neste dia.</div>`;
    return;
  }
  filaIdx = Math.max(0, Math.min(filaIdx, itens.length - 1));
  const { a, r } = itens[filaIdx];
  $('filaCaixa').innerHTML = `<div class="folha-cab">
      <h3>Fila de aprovação</h3>
      <span class="posicao">${filaIdx + 1} de ${itens.length}</span>
      <span class="trilho"><i style="width:${Math.round((100 * (filaIdx + 1)) / itens.length)}%"></i></span>
      <button class="bt peq" data-ant ${filaIdx ? '' : 'disabled'}>${ic('esq')}Anterior</button>
      <button class="bt peq" data-prox ${filaIdx < itens.length - 1 ? '' : 'disabled'}>Próxima${ic('dir')}</button>
      <button class="bt icone fantasma" data-fechar aria-label="Fechar">${ic('x')}</button>
    </div>
    <div class="folha-corpo">${cartao(a, r, true)}</div>`;
}

function abrirFila() { filaIdx = 0; $('fila').style.display = 'block'; document.body.style.overflow = 'hidden'; desenharFila(); }
function fecharFila() { $('fila').style.display = 'none'; document.body.style.overflow = ''; desenhar(); }
const filaAberta = () => $('fila').style.display === 'block';
const redesenhar = () => (filaAberta() ? desenharFila() : desenhar());

$('fila').addEventListener('click', (ev) => { if (ev.target === $('fila')) { salvarEdicoes(); fecharFila(); } });

document.addEventListener('keydown', (ev) => {
  if (ev.key === 'Escape' && $('config').classList.contains('aberto')) { fecharConfig(); return; }
  if (!filaAberta() || ev.target.matches('textarea, input, select')) return;
  const clicar = (sel) => document.querySelector(`#filaCaixa ${sel}`)?.click();
  const k = ev.key.toLowerCase();
  if (['escape', 'arrowright', 'arrowleft', 'a', 'd', 'c', 'e'].includes(k)) ev.preventDefault(); // a tecla não pode cair no texto que abre em seguida
  if (k === 'escape') fecharFila();
  else if (k === 'arrowright') clicar('[data-prox]');
  else if (k === 'arrowleft') clicar('[data-ant]');
  else if (k === 'a') clicar('[data-aprovar]');
  else if (k === 'd') clicar('[data-descartar]');
  else if (k === 'c') clicar('[data-colar]');
  else if (k === 'e') clicar('[data-editar]');
});

// ---------------- ações ----------------

document.addEventListener('click', async (ev) => {
  const b = ev.target.closest('button');
  if (!b || b.dataset.abrir) return;
  try {
    if (b.dataset.filtro !== undefined) {
      const i = Number(b.dataset.filtro);
      filtroEstado = i === 0 || filtroEstado === i ? null : i;
      desenhar();
    } else if (b.dataset.editar) {
      const id = Number(b.dataset.editar);
      salvarEdicoes();
      editando.has(id) ? editando.delete(id) : editando.add(id);
      redesenhar();
      if (editando.has(id)) $('t' + id)?.focus();
    } else if (b.dataset.rev) {
      b.disabled = true; b.innerHTML = `${girando}Revisando, cerca de 30 s`;
      await api('POST', '/api/revisar', { atendimentoId: Number(b.dataset.rev), campo: b.dataset.campo });
      await carregar();
    } else if (b.dataset.aprovar) {
      salvarEdicoes();
      const id = Number(b.dataset.aprovar);
      const r = atendimentos.flatMap((a) => a.revisoes).find((x) => x.id === id);
      await api('POST', '/api/aprovar', { revisaoId: id, texto: r.texto_sugerido, ajustes: ajustesParaColar(r) });
      editando.delete(id);
      avisar('Texto aprovado. Agora é só colar no SOC.', 'ok');
      await carregar(); redesenhar();
    } else if (b.dataset.incluirConduta) {
      incluirConduta(b);
    } else if (b.dataset.naoSoube !== undefined) {
      resolverCompletar(b, 'nao-soube');
    } else if (b.dataset.tirarComp !== undefined) {
      resolverCompletar(b, 'tirar');
    } else if (b.dataset.incluirEf) {
      incluirExameFisico(b);
    } else if (b.dataset.incluirNeg) {
      incluirNegativas(b, false);
    } else if (b.dataset.todasNeg) {
      incluirNegativas(b, true);
    } else if (b.dataset.descartar) {
      await api('POST', '/api/descartar', { revisaoId: Number(b.dataset.descartar) });
      await carregar(); redesenhar();
    } else if (b.dataset.desconcluir) {
      await api('POST', '/api/concluido/desfazer', { chave: b.dataset.desconcluir });
      avisar('Voltou para a lista. Leia o dia de novo para o app conferir a ficha.', 'ok');
      await carregar(); redesenhar();
    } else if (b.dataset.colar) {
      const id = Number(b.dataset.colar);
      const acao = $(`acao${id}`)?.value || acaoSoc();
      const escolha = ACOES_SOC[acao];
      if (acao === 'copiar') {
        const rev = atendimentos.flatMap((x) => x.revisoes).find((x) => x.id === id);
        try { await navigator.clipboard.writeText(rev?.texto_aprovado || ''); avisar('Texto aprovado copiado. Cole no SOC com Ctrl+V.', 'ok'); }
        catch { avisar('Não consegui copiar sozinho. Abra "Editar texto", selecione e copie com Ctrl+C.', 'erro'); }
        return;
      }
      if (!confirm(escolha.confirmar)) return;
      b.disabled = true; b.innerHTML = `${girando}${escolha.andamento}`;
      const r = await api('POST', '/api/colar', { revisaoId: id, acao });
      avisar(r.aviso, r.ok ? 'ok' : 'erro');
      await carregar(); redesenhar(); if (acao !== 'colar') carregarPendencias();
    } else if (b.dataset.prox !== undefined) { salvarEdicoes(); filaIdx++; desenharFila(); }
    else if (b.dataset.ant !== undefined) { salvarEdicoes(); filaIdx--; desenharFila(); }
    else if (b.dataset.fechar !== undefined) { salvarEdicoes(); fecharFila(); }
  } catch (e) {
    avisar(e.message, 'erro');
    await carregar(); redesenhar();
  }
});

$('abrirFila').onclick = abrirFila;

function contador(id, n) {
  const e = $(id);
  const mudou = e.textContent !== String(n);
  e.textContent = n;
  e.classList.toggle('zero', !n);
  if (mudou && n) { e.classList.remove('pulo'); void e.offsetWidth; e.classList.add('pulo'); }
}

function mostrarAba(aba) {
  document.querySelectorAll('nav.abas [data-aba]').forEach((b) => b.classList.toggle('ativa', b.dataset.aba === aba));
  $('vInicio').hidden = aba !== 'inicio';
  $('vDia').hidden = aba !== 'dia';
  $('vPend').hidden = aba !== 'pend';
  localStorage.setItem('aba', aba);
  if (aba === 'pend') carregarPendencias();
  if (aba === 'inicio') carregarPainel();
}

// ---------------- visão geral ----------------

function contarAte(el, alvo, casas = 0) {
  const ini = performance.now(), dur = 700;
  const passo = (t) => {
    const k = Math.min(1, (t - ini) / dur), e = 1 - Math.pow(1 - k, 3);
    el.textContent = (alvo * e).toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
    if (k < 1) requestAnimationFrame(passo);
  };
  if (matchMedia('(prefers-reduced-motion: reduce)').matches && !document.documentElement.classList.contains('animar')) el.textContent = alvo.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
  else requestAnimationFrame(passo);
}

function irParaDia(dataBRx) {
  const [d, m, a] = dataBRx.split('/');
  $('data').value = `${a}-${m}-${d}`;
  $('data').onchange();
  mostrarAba('dia');
}

async function carregarPainel() {
  let p;
  try { p = await api('GET', '/api/painel'); } catch (e) { $('grade').innerHTML = `<div class="cx" style="grid-column:span 12">${vazioTxt('alerta', 'Não consegui montar a visão geral', esc(e.message))}</div>`; return; }
  const h = new Date().getHours();
  const nome = (p.medico || '').split(' ')[0];
  $('olaTitulo').textContent = `${h < 12 ? 'Bom dia' : h < 18 ? 'Boa tarde' : 'Boa noite'}, ${nome}`;
  const hojeLongo = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  $('olaSub').textContent = `${hojeLongo.charAt(0).toUpperCase() + hojeLongo.slice(1)}${p.ultimaLeitura ? ` · último dia lido: ${p.ultimaLeitura.data}${p.ultimaLeitura.local ? ` em ${p.ultimaLeitura.local}` : ''}` : ' · nenhum dia lido ainda'}`;

  const at = p.atraso, totAt = at.recentes + at.semana + at.antigas;
  const faixaAtraso = totAt ? [
    ['recentes', at.recentes, 'var(--g-neutro)', 'Até 6 dias'],
    ['semana', at.semana, 'var(--g-pend)', '7 a 14 dias'],
    ['antigas', at.antigas, 'var(--g-nao)', '15 dias ou mais'],
  ] : [];

  const maxDia = Math.max(1, ...p.dias.map((d) => d.assinada + d.pendente + d.nao_gerada));
  const colunas = p.dias.map((d, i) => {
    const tot = d.assinada + d.pendente + d.nao_gerada;
    if (!d.lido) return `<div class="dia-col vazio-dia" data-dia="${d.data}" data-dica="${d.data}: dia não lido. Clique para ler." style="--i:${i}"></div>`;
    const seg = (n, cor) => (n ? `<div class="seg" style="height:${(100 * n) / maxDia}%;background:${cor};--i:${i}"></div>` : '');
    return `<div class="dia-col" data-dia="${d.data}" data-dica="${d.data}: ${tot} atendimento(s) seus · ${d.assinada} assinada(s) · ${d.pendente} sem PDF ou assinatura · ${d.nao_gerada} não gerada(s). Clique para abrir o dia." style="--i:${i}">
      ${seg(d.nao_gerada, 'var(--g-nao)')}${seg(d.pendente, 'var(--g-pend)')}${seg(d.assinada, 'var(--g-ok)')}</div>`;
  }).join('');
  const eixo = p.dias.map((d) => `<span class="${d.data === p.hoje ? 'hoje' : ''}"><span class="sem">${d.semana}<br></span>${d.data.slice(0, 2)}</span>`).join('');

  const q = p.qualidade;
  const maxHist = Math.max(1, ...q.distribuicao);
  const maxAch = Math.max(1, ...q.achados.map((a) => a.total));

  $('grade').innerHTML = `
    <article class="cx" style="--i:0">
      <h3>Sem assinatura</h3>
      <div class="grande"><span id="nAbertos">0</span> <small>registros nos últimos 60 dias</small></div>
      ${totAt ? `<div class="faixa">${faixaAtraso.filter((f) => f[1]).map(([, n, cor, rot]) => `<i style="width:${(100 * n) / totAt}%;background:${cor}" data-dica="${rot}: ${n}"></i>`).join('')}</div>
      <div class="legenda-g">${faixaAtraso.map(([, n, cor, rot]) => `<span style="--cor:${cor}">${rot} <b>${n}</b></span>`).join('')}</div>`
      : '<p class="vazio-cx">Nada pendente nos dias já lidos.</p>'}
      <div class="rodape-cx"><button class="bt fantasma peq" data-ir="pend">Ver pendências${ic('dir')}</button></div>
    </article>
    <article class="cx" style="--i:1">
      <h3>Esperando você</h3>
      <div class="fila-linhas">
        <div><b id="nAguardando">0</b><span class="leg">revisões para aprovar</span></div>
        <div><b id="nAprovadas">0</b><span class="leg">aprovadas, falta colar no SOC</span></div>
        <div><b id="nColadas">0</b><span class="leg">coladas nos últimos 30 dias</span></div>
      </div>
      <div class="rodape-cx"><button class="bt ${p.fila.aguardando + p.fila.aprovadas ? 'prim' : ''} peq" id="painelFila">Abrir fila${ic('dir')}</button></div>
    </article>
    <article class="cx" style="--i:2">
      <h3>Qualidade dos registros revisados</h3>
      ${q.revisoes ? `<div class="grande"><span id="nNota">0</span> <small>de 10, nota média · ${q.revisoes} revisões em 30 dias</small></div>
      <div class="histo">${q.distribuicao.map((n, i) => `<i style="height:${(100 * n) / maxHist}%;--i:${i}" data-dica="Nota ${i * 2} a ${i * 2 + 1}${i === 4 ? '0' : ''}: ${n} registro(s)"></i>`).join('')}</div>
      <div class="histo-eixo"><span>0–1</span><span>2–3</span><span>4–5</span><span>6–7</span><span>8–10</span></div>`
      : '<p class="vazio-cx">Ainda não há revisões. Na aba Dia, use "Revisar todos com IA".</p>'}
    </article>
    <article class="cx larga" style="--i:3">
      <h3>Seus atendimentos nos últimos 14 dias</h3>
      <div class="dias">${colunas}</div>
      <div class="dias-eixo">${eixo}</div>
      <div class="legenda-g" style="margin-top:12px">
        <span style="--cor:var(--g-ok)">Assinada</span><span style="--cor:var(--g-pend)">Sem PDF ou assinatura</span><span style="--cor:var(--g-nao)">Não gerada</span>
        <span style="--cor:transparent;">┄ tracejado: dia não lido (clique para ler)</span>
      </div>
    </article>
    <article class="cx" style="--i:4">
      <h3>Achados mais frequentes (30 dias)</h3>
      ${q.achados.length ? `<div class="barras-h">${q.achados.map((a, i) => `<div class="barra-h"><div class="rot"><span title="${esc(a.item)}">${esc(a.item)}</span><b>${a.total}</b></div>
        <div class="trilho-h" data-dica="${esc(a.item)}: ${a.total} vez(es), ${a.altas} de gravidade alta">
          ${a.altas ? `<i style="width:${(100 * a.altas) / maxAch}%;background:var(--g-nao);--i:${i}"></i>` : ''}<i style="width:${(100 * (a.total - a.altas)) / maxAch}%;background:var(--acao);--i:${i}"></i></div></div>`).join('')}</div>
      <div class="legenda-g" style="margin-top:12px"><span style="--cor:var(--g-nao)">Gravidade alta</span><span style="--cor:var(--acao)">Média ou baixa</span></div>`
      : '<p class="vazio-cx">Aparece depois das primeiras revisões.</p>'}
    </article>`;

  contarAte($('nAbertos'), p.totalAbertos);
  contarAte($('nAguardando'), p.fila.aguardando);
  contarAte($('nAprovadas'), p.fila.aprovadas);
  contarAte($('nColadas'), p.fila.coladas30);
  if (q.revisoes) contarAte($('nNota'), q.notaMedia, 1);
  contador('contPend', p.totalAbertos);
  $('painelFila').onclick = abrirFila;
}

function vazioTxt(icone, titulo, texto) { return `<div class="vazio">${ic(icone)}<b>${titulo}</b>${texto}</div>`; }

document.addEventListener('click', (ev) => {
  const ir = ev.target.closest('[data-ir]');
  if (ir) { mostrarAba(ir.dataset.ir); return; }
  const dia = ev.target.closest('.dia-col[data-dia]');
  if (dia) irParaDia(dia.dataset.dia);
});

$('lerHoje').onclick = () => {
  irParaDia(new Date().toLocaleDateString('pt-BR'));
  $('varrer').click();
};
document.querySelectorAll('nav.abas [data-aba]').forEach((b) => (b.onclick = () => mostrarAba(b.dataset.aba)));

function tomAtraso(d) { return d >= 15 ? 'perigo' : d >= 7 ? 'atencao' : 'neutro'; }

async function carregarPendencias() {
  try {
    const r = await api('GET', `/api/pendencias?dias=${$('pendDias').value}`);
    contador('contPend', r.lista.length);
    $('pendInfo').textContent = `${r.diasLidos} dia(s) lido(s) neste período. Dias que você ainda não leu na aba Dia não aparecem aqui.`;
    pendencias = r.lista;
    desenharPendencias();
  } catch (e) { $('pendLinhas').innerHTML = vazio('alerta', 'Não consegui carregar as pendências', esc(e.message), 7); }
}

let pendencias = [];
function desenharPendencias() {
    desenharFiltros('pend', pendencias);
    const lista = aplicarFiltros('pend', pendencias);
    $('pendLinhas').innerHTML = lista.length ? lista.map((a) => `<tr class="linha">
      <td><span class="atraso ${tomAtraso(a.diasDesde)}" title="Dias desde o atendimento">${a.diasDesde} d</span></td>
      <td class="num">${esc(a.data)}<div class="sub">${esc(a.hora)} · ${esc(a.local || '')}</div></td>
      <td><div class="pac">${esc(a.paciente)}</div><div class="sub">${esc(a.empresa)}</div>${a.doMedico === 2 ? `<div class="sub alerta">${ic('alerta')}Profissional não definido</div>` : ''}</td>
      <td>${esc(a.tipo)}</td>
      <td><div class="doc">${a.documentoPrincipal}</div>${chip(a.estadoPrincipal, a.estadoPrincipalTexto)}</td>
      <td>${a.estadoAso ? `<div class="doc">ASO</div>${chip(a.estadoAso, a.estadoAsoTexto)}` : ''}</td>
      <td class="acoes-col">${a.podeAbrir ? `<button class="bt fantasma peq" data-abrir="${a.id}">${ic('abrir')}Abrir no SOC</button>` : ''}</td></tr>`).join('')
      : pendencias.length ? vazio('caixa', 'Nada neste filtro', 'Limpe os filtros para ver todas as pendências.', 7)
      : vazio('escudo', 'Tudo assinado', 'Nenhuma pendência nos dias já lidos deste período.', 7);
}
$('pendDias').onchange = carregarPendencias;

document.addEventListener('click', async (ev) => {
  const b = ev.target.closest('[data-abrir]');
  if (!b) return;
  const antes = b.innerHTML;
  b.disabled = true; b.innerHTML = `${girando}Abrindo…`;
  try { await api('POST', '/api/abrir', { atendimentoId: Number(b.dataset.abrir) }); b.innerHTML = `${ic('ok')}Aberta no Edge`; }
  catch (e) { avisar(e.message, 'erro'); b.innerHTML = antes; }
  setTimeout(() => { b.disabled = false; b.innerHTML = antes; }, 4000);
});

// ---------------- revisores de IA ----------------
// Só o Claude Code (no computador, com a ponte) revisa sozinho. Os outros são copiar e colar: o pedido já sai sem nome,
// CPF e contatos; a pessoa cola numa conversa nova da IA que tem e cola a resposta de volta.
const PRIVACIDADE = 'Antes de colar dados de pacientes, mesmo sem nome e CPF, desligue o uso das suas conversas para treinar a IA';
const REVISORES = {
  'claude-code': { nome: 'Claude Code', curto: 'Claude Code', manual: false, tag: ['auto', 'Automático'], custo: 'Assinatura Claude Pro ou Max',
    resumo: 'Revisa sozinho, vários de uma vez. Precisa do Claude Code neste computador e da ponte do revisa.' },
  chatgpt: { nome: 'ChatGPT', curto: 'ChatGPT', manual: true, url: 'https://chatgpt.com/', tag: ['gratis', 'Grátis'], custo: 'Grátis, ou Plus',
    resumo: 'Copiar e colar no chatgpt.com. O plano grátis tem limite de mensagens por dia.',
    privacidade: 'No ChatGPT: foto de perfil › Configurações › Controles de dados › desligue "Melhorar o modelo para todos".' },
  gemini: { nome: 'Gemini', curto: 'Gemini', manual: true, url: 'https://gemini.google.com/app', tag: ['gratis', 'Grátis'], custo: 'Grátis com conta Google',
    resumo: 'Copiar e colar no gemini.google.com, com a sua conta Google.',
    privacidade: 'No Gemini: menu › Atividade › desative a "Atividade nos apps do Gemini" (ou em myactivity.google.com/product/gemini).' },
  claude: { nome: 'Claude (site)', curto: 'Claude', manual: true, url: 'https://claude.ai/new', tag: ['gratis', 'Grátis'], custo: 'Grátis, ou Pro',
    resumo: 'Copiar e colar no claude.ai. Bom para textos longos; o grátis tem limite por dia.',
    privacidade: 'No Claude: Configurações › Privacidade › desligue "Ajudar a melhorar o Claude".' },
  copilot: { nome: 'Microsoft Copilot', curto: 'Copilot', manual: true, url: 'https://copilot.microsoft.com/', tag: ['gratis', 'Grátis'], custo: 'Grátis com conta Microsoft',
    resumo: 'Copiar e colar no copilot.microsoft.com, já aberto no Edge.',
    privacidade: 'No Copilot: foto de perfil › Configurações › Privacidade › desligue o treinamento do modelo com o seu texto.' },
  outra: { nome: 'Outra IA', curto: 'sua IA', manual: true, url: '', tag: ['', 'Copiar e colar'], custo: 'A que você já usa',
    resumo: 'Qualquer chat de IA que aceite um texto longo e devolva o bloco de resposta pedido.',
    privacidade: 'Procure nas configurações de privacidade da sua IA a opção de não usar as conversas para treinar o modelo.' },
};
// Na extensão, o instalador "Ligar ao Claude" vai junto; no app local o servidor já roda o Claude Code direto.
const NA_EXTENSAO = document.documentElement.dataset.extensao === '1';
const BOTAO_LIGAR = '<a class="bt prim" href="Ligar%20ao%20Claude.cmd" download="Ligar ao Claude.cmd" style="margin-top:8px"><svg class="ic"><use href="#i-revisar"/></svg>Baixar "Ligar ao Claude"</a>';
const revisorAtual = () => (REVISORES[cfg.revisor] ? cfg.revisor : cfg.modoIA === 'manual' ? 'claude' : 'claude-code');

// Passo a passo de cada revisor (usado no tour e nas configurações).
function comoConfigurar(chave) {
  const r = REVISORES[chave];
  if (!r.manual) {
    return `<div class="rev-como"><span class="estado-ponte" id="estadoPonte">${girando}Procurando o Claude Code neste computador…</span>
      <ol><li>Tenha uma assinatura <b>Claude Pro ou Max</b> e o <a href="https://claude.com/claude-code" target="_blank" rel="noopener">Claude Code</a> instalado e com login feito neste computador.</li>
      ${NA_EXTENSAO ? `<li>Baixe o arquivo abaixo e dê <b>dois cliques</b> nele, uma vez só. Ele liga o revisa. ao seu Claude Code e avisa quando terminar. Se o Windows perguntar, clique em <b>Mais informações</b> e depois em <b>Executar assim mesmo</b>.<br>${BOTAO_LIGAR}</li>` : ''}
      <li>Na aba Dia, use <b>Revisar todos com IA</b>: as revisões caem sozinhas na Fila.</li></ol></div>`;
  }
  return `<div class="rev-como"><ol>
    <li>${r.url ? `Entre no <a href="${r.url}" target="_blank" rel="noopener">${esc(r.curto)}</a> com a sua conta (crie uma grátis, se não tiver).` : 'Abra a IA que você usa, com a sua conta.'}</li>
    <li><b>${PRIVACIDADE}.</b> ${esc(r.privacidade)} O nome do menu pode variar um pouco.</li>
    <li>Na aba Dia, clique em <b>Revisar pelo ${esc(r.curto)}</b> e em <b>Copiar pedido</b>. O pedido já sai sem nome, CPF e contatos.</li>
    <li>Cole numa conversa nova, espere a resposta terminar, copie a resposta inteira e cole de volta no revisa. As revisões vão para a Fila.</li>
  </ol></div>`;
}
async function verificarPonte() {
  const el = $('estadoPonte');
  if (!el) return;
  let ok = false;
  try { ok = (await api('GET', '/api/ia/ponte')).ok; } catch {}
  if (!$('estadoPonte')) return;
  el.className = `estado-ponte ${ok ? 'ok' : 'falta'}`;
  el.innerHTML = ok ? `${ic('ok')}Claude Code encontrado: a revisão automática está pronta.` : `${ic('alerta')}O Claude Code ainda não responde por aqui. Siga os passos abaixo ou escolha um revisor de copiar e colar.`;
}

// ---------------- tour da primeira abertura ----------------
const PASSOS_TOUR = [
  { corpo: () => `<div class="tour-marca">revisa<i>.</i></div>
      <h3 id="tourTitulo">O seu auditor do SOC, em quatro abas.</h3>
      <p>O revisa. lê a sua agenda no SOC, mostra a ficha que não foi gerada e o PDF que ficou sem assinatura, e revisa as anamneses com IA. Você aprova cada texto e escolhe se o app só cola ou também salva, gera o PDF e assina, um a um ou em lote.</p>
      <ul><li>Só escreve no SOC quando você clica: nada é gravado sozinho.</li><li>Nome, CPF e contatos saem do texto antes de ir para a IA.</li><li>Tudo o que é lido fica neste navegador.</li></ul>` },
  { alvo: '[data-aba="inicio"]', aba: 'inicio', titulo: 'Visão geral',
    texto: 'O resumo dos últimos dias: quantas fichas faltam gerar ou assinar, o que está atrasado e qual foi o último dia lido.' },
  { alvo: '[data-aba="dia"]', aba: 'dia', titulo: 'Dia',
    texto: 'Escolha o dia e o local. A tabela mostra cada atendimento seu com o estado da ficha ou licença e do ASO. Os filtros separam por estado, tipo, local e empresa.' },
  { alvo: '#varrer', aba: 'dia', titulo: 'Ler o dia no SOC',
    texto: 'Um clique e o revisa. abre a agenda e cada ficha no SOC. Enquanto lê, a aba do SOC fica coberta por uma tela de espera; ela libera sozinha. A lixeira, no canto direito da barra, apaga o que foi lido, para ler de novo.' },
  { alvo: '[data-aba="pend"]', aba: 'pend', titulo: 'Pendências',
    texto: 'Tudo o que ainda falta gerar ou assinar nos dias lidos, do mais atrasado ao mais recente. "Abrir no SOC" abre a ficha para você gerar o PDF ou assinar.' },
  { alvo: '#abrirFila', titulo: 'Fila',
    texto: 'Cada revisão da IA espera o seu OK aqui, uma por vez, com o antes e o depois lado a lado. Aprovado, o revisa. cola o texto na ficha em modo Alterar; quem confere e salva é você.' },
  { alvo: '#status', titulo: 'Conexão com o SOC',
    texto: 'Mostra se o SOC está aberto e logado, e em nome de quem. O revisa. descobre sozinho quem você é pelo login: não precisa digitar o seu nome.' },
  { revisor: true, largo: true },
  { corpo: () => `<h3 id="tourTitulo">Tudo pronto.</h3>
      <p>Abra o SOC numa aba do Edge, faça login e venha para a aba <b>Dia</b>: escolha o dia e clique em <b>Ler o dia no SOC</b>.</p>
      <p>Para rever este tour ou trocar de revisor, use a engrenagem no canto de cima.</p>`, fim: 'Ir para o Dia' },
];
let tourPasso = 0;
let tourEscolha = '';

function corpoRevisor() {
  const ops = Object.entries(REVISORES).map(([k, r]) => `<button type="button" class="rev-op" data-rev-op="${k}" aria-pressed="${tourEscolha === k}">
      <span class="rev-tag ${r.tag[0]}">${r.tag[1]}</span><b>${esc(r.nome)}</b><small>${esc(r.custo)}</small></button>`).join('');
  const r = REVISORES[tourEscolha];
  return `<h3 id="tourTitulo">Qual IA vai revisar os seus textos?</h3>
    <p>Escolha a que você já tem. Só o Claude Code revisa sozinho; as outras funcionam copiando e colando, e várias são grátis. Dá para trocar depois nas configurações.</p>
    <div class="rev-ops" role="group" aria-label="Revisores">${ops}</div>
    ${r ? `<p style="color:var(--tinta)"><b>${esc(r.nome)}.</b> ${esc(r.resumo)}</p>${comoConfigurar(tourEscolha)}` : ''}`;
}

function desenharTour() {
  const passo = PASSOS_TOUR[tourPasso];
  if (passo.aba) mostrarAba(passo.aba);
  const corpo = passo.revisor ? corpoRevisor() : passo.corpo ? passo.corpo() : `<h3 id="tourTitulo">${passo.titulo}</h3><p>${passo.texto}</p>`;
  $('tourCorpo').innerHTML = corpo;
  $('tourPasso').textContent = `${tourPasso + 1} de ${PASSOS_TOUR.length}`;
  $('tourPontos').innerHTML = PASSOS_TOUR.map((_p, i) => `<i class="${i === tourPasso ? 'ativo' : ''}"></i>`).join('');
  $('tourVoltar').hidden = tourPasso === 0;
  $('tourAvancar').textContent = passo.fim || (passo.revisor ? (tourEscolha ? `Usar ${REVISORES[tourEscolha].curto === 'sua IA' ? 'outra IA' : REVISORES[tourEscolha].curto}` : 'Escolher depois') : tourPasso === 0 ? 'Começar' : 'Próximo');
  $('tourCartao').classList.toggle('largo', !!passo.largo);
  if (passo.revisor && tourEscolha === 'claude-code') verificarPonte();
  posicionarTour();
}

function posicionarTour() {
  if ($('tour').hidden) return;
  const passo = PASSOS_TOUR[tourPasso];
  const alvo = passo.alvo && document.querySelector(passo.alvo);
  const luz = $('tourLuz');
  const cartao = $('tourCartao');
  const r = alvo?.getBoundingClientRect();
  const visivel = r && r.width > 0 && r.height > 0;
  luz.hidden = !visivel;
  const furo = $('tourFuroR');
  const caixa = visivel ? [r.left - 6, r.top - 6, r.width + 12, r.height + 12] : [innerWidth / 2, innerHeight / 2, 0, 0];
  ['x', 'y', 'width', 'height'].forEach((k, i) => furo.setAttribute(k, caixa[i]));
  const cw = cartao.offsetWidth;
  const ch = cartao.offsetHeight;
  if (!visivel) {
    cartao.style.left = `${Math.max(16, (innerWidth - cw) / 2)}px`;
    cartao.style.top = `${Math.max(16, (innerHeight - ch) / 2)}px`;
    return;
  }
  Object.assign(luz.style, { left: `${r.left - 6}px`, top: `${r.top - 6}px`, width: `${r.width + 12}px`, height: `${r.height + 12}px` });
  const embaixo = innerHeight - r.bottom > ch + 28;
  cartao.style.top = `${embaixo ? r.bottom + 16 : Math.max(16, r.top - ch - 16)}px`;
  cartao.style.left = `${Math.min(Math.max(16, r.left), innerWidth - cw - 16)}px`;
}

function abrirTour(passo = 0) {
  tourPasso = passo;
  tourEscolha = cfg.revisor && REVISORES[cfg.revisor] ? cfg.revisor : '';
  $('tour').hidden = false;
  desenharTour();
  $('tourAvancar').focus();
}

async function fecharTour() {
  $('tour').hidden = true;
  try { localStorage.setItem('tourVisto', '1'); } catch {}
  if (!cfg.tourVisto) { try { cfg = await api('POST', '/api/config', { tourVisto: true }); } catch {} }
}

function talvezTour() {
  let visto = false;
  try { visto = localStorage.getItem('tourVisto') === '1'; } catch {}
  if (!cfg.tourVisto && !visto) abrirTour(0);
}

$('tourAvancar').onclick = async () => {
  const passo = PASSOS_TOUR[tourPasso];
  if (passo.revisor && tourEscolha && tourEscolha !== cfg.revisor) {
    try { cfg = await api('POST', '/api/config', { revisor: tourEscolha }); aplicarModoIA(); avisar(`Revisor: ${REVISORES[tourEscolha].nome}.`, 'ok'); }
    catch (e) { return avisar(e.message, 'erro'); }
  }
  if (passo.fim || tourPasso === PASSOS_TOUR.length - 1) { await fecharTour(); mostrarAba('dia'); return; }
  tourPasso++;
  desenharTour();
};
$('tourVoltar').onclick = () => { if (tourPasso > 0) { tourPasso--; desenharTour(); } };
$('tourPular').onclick = fecharTour;
$('tourCorpo').addEventListener('click', (ev) => {
  const b = ev.target.closest('[data-rev-op]');
  if (!b) return;
  tourEscolha = b.dataset.revOp;
  desenharTour();
});
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !$('tour').hidden) fecharTour(); });
addEventListener('resize', posicionarTour);

// ---------------- configurações ----------------

let cfg = { revisoesSimultaneas: 2 };
async function carregarConfig() { try { cfg = await api('GET', '/api/config'); } catch {} aplicarModoIA(); }
function aplicarModoIA() {
  const manual = cfg.modoIA === 'manual';
  document.body.classList.toggle('modo-manual', manual);
  $('revisarTodos').hidden = manual;
  // Copiar e colar: botão, gaveta e link seguem a IA que a pessoa escolheu.
  const r = REVISORES[revisorAtual()];
  const ia = r.manual ? r : REVISORES.claude;
  $('abrirManual').lastChild.textContent = `Revisar pelo ${ia.curto}`;
  $('abrirManual').title = `Copiar os textos do dia, revisar numa conversa do ${ia.curto} e colar a resposta aqui`;
  $('manTitulo').textContent = `Revisar pelo ${ia.curto}`;
  $('manColeEm').textContent = ia.url ? `Cole numa conversa nova do ${ia.curto}` : 'Cole numa conversa nova da sua IA';
  $('manAbrirIA').hidden = !ia.url;
  if (ia.url) { $('manAbrirIA').href = ia.url; $('manAbrirIA').querySelector('span').textContent = `Abrir o ${ia.curto}`; }
}
function fecharConfig() { $('config').classList.remove('aberto'); }
function ajudaRevisor() {
  const r = REVISORES[$('cfgRevisor').value];
  $('cfgRevisorAjuda').textContent = r ? `${r.resumo} ${r.custo}.` : '';
  $('cfgModeloCampo').hidden = !!r?.manual;
  $('cfgLigar').innerHTML = NA_EXTENSAO && r && !r.manual ? BOTAO_LIGAR.replace(' style="margin-top:8px"', '').replace('bt prim', 'bt') : '';
}
$('cfgRevisor').onchange = ajudaRevisor;
$('cfgComoConfigurar').onclick = () => {
  fecharConfig();
  abrirTour(PASSOS_TOUR.findIndex((p) => p.revisor));
  tourEscolha = $('cfgRevisor').value;
  desenharTour();
};
$('cfgTour').onclick = () => { fecharConfig(); abrirTour(0); };
$('abrirConfig').onclick = async () => {
  await carregarConfig();
  // Em branco = nome de quem está logado no SOC (aparece como sugestão).
  $('cfgMedico').value = cfg.medicoManual ? cfg.medico || '' : '';
  $('cfgMedico').placeholder = cfg.medicoDoSoc || 'Abra o SOC para o revisa. descobrir';
  $('cfgMedicoAjuda').textContent = cfg.medicoDoSoc
    ? `Descoberto no SOC: ${cfg.medicoDoSoc}. Deixe em branco para usar este nome; só escreva se a agenda usar outro.`
    : 'O revisa. descobre sozinho quem está logado no SOC. Só escreva aqui se a agenda usar um nome diferente do seu login.';
  $('cfgModelo').value = cfg.modeloClaudeCode || 'sonnet';
  $('cfgRevisor').innerHTML = Object.entries(REVISORES).map(([k, r]) => `<option value="${k}">${esc(r.nome)}: ${r.manual ? 'copiar e colar' : 'automático'}</option>`).join('');
  $('cfgRevisor').value = revisorAtual();
  ajudaRevisor();
  $('cfgParalelo').value = String(cfg.revisoesSimultaneas || 2);
  $('cfgAlerta').value = cfg.diasAlertaSemAssinatura || 7;
  $('cfgExame').value = cfg.exameFisicoPadrao || '';
  $('config').classList.add('aberto');
};
$('cfgFechar').onclick = fecharConfig;
$('cfgCancelar').onclick = fecharConfig;
$('config').addEventListener('click', (ev) => { if (ev.target === $('config')) fecharConfig(); });
$('cfgSalvar').onclick = async () => {
  try {
    cfg = await api('POST', '/api/config', { medico: $('cfgMedico').value, modeloClaudeCode: $('cfgModelo').value, revisor: $('cfgRevisor').value,
      revisoesSimultaneas: Number($('cfgParalelo').value), diasAlertaSemAssinatura: Number($('cfgAlerta').value), exameFisicoPadrao: $('cfgExame').value });
    fecharConfig();
    aplicarModoIA();
    avisar('Configurações salvas.', 'ok');
    atualizarEstado();
  } catch (e) { avisar(e.message, 'erro'); }
};

// ---------------- modo manual (claude.ai) ----------------

$('abrirManual').onclick = () => { $('manual').classList.add('aberto'); $('manCopiar').focus(); };
$('manFechar').onclick = () => $('manual').classList.remove('aberto');
$('manual').addEventListener('click', (ev) => { if (ev.target === $('manual')) $('manual').classList.remove('aberto'); });
$('manCopiar').onclick = async () => {
  const d = dataBR();
  if (!d) return avisar('Escolha o dia primeiro.', 'erro');
  try {
    const r = await api('POST', '/api/manual/pedido', { data: d });
    try { await navigator.clipboard.writeText(r.texto); }
    catch { $('manResposta').value = r.texto; $('manResposta').select(); avisar('Não consegui copiar sozinho: o pedido está selecionado na caixa do passo 3. Copie com Ctrl+C e depois apague.', 'info'); return; }
    $('manInfo').textContent = `Pedido com ${r.quantidade} campo(s) copiado. Agora cole no claude.ai.`;
    avisar(`Pedido com ${r.quantidade} campo(s) copiado.`, 'ok');
  } catch (e) { avisar(e.message, 'erro'); }
};
$('manLer').onclick = async () => {
  try {
    const r = await api('POST', '/api/manual/resposta', { texto: $('manResposta').value });
    $('manResposta').value = '';
    $('manual').classList.remove('aberto');
    avisar(`${r.feitas} revisão(ões) prontas na Fila${r.ignoradas.length ? `; ${r.ignoradas.length} item(ns) não reconhecido(s)` : ''}.`, 'ok');
    await carregar();
    abrirFila();
  } catch (e) { avisar(e.message, 'erro'); }
};

// ---------------- leitura e revisão em lote ----------------

// A lista de agendas do SOC (a mesma do botão "Trocar agenda") vem sozinha: na primeira vez e depois uma vez por dia,
// quando o SOC está logado e nada está sendo lido. Sem aviso quando dá certo.
let buscandoAgendas = false;
async function trazerAgendasSozinho(e) {
  if (buscandoAgendas || !e?.soc?.logado || e.progresso?.rodando || document.documentElement.dataset.ficticio === '1') return;
  let ultima = 0;
  try { ultima = Number(localStorage.getItem('agendasEm') || 0); } catch {}
  if (Date.now() - ultima < 86400000 && e.agendas.length > 1) return;
  buscandoAgendas = true;
  try { localStorage.setItem('agendasEm', String(Date.now())); } catch {} // uma tentativa por dia, mesmo se falhar
  try {
    await api('POST', '/api/agendas/buscar');
    await atualizarEstado();
  } catch (err) { console.warn('[revisa.] lista de agendas:', err.message); } finally { buscandoAgendas = false; }
}

// Ao trocar o dia: se o dia já foi lido, o seletor mostra a agenda em que você atendeu; senão, volta para a busca nas suas agendas.
// Padrão: a agenda que está aberta no SOC. Dia já lido: a agenda em que você atendeu. O que você escolher à mão vale.
let agendaAbertaSoc = null;
try { agendaAbertaSoc = localStorage.getItem('agendaSoc'); } catch {}
let agendaEscolhidaAMao = false;
function ajustarAgendaDoDia() {
  if (agendaEscolhidaAMao) return;
  const codigos = [...new Set(atendimentos.filter((a) => a.doMedico === 1 && a.agendaCodigo).map((a) => a.agendaCodigo))];
  const temOpcao = (v) => [...$('agenda').options].some((o) => o.value === v);
  const quer = codigos.length === 1 ? codigos[0] : agendaAbertaSoc && temOpcao(agendaAbertaSoc) ? agendaAbertaSoc : '@minhas';
  const sel = $('agenda');
  if ([...sel.options].some((o) => o.value === quer)) sel.value = quer;
  localStorage.setItem('agenda', sel.value);
}

$('varrer').onclick = async () => {
  const d = dataBR();
  if (!d) return avisar('Escolha o dia primeiro.', 'erro');
  localStorage.setItem('agenda', $('agenda').value);
  try {
    await api('POST', '/api/varrer', { data: d, agendaCodigo: $('agenda').value });
    const timer = setInterval(async () => {
      const p = await atualizarEstado();
      await carregar();
      if (p && !p.rodando) { clearInterval(timer); ajustarAgendaDoDia(); }
    }, 2000);
  } catch (e) { avisar(e.message, 'erro'); }
};

// Alternativa (03/11): lê a agenda que está aberta no SOC (dia e local escolhidos lá, à mão) e mostra esse dia aqui.
$('varrerAberta').onclick = async () => {
  try {
    await api('POST', '/api/varrer', { data: dataBR() || '', aberta: true });
    const timer = setInterval(async () => {
      const p = await atualizarEstado();
      if (p?.data) {
        const [d, m, a] = p.data.split('/');
        const iso = `${a}-${m}-${d}`;
        if ($('data').value !== iso) { $('data').value = iso; localStorage.setItem('data', iso); }
      }
      await carregar();
      if (p && !p.rodando) { clearInterval(timer); ajustarAgendaDoDia(); }
    }, 2000);
  } catch (e) { avisar(e.message, 'erro'); }
};

$('revisarTodos').onclick = async () => {
  const alvos = atendimentos.filter((a) => a.doMedico).flatMap((a) => a.campos.filter((c) => c.texto && !a.revisoes.some((r) => r.campo === c.campo && r.status !== 'descartada')).map((c) => ({ a, c })));
  if (!alvos.length) return avisar('Nada novo para revisar neste dia.', 'info');
  const n = cfg.revisoesSimultaneas || 2;
  const min = Math.ceil((alvos.length * 30) / n / 60);
  if (!confirm(`Mandar ${alvos.length} campo(s) para a IA, já anonimizados? ${n} de cada vez, uns ${min} min no total. Você pode ir aprovando na Fila enquanto isso.`)) return;
  let feito = 0, erros = 0;
  const fila = [...alvos];
  $('barraProg').hidden = false;
  $('revisarTodos').disabled = true;
  const trabalhador = async () => {
    while (fila.length) {
      const { a, c } = fila.shift();
      try { await api('POST', '/api/revisar', { atendimentoId: a.id, campo: c.campo }); } catch (e) { erros++; console.warn(e); }
      feito++;
      $('prog').textContent = `Revisando: ${feito} de ${alvos.length} prontos${erros ? ` (${erros} com erro)` : ''}`;
      $('barraProgI').style.width = `${Math.round((100 * feito) / alvos.length)}%`;
      await carregar();
      if (filaAberta()) desenharFila();
    }
  };
  await Promise.all(Array.from({ length: Math.min(n, alvos.length) }, trabalhador));
  $('barraProg').hidden = true;
  $('revisarTodos').disabled = false;
  $('prog').textContent = `Revisão concluída: ${alvos.length - erros} campo(s)${erros ? `, ${erros} com erro (tente de novo no botão do paciente)` : ''}.`;
  if (!filaAberta()) abrirFila();
};

// ---- lixeira: dois cliques no mesmo botão (o primeiro arma, o segundo apaga) ----
const textosLimpar = { dia: () => `Apagar ${dataBR() || 'este dia'} (${atendimentos.length})`, tudo: () => 'Apagar todos os dias lidos' };
function fecharLixeira() {
  $('popLixeira').hidden = true;
  $('abrirLixeira').setAttribute('aria-expanded', 'false');
  document.querySelectorAll('[data-limpar]').forEach((b) => { b.classList.remove('armado'); b.querySelector('span').textContent = textosLimpar[b.dataset.limpar](); });
}
$('abrirLixeira').onclick = (ev) => {
  ev.stopPropagation();
  const abrir = $('popLixeira').hidden;
  fecharLixeira();
  if (abrir) {
    // Abre para o lado que cabe na tela.
    const pop = $('popLixeira');
    const r = $('abrirLixeira').getBoundingClientRect();
    const cabeDireita = r.left + Math.min(300, innerWidth - 32) <= innerWidth - 16;
    pop.style.left = cabeDireita ? '0' : 'auto';
    pop.style.right = cabeDireita ? 'auto' : '0';
    pop.hidden = false;
    $('abrirLixeira').setAttribute('aria-expanded', 'true');
  }
};
document.addEventListener('click', (ev) => { if (!ev.target.closest('#lixeira')) fecharLixeira(); });
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape' && !$('popLixeira').hidden) fecharLixeira(); });
document.querySelectorAll('[data-limpar]').forEach((b) => b.addEventListener('click', async () => {
  const tudo = b.dataset.limpar === 'tudo';
  if (!tudo && !dataBR()) return avisar('Escolha o dia primeiro.', 'erro');
  if (!b.classList.contains('armado')) {
    document.querySelectorAll('[data-limpar].armado').forEach((x) => { x.classList.remove('armado'); x.querySelector('span').textContent = textosLimpar[x.dataset.limpar](); });
    b.classList.add('armado');
    b.querySelector('span').textContent = tudo ? 'Clique de novo para apagar tudo' : 'Clique de novo para apagar o dia';
    return;
  }
  b.disabled = true;
  try {
    const r = await api('POST', '/api/limpar', tudo ? { tudo: true } : { data: dataBR() });
    fecharLixeira();
    vistos.clear(); estadosAntes.clear(); contagensAntes.clear(); filtroEstado = null;
    await atualizarEstado();
    await carregar();
    await carregarPendencias();
    avisar(r.apagados ? `${r.apagados} atendimento(s) apagado(s). Pode ler de novo.` : 'Não havia nada lido para apagar.', 'ok');
  } catch (e) { avisar(e.message, 'erro'); } finally { b.disabled = false; }
}));

const LOTES = {
  gerar: {
    titulo: (n) => `Gerar fichas clínicas em lote: ${n} paciente(s)`,
    explica: 'Fichas já gravadas que ainda não têm PDF. O app gera o PDF de cada uma no SOCGED (Imprimir Ficha Clínica > Avançar > Gerar PDF no SOCGED), um paciente por vez, e NÃO assina. Licença: o app pede o PDF ao SOC, que leva de 5 a 30 minutos para chegar. Nada de IA e nada de texto mexido.',
    vazio: 'Nenhuma ficha sua sem PDF neste dia (com os filtros de cima).',
    rodar: 'Gerar os PDFs',
    confirma: (n) => `Gerar o PDF de ${n} ficha(s)? Não assina nada. O SOC fica ocupado até terminar.`,
    corpo: { pdf: true, assinar: false, aso: false },
  },
  assinar: {
    titulo: (n) => `Assinar fichas clínicas em lote: ${n} paciente(s)`,
    explica: 'Fichas e licenças que já têm PDF sem assinatura. O app abre a pastinha SOCGED de cada uma e clica em "Assinar arquivo digitalmente" com o seu certificado, um paciente por vez. Não gera PDF novo e não mexe no texto.',
    vazio: 'Nenhum PDF seu sem assinatura neste dia. Gere os PDFs primeiro.',
    rodar: 'Assinar com o meu certificado',
    confirma: (n) => `ASSINAR ${n} PDF(s) com o seu certificado no SOC? O SOC fica ocupado até terminar.`,
    corpo: { pdf: false, assinar: true, aso: false },
  },
  aso: {
    titulo: (n) => `ASO em lote: ${n} paciente(s) com ASO pendente`,
    explica: 'Só para quem a ficha já diz Apto: grava "Apto para função", gera e assina o ASO. Inapto, restrição ou sem parecer ficam para você. Não mexe na ficha clínica.',
    vazio: 'Nenhum ASO pendente seu neste dia.',
    rodar: 'Gravar, gerar e assinar os ASOs',
    confirma: (n) => `Gravar "Apto para função", gerar e ASSINAR o ASO dos Aptos entre ${n} paciente(s)? O SOC fica ocupado até terminar.`,
    corpo: { pdf: false, assinar: false, aso: true, assinarAso: true },
  },
};

function mostrarLote(qual) {
  const l = LOTES[qual], lista = listasDoLote[qual];
  loteAberto = qual;
  $('loteTitulo').textContent = l.titulo(lista.length);
  $('loteExplica').textContent = lista.length ? l.explica : l.vazio;
  $('loteLista').innerHTML = lista.map((a) => `<li>${esc(a.hora)} · ${esc(a.paciente)} <span class="sub">· ${esc(a.tipo || a.tipoTexto || '')}</span></li>`).join('');
  $('loteRodar').textContent = l.rodar;
  $('loteRodar').disabled = !lista.length;
  $('loteCaixa').hidden = false;
}
for (const [id, qual] of [['loteGerarAbrir', 'gerar'], ['loteAssinarAbrir', 'assinar'], ['loteAsoAbrir', 'aso']]) {
  $(id).onclick = () => { if (loteAberto === qual && !$('loteCaixa').hidden) { $('loteCaixa').hidden = true; loteAberto = null; } else mostrarLote(qual); };
}
$('loteFechar').onclick = () => { $('loteCaixa').hidden = true; loteAberto = null; };
$('loteRodar').onclick = async () => {
  const qual = loteAberto, l = LOTES[qual], lista = listasDoLote[qual] || [];
  if (!qual || !lista.length) return;
  if (!confirm(l.confirma(lista.length))) return;
  try {
    const r = await api('POST', '/api/lote', { ids: lista.map((a) => a.id), ...l.corpo });
    $('loteCaixa').hidden = true; loteAberto = null;
    avisar(`Lote iniciado: ${r.total} atendimento(s). Acompanhe pela barra.`, 'ok');
    const sondar = setInterval(async () => {
      const p = await atualizarEstado();
      if (p && !p.rodando) { clearInterval(sondar); await carregar(); redesenhar(); carregarPendencias(); if (p.resumo) avisar(`Lote: ${p.resumo}`, p.erro ? 'erro' : 'ok'); }
    }, 2000);
  } catch (e) { avisar(e.message, 'erro'); }
};
$('data').onchange = () => { agendaEscolhidaAMao = false; filtroEstado = null; vistos.clear(); estadosAntes.clear(); contagensAntes.clear(); localStorage.setItem('data', $('data').value); carregar().then(ajustarAgendaDoDia); };
$('agenda').onchange = () => { agendaEscolhidaAMao = true; localStorage.setItem('agenda', $('agenda').value); };
// Rodapé: troca entre os dados reais e os fictícios (para mostrar o app sem expor nenhum paciente).
const ficticio = document.documentElement.dataset.ficticio === '1';
$('rodapeModo').textContent = ficticio ? 'dados fictícios, nada aqui vem do SOC' : 'dados do SOC neste computador';
$('trocarDados').textContent = ficticio ? 'voltar aos dados reais' : 'ver com dados fictícios';
$('trocarDados').hidden = document.documentElement.dataset.demo === '1';
$('trocarDados').onclick = () => {
  try { localStorage.setItem('dadosFicticios', ficticio ? '0' : '1'); } catch {}
  location.reload();
};

$('data').value = localStorage.getItem('data') || new Date().toLocaleDateString('sv-SE');
carregarConfig().then(talvezTour);
mostrarAba(localStorage.getItem('aba') || 'inicio');
atualizarEstado().then(carregar).then(ajustarAgendaDoDia).then(carregarPendencias);
setInterval(atualizarEstado, 15000);
