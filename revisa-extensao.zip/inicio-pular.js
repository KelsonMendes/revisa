// Quem marcou "abrir direto no painel" pula a apresentação (a menos que tenha vindo pelo link "Sobre").
  try { if (localStorage.getItem('pularInicio') === '1' && !location.search.includes('ver')) location.replace(document.documentElement.dataset.painel || '/painel'); } catch {}
