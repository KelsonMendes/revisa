// Camada (véu) sobre a janela do SOC enquanto o app trabalha nela: bloqueia cliques e teclas do usuário,
// mostra o que está sendo feito (etapas, progresso, tempo) e se desfaz sozinha se o app parar de dar sinal.
// Fica no documento principal do SOC, dentro de um Shadow DOM (o CSS do SOC não alcança o véu).
// Se o SOC recarregar a janela inteira (troca de empresa ao abrir uma ficha, por exemplo), o véu some junto;
// por isso, enquanto ele estiver ligado, o app reenvia o último estado a cada segundo e meio.
import { rodar } from './cdp.js';

const pagina = {
  // etapas: rótulos das fases (ex.: ['Assinaturas', 'Agenda', 'Fichas']); etapa: índice da fase atual.
  // inicio e ritmo vêm do app, para o relógio e a estimativa sobreviverem a uma recarga do SOC.
  mostrar: function ({ titulo, detalhe, feito, total, etapas, etapa, inicio, ritmo }) {
    const ID = 'auditor-veu';
    let host = document.getElementById(ID);
    if (!host) {
      // Elemento próprio (não um div) e estilo inline com !important: nenhuma regra do SOC pega no hospedeiro.
      host = document.createElement('revisa-veu');
      host.id = ID;
      host.setAttribute('style', 'all:initial!important;position:fixed!important;inset:0!important;z-index:2147483647!important;display:block!important;background:transparent!important;opacity:1!important;visibility:visible!important;transform:none!important;filter:none!important');
      const raiz = host.attachShadow({ mode: 'open' });
      raiz.innerHTML = `<style>
        :host{all:initial}
        *{box-sizing:border-box;margin:0;padding:0;font:inherit;color:inherit;letter-spacing:normal;text-transform:none;text-decoration:none;background:none;border:0;float:none;position:static}
        .v{position:fixed;inset:0;display:grid;place-items:center;padding:16px;
          background:radial-gradient(120% 90% at 50% 40%,rgb(11 13 18 / .42),rgb(11 13 18 / .62));backdrop-filter:blur(4px) saturate(.7);
          font:14px/1.5 "Hanken Grotesk","Segoe UI Variable Text","Segoe UI",system-ui,sans-serif;color:#0b0d12;
          cursor:progress;transition:opacity .35s;animation:entra .25s cubic-bezier(.16,1,.3,1)}
        .v.sai{opacity:0}
        .c{display:block;width:min(460px,100%);background:#fff;border-radius:24px;padding:22px 24px 16px;
          box-shadow:0 0 0 6px rgb(255 255 255 / .16),0 30px 80px rgb(11 13 18 / .45)}
        .v.nova .c{animation:sobe .35s cubic-bezier(.16,1,.3,1)}
        .cab{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px}
        .m{font:900 17px/1 "Hanken Grotesk","Segoe UI",system-ui,sans-serif;letter-spacing:-.06em}
        .m i{font-style:normal;color:#1f4bff}
        .tag{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;line-height:1.2;font-weight:600;color:#1f4bff;background:#eef1ff;border-radius:99px;padding:4px 10px 4px 8px}
        .tag::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor;animation:pisca 1.4s ease-in-out infinite}
        .topo{display:flex;align-items:center;gap:14px}
        .txt{display:block;min-width:0;flex:1}
        .radar{position:relative;width:44px;height:44px;flex:none;border-radius:14px;background:#eef1ff;display:grid;place-items:center}
        .radar::before,.radar::after{content:"";position:absolute;inset:0;border-radius:14px;border:2px solid #1f4bff;opacity:0;animation:onda 2s cubic-bezier(.16,1,.3,1) infinite}
        .radar::after{animation-delay:1s}
        .radar svg{width:22px;height:22px;stroke:#1f4bff;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
        .t{display:block;font-size:16px;line-height:1.3;font-weight:650;color:#0b0d12;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .d{display:block;color:#4d5363;font-size:13px;line-height:1.45;min-height:19px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .fases{display:flex;gap:6px;margin-top:18px;list-style:none}
        .fases[hidden],.trilho[hidden],.rodape[hidden]{display:none}
        .fases li{flex:1;display:grid;gap:6px;font-size:11.5px;line-height:1.2;font-weight:600;color:#9aa0ad}
        .fases li::before{content:"";height:4px;border-radius:2px;background:#eceef3}
        .fases li.feita{color:#12804f}
        .fases li.feita::before{background:#12b886}
        .fases li.agora{color:#1f4bff}
        .fases li.agora::before{background:linear-gradient(90deg,#1f4bff var(--p,30%),#dfe5ff 0)}
        .fases li.agora.indef::before{background:linear-gradient(90deg,#dfe5ff,#1f4bff,#dfe5ff);background-size:200% 100%;animation:corre 1.3s linear infinite}
        .trilho{display:block;height:6px;border-radius:3px;background:#eceef3;overflow:hidden;margin-top:18px}
        .trilho i{display:block;height:100%;border-radius:3px;background:#1f4bff;transition:width .5s cubic-bezier(.16,1,.3,1)}
        .trilho.indef i{width:35%!important;animation:vai 1.2s cubic-bezier(.45,0,.55,1) infinite}
        .nums{display:flex;justify-content:space-between;gap:12px;margin-top:10px;font-size:12.5px;line-height:1.4;color:#4d5363;font-variant-numeric:tabular-nums}
        .nums b{color:#0b0d12;font-weight:650}
        .aviso{display:flex;gap:10px;align-items:flex-start;margin-top:16px;padding:10px 12px;border-radius:12px;background:#f6f7f9;font-size:12.5px;line-height:1.5;color:#4d5363}
        .aviso svg{width:16px;height:16px;flex:none;margin-top:1px;stroke:#4d5363;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
        .rodape{display:flex;justify-content:flex-end;margin-top:10px}
        button{font-size:12px;line-height:1.4;color:#7a8090;cursor:pointer;padding:4px 2px;text-decoration:underline;text-underline-offset:3px}
        button:hover,button:focus-visible{color:#1f4bff;outline:none}
        .confirma{display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;gap:10px;margin-top:10px;font-size:12.5px;color:#9a6200}
        .confirma[hidden]{display:none}
        .confirma button{text-decoration:none;padding:6px 12px;border-radius:99px;background:#f6f7f9;color:#0b0d12}
        .confirma button.sim{background:#d8332f;color:#fff}
        .v.pronto .radar{background:#e6f8f1}
        .v.pronto .radar::before,.v.pronto .radar::after{display:none}
        .v.pronto .radar svg{stroke:#12b886}
        .v.pronto .tag{color:#12804f;background:#e6f8f1}
        .v.pronto .tag::before{animation:none}
        @keyframes entra{from{opacity:0}}
        @keyframes sobe{from{opacity:0;transform:translateY(12px) scale(.98)}}
        @keyframes onda{0%{transform:scale(1);opacity:.55}100%{transform:scale(1.6);opacity:0}}
        @keyframes vai{0%{transform:translateX(-100%)}100%{transform:translateX(290%)}}
        @keyframes corre{from{background-position:200% 0}to{background-position:0 0}}
        @keyframes pisca{50%{opacity:.3}}
        @media (prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
        </style>
        <div class="v" role="alertdialog" aria-modal="true" aria-live="polite"><div class="c">
          <div class="cab"><span class="m">revisa<i>.</i></span><span class="tag">Lendo o SOC</span></div>
          <div class="topo"><span class="radar"><svg viewBox="0 0 24 24"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="m9 15 2 2 4-4"/></svg></span>
            <span class="txt"><b class="t"></b><span class="d"></span></span></div>
          <ol class="fases" hidden></ol>
          <span class="trilho"><i></i></span>
          <div class="nums"><span class="q"></span><span class="tempo"></span></div>
          <div class="aviso"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>
            <span class="aviso-t">Esta janela fica travada enquanto o revisa. lê, para nada se misturar. Use as outras abas e programas à vontade: ela libera sozinha ao terminar.</span></div>
          <div class="rodape"><button type="button" class="liberar">Liberar agora</button></div>
          <div class="confirma" hidden><span>A leitura em andamento pode falhar.</span><button type="button" class="nao">Continuar lendo</button><button type="button" class="sim">Liberar mesmo assim</button></div>
        </div></div>`;
      const v = raiz.querySelector('.v');
      // Só na primeira vez a placa sobe; nas recriações (SOC recarregou) ela aparece parada, sem piscar.
      if (!window.__auditorVeuJaMostrou) { v.classList.add('nova'); window.__auditorVeuJaMostrou = true; }
      const ehBotao = (e) => e.composedPath().some((n) => n.tagName === 'BUTTON');
      // Cliques, rolagem e toques ficam presos no véu; o app trabalha por dentro, sem precisar deles.
      for (const ev of ['click', 'dblclick', 'mousedown', 'mouseup', 'contextmenu', 'wheel', 'touchstart']) {
        host.addEventListener(ev, (e) => { if (!ehBotao(e)) { e.preventDefault(); e.stopPropagation(); } }, { capture: true, passive: false });
      }
      // Teclado: bloqueia digitação e F5 (recarregar derrubaria a leitura); atalhos com Ctrl/Alt (trocar de aba) passam.
      window.removeEventListener('keydown', window.__auditorVeuTeclas, true);
      window.__auditorVeuTeclas = (e) => {
        if (!document.getElementById(ID)) return;
        const recarrega = e.key === 'F5' || ((e.ctrlKey || e.metaKey) && /^r$/i.test(e.key));
        if (recarrega || !(e.ctrlKey || e.metaKey || e.altKey)) {
          if ((e.key === 'Enter' || e.key === ' ') && ehBotao(e)) return;
          e.preventDefault();
          e.stopPropagation();
        }
      };
      window.addEventListener('keydown', window.__auditorVeuTeclas, true);
      // "Liberar agora" pede confirmação ali mesmo (sem caixa do navegador).
      const confirma = raiz.querySelector('.confirma');
      raiz.querySelector('.liberar').addEventListener('click', () => { confirma.hidden = false; raiz.querySelector('.rodape').hidden = true; });
      confirma.querySelector('.nao').addEventListener('click', () => { confirma.hidden = true; raiz.querySelector('.rodape').hidden = false; });
      confirma.querySelector('.sim').addEventListener('click', () => { window.__auditorVeuLiberado = Date.now(); window.__auditorVeuFechar(); });
      if (window.__auditorVeuTitulo === undefined) window.__auditorVeuTitulo = document.title;
      window.__auditorVeuFechar = () => {
        clearInterval(window.__auditorVeuVigia);
        clearInterval(window.__auditorVeuRelogio);
        window.removeEventListener('keydown', window.__auditorVeuTeclas, true);
        if (window.__auditorVeuTitulo !== undefined) document.title = window.__auditorVeuTitulo;
        window.__auditorVeuTitulo = undefined;
        window.__auditorVeuJaMostrou = false;
        document.getElementById(ID)?.remove();
      };
      // Se o app parar de dar sinal (travou ou foi fechado), o véu sai sozinho.
      clearInterval(window.__auditorVeuVigia);
      window.__auditorVeuVigia = setInterval(() => {
        if (Date.now() - (window.__auditorVeuSinal || 0) > 90000) window.__auditorVeuFechar();
      }, 5000);
      // Relógio: tempo passado e, quando já dá para medir o ritmo, quanto falta.
      const mmss = (ms) => { const s = Math.max(0, Math.round(ms / 1000)); return s < 60 ? `${s} s` : `${Math.floor(s / 60)} min ${String(s % 60).padStart(2, '0')} s`; };
      const relogio = () => {
        const el = document.getElementById(ID)?.shadowRoot?.querySelector('.v');
        if (!el || el.classList.contains('pronto')) return;
        const r = window.__auditorVeuRitmo;
        let falta = '';
        if (r && r.feito - r.feito0 >= 2 && r.total > r.feito) {
          const min = Math.max(1, Math.round((((Date.now() - r.t0) / (r.feito - r.feito0)) * (r.total - r.feito)) / 60000));
          falta = ` · faltam ~${min} min`;
        }
        el.querySelector('.tempo').textContent = `${mmss(Date.now() - (window.__auditorVeuInicio || Date.now()))}${falta}`;
      };
      clearInterval(window.__auditorVeuRelogio);
      window.__auditorVeuRelogio = setInterval(relogio, 1000);
      (document.body || document.documentElement).append(host);
    }
    // Depois de "Liberar mesmo assim", o reenvio periódico não traz o véu de volta.
    if (window.__auditorVeuLiberado && Date.now() - window.__auditorVeuLiberado < 600000) { host.remove(); return false; }
    const v = host.shadowRoot.querySelector('.v');
    window.__auditorVeuSinal = Date.now();
    window.__auditorVeuInicio = inicio || window.__auditorVeuInicio || Date.now();
    window.__auditorVeuRitmo = ritmo || null;
    v.classList.remove('pronto', 'sai');
    v.querySelector('.tag').textContent = 'Lendo o SOC';
    v.querySelector('.t').textContent = titulo || 'revisa. trabalhando';
    v.querySelector('.d').textContent = detalhe || '';
    v.querySelector('.d').title = detalhe || '';
    const temTotal = Number(total) > 0;
    const pct = temTotal ? Math.round((100 * feito) / total) : 0;

    // Fases (quando o trabalho tem mais de uma): feitas em verde, a atual com o próprio progresso.
    const fases = v.querySelector('.fases');
    const lista = Array.isArray(etapas) ? etapas : [];
    fases.hidden = lista.length < 2;
    fases.replaceChildren(...lista.map((nome, i) => {
      const li = document.createElement('li');
      li.className = i < etapa ? 'feita' : i === etapa ? `agora${temTotal ? '' : ' indef'}` : '';
      li.style.setProperty('--p', `${Math.max(4, pct)}%`);
      li.textContent = `${i < etapa ? '✓ ' : ''}${nome}`;
      return li;
    }));
    // Com fases, a barra fica dentro da fase atual; sem fases, a barra única.
    const trilho = v.querySelector('.trilho');
    trilho.hidden = lista.length >= 2;
    trilho.classList.toggle('indef', !temTotal);
    trilho.querySelector('i').style.width = temTotal ? `${Math.max(4, pct)}%` : '';
    v.querySelector('.q').innerHTML = temTotal ? `<b>${Number(feito)}</b> de ${Number(total)} · ${pct}%` : 'Preparando…';
    document.title = `${temTotal ? `(${pct}%) ` : ''}revisa. · ${titulo || 'trabalhando'}`;
    return true;
  },

  // mensagem: mostra um "Pronto" rápido antes de sair; sem mensagem, sai na hora.
  ocultar: function ({ mensagem } = {}) {
    window.__auditorVeuLiberado = 0;
    const host = document.getElementById('auditor-veu');
    if (!host || typeof window.__auditorVeuFechar !== 'function') { host?.remove(); return true; }
    if (!mensagem) { window.__auditorVeuFechar(); return true; }
    clearInterval(window.__auditorVeuVigia);
    window.removeEventListener('keydown', window.__auditorVeuTeclas, true);
    const v = host.shadowRoot.querySelector('.v');
    v.classList.add('pronto');
    v.querySelector('.tag').textContent = 'Concluído';
    v.querySelector('.radar svg').innerHTML = '<path d="M20 6 9 17l-5-5"/>';
    v.querySelector('.t').textContent = 'Pronto';
    v.querySelector('.d').textContent = mensagem;
    v.querySelectorAll('.fases li').forEach((li) => { li.className = 'feita'; });
    v.querySelector('.trilho').classList.remove('indef');
    v.querySelector('.trilho i').style.width = '100%';
    v.querySelector('.aviso-t').textContent = 'A janela já está liberada. Os resultados estão no painel do revisa.';
    v.querySelector('.rodape').hidden = true;
    v.querySelector('.confirma').hidden = true;
    if (window.__auditorVeuTitulo !== undefined) document.title = window.__auditorVeuTitulo;
    host.style.setProperty('pointer-events', 'none', 'important');
    setTimeout(() => v.classList.add('sai'), 1600);
    setTimeout(() => window.__auditorVeuFechar(), 2000);
    return true;
  },
};

// Estado do véu no lado do app: o último pedido (para reenviar), o início e o ritmo (para o tempo restante).
const estado = new WeakMap();

function estadoDe(sessao) {
  let e = estado.get(sessao);
  if (!e) { e = { inicio: Date.now(), ritmo: null, ultimo: null, timer: null }; estado.set(sessao, e); }
  return e;
}

// O véu nunca pode derrubar o trabalho: falhas nele são ignoradas.
export async function veu(sessao, dados) {
  if (sessao.porTras) return; // trabalho por trás: a tela do médico fica livre, o progresso aparece no painel
  const e = estadoDe(sessao);
  const total = Number(dados.total) || 0;
  const feito = Number(dados.feito) || 0;
  // Ritmo: recomeça quando o total muda (outra fase) ou a contagem volta.
  if (total && (!e.ritmo || e.ritmo.total !== total || feito < e.ritmo.feito)) e.ritmo = { t0: Date.now(), feito0: feito, feito, total };
  else if (total) e.ritmo.feito = feito;
  else e.ritmo = null;
  e.ultimo = { ...dados, inicio: e.inicio, ritmo: e.ritmo };
  // Reenvio periódico: recria o véu se o SOC recarregar a janela no meio do trabalho.
  if (!e.timer) {
    e.timer = setInterval(() => {
      if (e.ultimo && !e.enviando) {
        e.enviando = rodar(sessao, pagina.mostrar, e.ultimo).catch(() => {}).finally(() => { e.enviando = null; });
      }
    }, 1500);
  }
  try {
    await rodar(sessao, pagina.mostrar, e.ultimo);
  } catch {
    // página no meio de uma navegação; o reenvio recria o véu
  }
}

export async function tirarVeu(sessao, dados = {}) {
  if (sessao.porTras) return;
  const e = estado.get(sessao);
  if (e) {
    clearInterval(e.timer);
    e.ultimo = null;
    estado.delete(sessao);
    await e.enviando; // um reenvio em voo chegaria depois e traria o véu de volta
  }
  try {
    await rodar(sessao, pagina.ocultar, dados);
  } catch {
    // sem véu para tirar
  }
}

export { pagina as paginaVeu };
